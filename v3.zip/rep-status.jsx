/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, ScheduledContent, AssignedContent */
const { useState, useEffect } = React;

const STATUS_DIST = [
  { name: "Not Interested",   v: 18, color: "#7c2d12" },
  { name: "Negotiation",      v: 8,  color: "#16a34a" },
  { name: "Just Check",       v: 6,  color: "#9a3412" },
  { name: "Privacy",          v: 3,  color: "#16a34a" },
  { name: "Purchased",        v: 0,  color: "#22c55e" },
  { name: "Attempted To Purchase", v: 0, color: "#16a34a" },
  { name: "Spam",             v: 0,  color: "#9a3412" },
  { name: "New",              v: 0,  color: "#3b82f6" },
  { name: "incoming call not supported", v: 1, color: "#3b82f6" },
];

const BREAKDOWN = [
  { user: "Shad", attention: 18, interest: 0, desire: 0, action: 0, total: 18 },
  { user: "Nasiha", attention: 5, interest: 0, desire: 0, action: 0, total: 5 },
  { user: "Privacy", attention: 3, interest: 0, desire: 0, action: 0, total: 3 },
  { user: "Fathima rana kp", attention: 1, interest: 0, desire: 0, action: 0, total: 1 },
  { user: "Rana Fathima MP", attention: 1, interest: 0, desire: 0, action: 0, total: 1 },
  { user: "Abhinaraj", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Alfiya fathima kv", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Ardhra ganesh pg", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Arjun M", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Arya", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Ayisha Noura.B", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Ayishathul Hudha", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Aysha fidha k", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Fahmida", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Fathima Hamida", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Fathima Khusna", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "GINA GAZIYALI", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Hana Hashima", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Hanna fathima v", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
  { user: "Honoura Karamatel", attention: 0, interest: 0, desire: 0, action: 0, total: 0 },
];

function Kpi({ icon, label, value, sub, color = "#3b82f6" }) {
  const accentMap = {
    "#ef4444": "accent-red", "#3b82f6": "accent-blue", "#a855f7": "accent-purple",
    "#22c55e": "accent-green", "#eab308": "accent-yellow", "#22d3ee": "accent-cyan",
    "#f97316": "accent-yellow" };
  const accent = accentMap[color] || "accent-blue";
  return (
    <div className={`card kpi ${accent}`}>
      <div className="kpi-top">
        <div className="kpi-icon" style={{
          background: `color-mix(in srgb, ${color} 18%, transparent)`,
          color: color,
          boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${color} 30%, transparent)` }}>
          <Icon name={icon} className="" size={20} />
        </div>
        <span className="kpi-label">{label}</span>
      </div>
      <div className="kpi-val">{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}

function StatusDistBars() {
  const max = Math.max(...STATUS_DIST.map(s => s.v), 1);
  return (
    <div className="hbar-list">
      {STATUS_DIST.map((s, i) => (
        <div key={i} className="hbar-row" style={{ gridTemplateColumns: "200px 1fr 32px" }}>
          <div className="hbar-label">{s.name}</div>
          <div className="hbar-track">
            <div className="hbar-fill" style={{ width: `${(s.v / max) * 100}%`, background: s.color }} />
          </div>
          <div className="hbar-val">{s.v}</div>
        </div>
      ))}
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [filters, setFilters] = useState({ date: "18/04/2026 – 18/05/2026", field: null, user: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="rep-lead-status" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Lead Status Report"
          subtitle="See how your leads are currently distributed across statuses. Filter by date range to understand how the pipeline looked at a specific point in time."
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={<button className="btn-export"><Icon name="download" className="" />Export CSV</button>}
        />
        <div className="content">
          <div className="rep-filters">
            <FilterPill label="Date" value={filters.date} open={openPop==="date"} onToggle={(o)=>setOpenPop(o?"date":null)} onClear={()=>setFilter("date",null)}>
              <ScheduledContent value={filters.date} onChange={(v)=>{setFilter("date",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Date Field" value={filters.field} open={openPop==="field"} onToggle={(o)=>setOpenPop(o?"field":null)} onClear={()=>setFilter("field",null)}>
              <AssignedContent value={filters.field} onChange={(v)=>{setFilter("field",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Assigned User" value={filters.user} open={openPop==="user"} onToggle={(o)=>setOpenPop(o?"user":null)} onClear={()=>setFilter("user",null)}>
              <AssignedContent value={filters.user} onChange={(v)=>{setFilter("user",v);setOpenPop(null);}} />
            </FilterPill>
          </div>

          <div className="kpi-grid" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
            <Kpi icon="users-2"  color="#3b82f6" label="Total Leads"      value="31"  sub="Leads matching the selected date range and filters" />
            <Kpi icon="activity" color="#22c55e" label="Active Statuses"  value="5"   sub="Statuses with leads in this period" />
            <Kpi icon="spark"    color="#a855f7" label="Top Status"       value={<span style={{display:"inline-flex",gap:6,alignItems:"center"}}><span className="pill pill-blue pill-mini">New</span></span>} sub="29 leads · Status with the most leads right now" />
            <Kpi icon="alert"    color="#f97316" label="No Status"        value="0"   sub="Leads with no status assigned in this period" />
          </div>

          <div className="rep-section">
            <h3>Status Distribution</h3>
            <div className="sub">Lead count per status for the extended period</div>
            <StatusDistBars />
          </div>

          <div className="rep-section">
            <h3>Breakdown by Stage</h3>
            <div className="sub">Lead count per team member, grouped by AIDA stage</div>
            <table className="leads-table" style={{ marginTop: 4 }}>
              <thead>
                <tr>
                  <th>User</th>
                  <th style={{ textAlign:"right" }}><span style={{ display:"inline-flex", gap:6, alignItems:"center" }}><span className="dot-status" style={{ background:"#3b82f6" }}></span>Attention</span></th>
                  <th style={{ textAlign:"right" }}><span style={{ display:"inline-flex", gap:6, alignItems:"center" }}><span className="dot-status" style={{ background:"#a855f7" }}></span>Interest</span></th>
                  <th style={{ textAlign:"right" }}><span style={{ display:"inline-flex", gap:6, alignItems:"center" }}><span className="dot-status" style={{ background:"#f97316" }}></span>Desire</span></th>
                  <th style={{ textAlign:"right" }}><span style={{ display:"inline-flex", gap:6, alignItems:"center" }}><span className="dot-status" style={{ background:"#22c55e" }}></span>Action</span></th>
                  <th style={{ textAlign:"right" }}>Total</th>
                </tr>
              </thead>
              <tbody>
                {BREAKDOWN.map((b, i) => (
                  <tr key={i}>
                    <td style={{ fontWeight: 500 }}>{b.user}</td>
                    <td style={{ textAlign:"right" }} className="tt-cell">{b.attention}</td>
                    <td style={{ textAlign:"right" }} className="tt-cell">{b.interest}</td>
                    <td style={{ textAlign:"right" }} className="tt-cell">{b.desire}</td>
                    <td style={{ textAlign:"right" }} className="tt-cell">{b.action}</td>
                    <td style={{ textAlign:"right", fontWeight: 700 }} className="tt-cell">{b.total}</td>
                  </tr>
                ))}
                <tr style={{ background: "var(--surface-2)" }}>
                  <td style={{ fontWeight: 700 }}>Total</td>
                  <td style={{ textAlign:"right", fontWeight: 700 }} className="tt-cell">31</td>
                  <td style={{ textAlign:"right", fontWeight: 700 }} className="tt-cell">0</td>
                  <td style={{ textAlign:"right", fontWeight: 700 }} className="tt-cell">0</td>
                  <td style={{ textAlign:"right", fontWeight: 700 }} className="tt-cell">0</td>
                  <td style={{ textAlign:"right", fontWeight: 700 }} className="tt-cell">31</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
