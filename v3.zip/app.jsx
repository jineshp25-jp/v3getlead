/* global React, ReactDOM, Icon, KPI, LeadsAddedChart, DonutChart, CategoryBarChart, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakToggle, TweakSlider */
const { useState, useEffect, useMemo } = React;

// ─── data
const KPIS = [
  { label: "Total Leads - Today",      value: "48",    icon: "grid",   color: "#ef4444", chip: "12.5%", chipDir: "down", sub: "12.5% vs yesterday",   subDir: "down", featured: true,
    spark: [22,18,28,20,32,28,35,30,42,38,48] },
  { label: "Total Leads - This Week",  value: "412",   icon: "target", color: "#3b82f6", chip: "8.2%",  chipDir: "up",   sub: "8.2% vs last week",    subDir: "up",
    spark: [18,22,20,30,28,34,38,42,48,52,60] },
  { label: "Total Leads - This Month", value: "2,842", icon: "calendar", color: "#a855f7", chip: "15.6%", chipDir: "up", sub: "Target: 3,500",         subDir: "neutral", progress: 81,
    spark: [12,18,22,30,38,42,48,55,62,72,80] },
  { label: "Active Deals",             value: "32",    icon: "drop",   color: "#22c55e", chip: "8",     chipDir: "up",   sub: "8 due today",          subDir: "up",
    spark: [10,14,12,18,22,20,24,28,26,30,32] },
  { label: "Conversion Rate",          value: "24.8%", icon: "shield", color: "#eab308", chip: "2.1%",  chipDir: "up",   sub: "2.1% boost",           subDir: "up",
    spark: [16,18,20,22,20,24,22,26,24,28,30] },
  { label: "Pipeline Value",           value: "$4.9M", icon: "tag",    color: "#22d3ee", chip: "6.7%",  chipDir: "up",   sub: "6.7% vs last month",   subDir: "up",
    spark: [22,28,26,34,32,38,42,40,48,50,56] },
];

function buildLeadsAdded() {
  const days = 30;
  const today = new Date(2026, 4, 8);
  const out = [];
  const seed = [4,6,3,8,5,12,9,7,4,11,6,8,14,10,7,5,9,12,8,6,11,15,13,9,18,22,16,28,42,24];
  for (let i = 0; i < days; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - (days - 1 - i));
    const lab = i % 6 === 0 || i === days - 1 ? `${["Jan","Feb","Mar","Apr","May","Jun"][d.getMonth()]} ${d.getDate()}` : "";
    out.push({ v: seed[i], label: lab || `${d.getMonth()+1}/${d.getDate()}` });
  }
  return out;
}

const LEADS_BY_STATUS = [
  { name: "New", v: 15, color: "var(--c-blue)" },
  { name: "Contacted", v: 2, color: "var(--c-cyan)" },
  { name: "Not attended", v: 0, color: "var(--c-red)" },
  { name: "Not interested", v: 2, color: "var(--c-orange)" },
  { name: "Attempt 1", v: 1, color: "var(--c-purple)" },
  { name: "Interested", v: 1, color: "var(--c-pink)" },
  { name: "Qualified", v: 0, color: "var(--c-green)" },
  { name: "None", v: 0, color: "var(--text-3)" },
];

const LEAD_SOURCES_BARS = [
  { label: "Direct",       v: 28, color: "#22c55e" },
  { label: "Excel Import", v: 8,  color: "#f87171" },
  { label: "GLDialer",     v: 16, color: "#84cc16" },
  { label: "IVR",          v: 32, color: "#a855f7" },
  { label: "KTX",          v: 16, color: "#f97316" },
];

const DEALS_BY_STATUS = [
  { name: "New",         v: 40, color: "#3b82f6", icon: "grid" },
  { name: "In Progress", v: 70, color: "#eab308", icon: "drop" },
  { name: "Negotiation", v: 23, color: "#a855f7", icon: "tag" },
  { name: "Won",         v: 99, color: "#22c55e", icon: "check" },
  { name: "Lost",        v: 8,  color: "#ef4444", icon: "shield" },
];

const DETAILED_SOURCES = [
  ["BNI", 0], ["Excel Import KTX", 1], ["Google Ads", 0], ["KSSIA", 0],
  ["KTX Draft", 0], ["MCC", 0], ["Reboot 2024", 0], ["Website", 0],
  ["CMA", 0], ["Facebook", 0], ["Instagram", 0], ["KTX", 4],
  ["KTX FB", 0], ["Migration", 0], ["Referral", 0], ["TikTok", 0],
  ["Direct", 5], ["FACEBOOK", 0], ["INSTAGRAM", 0], ["KTX9th", 0],
  ["ktx new", 0], ["Portal", 0], ["Type 1", 0], ["LinkedIn", 0],
  ["Excel Import", 0], ["GLDialer", 3], ["IVR", 8], ["KTX 9th", 0],
  ["Reboot", 0],
];

function LegendList({ items, total }) {
  return (
    <div className="legend">
      {items.map((it, i) => {
        const pct = total ? Math.round((it.v / total) * 100) : 0;
        return (
          <div className="row" key={i}>
            <span className="sw" style={{ background: it.color }}></span>
            <span className="name">{it.name}</span>
            <span className="val">{it.v}</span>
            <span className="pct">{pct}%</span>
          </div>
        );
      })}
    </div>
  );
}

function ProgressList({ items }) {
  const max = Math.max(...items.map(x => x.v));
  return (
    <div className="prog-list">
      {items.map((it, i) => (
        <div key={i} className="prog-row">
          <div className="prog-avatar" style={{
            background: `color-mix(in srgb, ${it.color} 18%, transparent)`,
            color: it.color,
            boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${it.color} 30%, transparent)` }}>
            <Icon name={it.icon} className="" size={14} />
          </div>
          <div className="prog-body">
            <div className="prog-line1">
              <span className="prog-name">{it.name}</span>
              <span className="prog-val">{it.v} deals</span>
            </div>
            <div className="prog-track">
              <div className="prog-fill" style={{ width: `${(it.v / max) * 100}%`, background: it.color }} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function DetailedSources() {
  const COLORS = ["#ef4444","#3b82f6","#a855f7","#22c55e","#f97316","#22d3ee","#eab308","#ec4899","#84cc16","#6366f1"];
  const items = DETAILED_SOURCES.map(([name, v], i) => ({ name, v, color: COLORS[i % COLORS.length] }));
  return (
    <div className="card">
      <div className="card-head">
        <div>
          <h3 className="card-title">Detailed Lead Sources</h3>
          <div className="card-sub">All channels · click to filter</div>
        </div>
        <div className="range-pill">Last 30 Days <Icon name="chevron-down" className="" size={12} /></div>
      </div>

      <div className="src-grid">
        {items.map((s) => {
          const initials = s.name.split(/\s+/).map(w => w[0]).slice(0, 2).join("").toUpperCase();
          return (
            <div key={s.name} className={`src-card ${s.v === 0 ? "empty" : ""}`} style={{ "--accent": s.color }}>
              <div className="src-card-head">
                <span className="src-mark" style={{ background: `linear-gradient(135deg, ${s.color}, color-mix(in srgb, ${s.color} 60%, #000))` }}>{initials}</span>
                <div className="src-name">{s.name}</div>
                <div className="src-count">{s.v}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "theme": "dark",
    "accent": "#ef3b3b",
    "fontScale": 100,
    "showSparklines": true
  }/*EDITMODE-END*/);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", tweaks.theme);
  }, [tweaks.theme]);

  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    // strong = darken approximation via mix
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);

  useEffect(() => {
    document.documentElement.style.fontSize = `${tweaks.fontScale}%`;
  }, [tweaks.fontScale]);

  const leadsTotal = useMemo(() => LEADS_BY_STATUS.reduce((s, x) => s + x.v, 0), []);
  const leadsAdded = useMemo(buildLeadsAdded, []);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="dashboard" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar title="Dashboard" theme={tweaks.theme} setTheme={(v) => setTweak("theme", v)} />
        <div className="content">
          <div className="hero">
            <div className="hero-top">
              <div className="hero-text">
                <h2 className="hero-title">Total Leads Overview</h2>
                <p className="hero-sub">Real-time breakdown of your lead generation performance across key timeframes.</p>
              </div>
              <div className="hero-filters">
                <div className="hero-filter">
                  <span className="hero-flabel">PERIOD</span>
                  <span className="hero-fval">Last 30 Days</span>
                  <Icon name="chevron-down" className="" size={12} />
                </div>
                <div className="hero-filter">
                  <span className="hero-flabel">BRANCH</span>
                  <span className="hero-fval">All Branches</span>
                  <Icon name="chevron-down" className="" size={12} />
                </div>
              </div>
            </div>
            <div className="hero-divider"></div>
            <div className="hero-bottom">
              <div className="hero-stat">
                <div className="hero-stat-label">Total Leads · All Time</div>
                <div className="hero-stat-val">12,988</div>
              </div>
              <div className="hero-deltas">
                <div className="hero-delta-card">
                  <span className="hero-delta-icon up">▲</span>
                  <div>
                    <div className="hero-delta-val up">+31,138</div>
                    <div className="hero-delta-cap">created</div>
                  </div>
                </div>
                <div className="hero-delta-card">
                  <span className="hero-delta-icon down">▼</span>
                  <div>
                    <div className="hero-delta-val down">−18,150</div>
                    <div className="hero-delta-cap">deleted</div>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <div className="kpi-grid">
            {KPIS.map((k, i) => (
              <KPI key={i} {...k} />
            ))}
          </div>

          <div className="row-2">
            <div className="card hover">
              <div className="card-head">
                <div>
                  <h3 className="card-title">Leads Added <span className="title-suf">(Last 30 Days)</span></h3>
                  <div className="card-sub">Daily breakdown of new leads</div>
                </div>
                <div className="range-pill">Last 30 Days <Icon name="chevron-down" className="" size={12} /></div>
              </div>
              <LeadsAddedChart data={leadsAdded} />
            </div>

            <div className="card hover">
              <div className="card-head">
                <div>
                  <h3 className="card-title">Leads by Status</h3>
                  <div className="card-sub">Distribution across pipeline</div>
                </div>
                <div className="range-pill">Last 30 Days <Icon name="chevron-down" className="" size={12} /></div>
              </div>
              <div className="donut-wrap">
                <div className="donut-center">
                  <DonutChart items={LEADS_BY_STATUS} total={leadsTotal} />
                </div>
                <LegendList items={LEADS_BY_STATUS} total={leadsTotal} />
              </div>
            </div>
          </div>

          <div className="row-2-eq">
            <div className="card hover">
              <div className="card-head">
                <div>
                  <h3 className="card-title">Lead Sources</h3>
                  <div className="card-sub">Where your leads come from</div>
                </div>
                <div className="range-pill">Last 30 Days <Icon name="chevron-down" className="" size={12} /></div>
              </div>
              <CategoryBarChart data={LEAD_SOURCES_BARS} unit="%" />
            </div>

            <div className="card hover">
              <div className="card-head">
                <div>
                  <h3 className="card-title">Deals by Status</h3>
                  <div className="card-sub">Pipeline stage breakdown</div>
                </div>
                <div className="range-pill">Last 30 Days <Icon name="chevron-down" className="" size={12} /></div>
              </div>
              <ProgressList items={DEALS_BY_STATUS} />
            </div>
          </div>

          <DetailedSources />
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio
          label="Mode"
          value={tweaks.theme}
          options={["dark", "light"]}
          onChange={(v) => setTweak("theme", v)}
        />
        <TweakColor
          label="Accent"
          value={tweaks.accent}
          options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]}
          onChange={(v) => setTweak("accent", v)}
        />
        <TweakSection label="Display" />
        <TweakSlider
          label="Font scale"
          value={tweaks.fontScale}
          min={85} max={115} step={5} unit="%"
          onChange={(v) => setTweak("fontScale", v)}
        />
        <TweakToggle
          label="Sparklines"
          value={tweaks.showSparklines}
          onChange={(v) => setTweak("showSparklines", v)}
        />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
