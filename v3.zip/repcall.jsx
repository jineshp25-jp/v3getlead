/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, ScheduledContent, AssignedContent */
const { useState, useEffect } = React;

const HISTORY = [
  { cust: "FAROOK KURIKKAL",  phone: "+91 96354 81003", type: "Initiated · Outbound", typeAns: false, agent: "Shad",            time: "15/05/2026, 9:44 pm", dur: "5h"     },
  { cust: "RASHEED ALI",      phone: "+91 9111 92204", type: "Answered",             typeAns: true,  agent: "Shad",            time: "15/05/2026, 9:44 pm", dur: "0s"     },
  { cust: "ABDUL SHABEER",    phone: "+91 70123 03402", type: "Initiated · Outbound", typeAns: false, agent: "Shad",            time: "15/05/2026, 9:43 pm", dur: "0s"     },
  { cust: "MUGESH KUMAR",     phone: "+91 96354 22500", type: "Answered",             typeAns: true,  agent: "Shad",            time: "15/05/2026, 9:40 pm", dur: "2s"     },
  { cust: "FINOB K",          phone: "+91 96354 75690", type: "Answered",             typeAns: true,  agent: "Shad",            time: "15/05/2026, 9:41 pm", dur: "40s"    },
  { cust: "Harisuthan Prakash", phone: "+91 70123 4321", type: "Answered",           typeAns: true,  agent: "Shad",            time: "15/05/2026, 9:39 pm", dur: "40s"    },
  { cust: "NAVAS KPT",        phone: "+91 99887 65656", type: "Initiated · Outbound", typeAns: false, agent: "Muhammed Nihad",  time: "15/05/2026, 9:36 pm", dur: "0s"     },
  { cust: "SUSMITHA AJITH",   phone: "+91 70123 9087",  type: "Answered",             typeAns: true,  agent: "Shad",            time: "15/05/2026, 9:34 pm", dur: "1m 40s" },
  { cust: "ILYAS HAMEED",     phone: "+91 99887 12340", type: "Answered",             typeAns: true,  agent: "Shad",            time: "15/05/2026, 9:34 pm", dur: "51s"    },
  { cust: "VIPIN KUMAR PP",   phone: "+91 99887 41122", type: "Answered",             typeAns: true,  agent: "Muhammed Nihad",  time: "15/05/2026, 9:33 pm", dur: "1m 10s" },
  { cust: "RAHUFINA POPY",    phone: "+91 99887 33112", type: "Answered",             typeAns: true,  agent: "Muhammed Nihad",  time: "15/05/2026, 9:33 pm", dur: "8s"     },
  { cust: "SREELAL K",        phone: "+91 99887 22209", type: "Initiated · Outbound", typeAns: false, agent: "Shad",            time: "15/05/2026, 9:31 pm", dur: "0s"     },
  { cust: "Ashitha vm",       phone: "+91 99887 47823", type: "Initiated · Outbound", typeAns: false, agent: "Shad",            time: "15/05/2026, 9:31 pm", dur: "0s"     },
  { cust: "Srivatsa Acharya", phone: "+91 99887 02124", type: "Answered",             typeAns: true,  agent: "Shad",            time: "15/05/2026, 9:29 pm", dur: "1s"     },
  { cust: "Mohammed Najeeb Rahman", phone: "+91 99887 32133", type: "Answered",       typeAns: true,  agent: "Shad",            time: "15/05/2026, 9:27 pm", dur: "1m 46s" },
  { cust: "Dr. ROSHNI SHAFEEQ", phone: "+91 99887 41100", type: "Answered",          typeAns: true,  agent: "Shad",            time: "15/05/2026, 9:27 pm", dur: "0s"     },
  { cust: "KIRAN JOABS",      phone: "+91 99887 51202", type: "Initiated · Outbound", typeAns: false, agent: "Shad",            time: "15/05/2026, 9:26 pm", dur: "0s"     },
  { cust: "KIRAN JOABS",      phone: "+91 99887 51202", type: "Initiated · Outbound", typeAns: false, agent: "Shad",            time: "15/05/2026, 9:25 pm", dur: "0s"     },
  { cust: "RAJEESH CHIRAKKAL", phone: "+91 99887 17012", type: "Initiated · Outbound", typeAns: false, agent: "Shad",            time: "15/05/2026, 9:25 pm", dur: "0s"     },
  { cust: "ARUN PRASAD",      phone: "+91 99887 18222", type: "Initiated · Outbound", typeAns: false, agent: "Shad",            time: "15/05/2026, 9:00 pm", dur: "0s"     },
  { cust: "Girish KK",        phone: "+91 99887 50320", type: "Answered",             typeAns: true,  agent: "Shad",            time: "15/05/2026, 5:08 pm", dur: "50s"    },
  { cust: "DILEEP K P",       phone: "+91 99887 17708", type: "Answered",             typeAns: true,  agent: "Shad",            time: "15/05/2026, 5:01 pm", dur: "30s"    },
  { cust: "SAJEED MUHAMMED",  phone: "+91 99887 20402", type: "Initiated · Outbound", typeAns: false, agent: "Shad",            time: "15/05/2026, 4:56 pm", dur: "0s"     },
  { cust: "ARUN BRILLIANT",   phone: "+91 99887 19412", type: "Initiated · Outbound", typeAns: false, agent: "Shad",            time: "15/05/2026, 4:55 pm", dur: "0s"     },
  { cust: "SHAHID SHOWKATH",  phone: "+91 99887 26851", type: "Answered",             typeAns: true,  agent: "Shad",            time: "15/05/2026, 3:12 pm", dur: "0s"     },
];

const LEADERBOARD = [
  { name: "Shad",            total: 768, answered: 354 },
  { name: "Muhammed Nihad",  total: 705, answered: 321 },
  { name: "Fathima Rinsha",  total: 588, answered: 299 },
  { name: "Princy",          total: 450, answered: 208 },
  { name: "Sajana",          total: 429, answered: 199 },
  { name: "Meharin Zainab M", total: 472, answered: 166 },
  { name: "Abhinaraj",       total: 249, answered: 125 },
  { name: "Unassigned",      total: 243, answered: 120 },
  { name: "Ayishathul Hudha", total: 178, answered: 97 },
  { name: "fathima rinsha pk", total: 196, answered: 84 },
  { name: "Sheethal k",      total: 151, answered: 55 },
  { name: "ittis sharin",    total: 144, answered: 53 },
  { name: "Shahana Shameem", total: 77,  answered: 50 },
  { name: "Fahmida",         total: 102, answered: 24 },
  { name: "Nasiha",          total: 41,  answered: 15 },
  { name: "Suhadha Aneez",   total: 33,  answered: 12 },
  { name: "Hana Hashma",     total: 21,  answered: 9 },
  { name: "Fathima rana kp", total: 11,  answered: 4 },
  { name: "Alfiya fathima kv", total: 159, answered: 3 },
  { name: "GINA GAZIYALI",   total: 77,  answered: 1 },
];

function VolumeStat({ icon, color, num, lbl }) {
  return (
    <div className="vol-stat">
      <span className="vol-icon" style={{ color }}>
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{icon}</svg>
      </span>
      <div>
        <div className="vol-num">{num.toLocaleString()}</div>
        <div className="vol-lbl">{lbl}</div>
      </div>
    </div>
  );
}

function MiniChart() {
  // Two line dataset
  const inc = [12, 14, 11, 13, 12, 18, 22, 35, 60, 40, 30, 25, 22, 28, 15];
  const out = [4, 5, 6, 4, 4, 6, 8, 14, 20, 18, 12, 10, 14, 10, 8];
  const w = 600, h = 200, padL = 38, padR = 12, padT = 14, padB = 26;
  const innerW = w - padL - padR, innerH = h - padT - padB;
  const max = Math.max(...inc, ...out);
  const tickMax = Math.ceil(max / 100) * 100 || max;
  const pts = (data) => data.map((v, i) => {
    const x = padL + (i / (data.length - 1)) * innerW;
    const y = padT + innerH - (v / tickMax) * innerH;
    return `${x},${y}`;
  }).join(" ");
  const labels = ["19 Apr","21 Apr","23 Apr","25 Apr","27 Apr","29 Apr","1 May","3 May","5 May","7 May","9 May","11 May","13 May","15 May","17 May"];
  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{ width: "100%", height: "auto", display: "block" }}>
      <g className="axis">
        {[0, 0.25, 0.5, 0.75, 1].map((t, i) => {
          const y = padT + innerH - t * innerH;
          return <g key={i}><line x1={padL} y1={y} x2={w - padR} y2={y} stroke="var(--grid)" strokeDasharray="2 4" /><text x={padL - 6} y={y + 3} textAnchor="end" fill="var(--text-3)" style={{ fontSize: 10 }}>{Math.round(t * tickMax)}</text></g>;
        })}
      </g>
      <polyline points={pts(inc)} fill="none" stroke="#3b82f6" strokeWidth="2" />
      <polyline points={pts(out)} fill="none" stroke="#22c55e" strokeWidth="2" />
      <g className="axis">
        {labels.filter((_, i) => i % 3 === 0).map((l, i) => {
          const idx = i * 3;
          const x = padL + (idx / (labels.length - 1)) * innerW;
          return <text key={i} x={x} y={h - 8} textAnchor="middle" fill="var(--text-3)" style={{ fontSize: 10 }}>{l}</text>;
        })}
      </g>
    </svg>
  );
}

function Donut() {
  const attended = 2214, unattended = 3148;
  const total = attended + unattended;
  const size = 160, stroke = 24, r = (size - stroke) / 2, cx = size / 2, cy = size / 2;
  const C = 2 * Math.PI * r;
  const fracA = attended / total;
  return (
    <svg viewBox={`0 0 ${size} ${size}`} width="160" height="160">
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="#ef4444" strokeWidth={stroke} />
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="#22c55e" strokeWidth={stroke}
        strokeDasharray={`${fracA * C} ${C - fracA * C}`} strokeDashoffset="0"
        transform={`rotate(-90 ${cx} ${cy})`} />
    </svg>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [tab, setTab] = useState("All");
  const [filters, setFilters] = useState({ date: "18/04/2026 – 18/05/2026", field: null, agent: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="rep-call-report" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Call Report"
          subtitle="Inbound and outbound call activity. Use this report to track answered vs missed calls, spot busy days, and see how each agent is performing."
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={
            <div className="cr-tabs">
              <button className={`cr-tab ${tab === "All" ? "active" : ""}`} onClick={() => setTab("All")}>All</button>
              <button className={`cr-tab ${tab === "GL Dialer" ? "active" : ""}`} onClick={() => setTab("GL Dialer")}>GL Dialer</button>
            </div>
          }
        />
        <div className="content">
          <div className="cr-tabs-row">
            <a href="CallReport.html" className="cr-tab active">Call Report</a>
            <a href="CallHistory.html" className="cr-tab">Call History</a>
          </div>
          <div className="rep-filters">
            <FilterPill label="Date" value={filters.date} open={openPop==="date"} onToggle={(o)=>setOpenPop(o?"date":null)} onClear={()=>setFilter("date",null)}>
              <ScheduledContent value={filters.date} onChange={(v)=>{setFilter("date",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Date Field" value={filters.field} open={openPop==="field"} onToggle={(o)=>setOpenPop(o?"field":null)} onClear={()=>setFilter("field",null)}>
              <AssignedContent value={filters.field} onChange={(v)=>{setFilter("field",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Agent" value={filters.agent} open={openPop==="agent"} onToggle={(o)=>setOpenPop(o?"agent":null)} onClear={()=>setFilter("agent",null)}>
              <AssignedContent value={filters.agent} onChange={(v)=>{setFilter("agent",v);setOpenPop(null);}} />
            </FilterPill>
          </div>

          <div className="cr-summary">
            <div className="rep-section cr-vol">
              <h3>Volume</h3>
              <div className="sub">Across the selected period</div>

              <div className="vol-hero">
                <div className="vol-hero-num">5,362</div>
                <div className="vol-hero-lbl">Total calls</div>
                <div className="vol-progress">
                  <div className="vol-progress-track">
                    <div className="vol-progress-fill" style={{ width: "41.3%", background: "#22c55e" }}></div>
                  </div>
                  <div className="vol-progress-meta">
                    <span style={{ color: "#22c55e" }}>2,214 answered</span>
                    <span style={{ color: "var(--text-3)" }}>41.3%</span>
                  </div>
                </div>
              </div>

              <div className="vol-split">
                <div className="vol-mini">
                  <span className="vol-mini-dot" style={{ background: "#22c55e" }}></span>
                  <div>
                    <div className="vol-mini-num">239</div>
                    <div className="vol-mini-lbl">Incoming</div>
                  </div>
                </div>
                <div className="vol-mini">
                  <span className="vol-mini-dot" style={{ background: "#3b82f6" }}></span>
                  <div>
                    <div className="vol-mini-num">5,123</div>
                    <div className="vol-mini-lbl">Outgoing</div>
                  </div>
                </div>
                <div className="vol-mini">
                  <span className="vol-mini-dot" style={{ background: "#ef4444" }}></span>
                  <div>
                    <div className="vol-mini-num">0</div>
                    <div className="vol-mini-lbl">Missed</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="rep-section">
              <h3>Incoming vs Outgoing</h3>
              <div className="sub">Daily call volume by direction</div>
              <MiniChart />
              <div className="cr-legend">
                <span><span className="sw" style={{ background: "#3b82f6" }}></span>Incoming</span>
                <span><span className="sw" style={{ background: "#22c55e" }}></span>Outgoing</span>
              </div>
            </div>

            <div className="rep-section">
              <h3>Attended vs Unattended</h3>
              <div className="sub">Across all directions</div>
              <div style={{ display: "grid", placeItems: "center", padding: "12px 0" }}>
                <Donut />
              </div>
              <div className="cr-legend">
                <span><span className="sw" style={{ background: "#22c55e" }}></span>Attended</span>
                <span><span className="sw" style={{ background: "#ef4444" }}></span>Unattended</span>
              </div>
            </div>
          </div>

          <div className="cr-grid">
            <div className="rep-section">
              <h3>Recent Call History</h3>
              <div className="sub">Each row is a single call. Customer, type (answered or missed), agent, time, and duration.</div>
              <table className="leads-table">
                <thead>
                  <tr><th>Customer</th><th>Call Type</th><th>Agent</th><th>Time</th><th>Duration</th></tr>
                </thead>
                <tbody>
                  {HISTORY.map((h, i) => (
                    <tr key={i}>
                      <td>
                        <div style={{ fontWeight: 600 }}>{h.cust}</div>
                        <div className="tt-phone">{h.phone}</div>
                      </td>
                      <td>
                        <span className={`cr-type ${h.typeAns ? "ans" : "init"}`}>{h.type}</span>
                      </td>
                      <td><span className="agent-tag">{h.agent}</span></td>
                      <td className="tt-cell" style={{ color: "var(--text-2)" }}>{h.time}</td>
                      <td className="tt-cell">{h.dur}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="rep-pager">
                <div></div>
                <div className="rep-pager-right">
                  <button className="pager-btn">Previous</button>
                  <button className="pager-btn">Next</button>
                </div>
              </div>
            </div>

            <div className="rep-section">
              <h3>Agent Leaderboard</h3>
              <div className="sub">Calls handled and answered per agent</div>
              <table className="leads-table">
                <thead>
                  <tr><th>Agent</th><th style={{ textAlign: "right" }}>Total</th><th style={{ textAlign: "right" }}>Answered</th></tr>
                </thead>
                <tbody>
                  {LEADERBOARD.map((l, i) => (
                    <tr key={i}>
                      <td style={{ fontWeight: 500 }}>{l.name}</td>
                      <td className="tt-cell" style={{ textAlign: "right" }}>{l.total}</td>
                      <td className="tt-cell" style={{ textAlign: "right", fontWeight: 600 }}>{l.answered}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
