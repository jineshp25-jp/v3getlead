/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, AssignedContent */
const { useState, useEffect } = React;

const FEED = [
  { day: "MAY 2026", items: [
    { icon: "phone",       cat: "blue",   t: "Call",              meta: "Outbound · Inbound call answered for ar.Sk Saber · Performed by Nasiha", time: "1:00 pm" },
    { icon: "phone",       cat: "blue",   t: "Call",              meta: "SHAHEED HASSAN · Inbound call answered for ar.Sk Saber · Performed by Nasiha", time: "12:50 pm" },
    { icon: "phone",       cat: "blue",   t: "Call",              meta: "Unknown Lead · Inbound call answered for ar.Sk Saber · Performed by Nasiha", time: "1:43 pm" },
    { icon: "user-plus",   cat: "green",  t: "Assigned to User",  meta: "Unknown Lead · Lead assigned to Nasiha", time: "1:43 pm" },
    { icon: "plus",        cat: "green",  t: "Lead Created",      meta: "Unknown Lead · Lead created by Nasiha", time: "1:43 pm" },
    { icon: "phone",       cat: "blue",   t: "Call",              meta: "Outbound · Inbound call answered for ar.Sk Saber · Performed by Nasiha", time: "12:30 pm" },
    { icon: "phone",       cat: "blue",   t: "Call",              meta: "Outbound · Inbound call answered for ar.Sk Saber · Performed by Nasiha", time: "12:30 pm" },
    { icon: "star",        cat: "orange", t: "Spotlight Toggled", meta: "Unknown Lead · Lead unstarred", time: "11:00 pm" },
    { icon: "phone",       cat: "blue",   t: "Call",              meta: "Outbound · Inbound call answered for ar.Sk Saber · Performed by Nasiha", time: "11:00 pm" },
    { icon: "user-plus",   cat: "green",  t: "Assigned to User",  meta: "Unknown Lead · Lead assigned to Nasiha", time: "11:00 pm" },
    { icon: "plus",        cat: "green",  t: "Lead Created",      meta: "Unknown Lead · Lead created by Nasiha", time: "11:00 pm" },
    { icon: "phone",       cat: "blue",   t: "Call",              meta: "Unknown Lead · Inbound call answered for ar.Sk Saber · Performed by Nasiha", time: "11:40 am" },
    { icon: "phone",       cat: "blue",   t: "Call",              meta: "Unknown Lead · Inbound call answered for ar.Sk Saber · Performed by Nasiha", time: "11:35 am" },
    { icon: "tasks",       cat: "purple", t: "Task Created",      meta: "SHAHEEEDU · Task created", time: "10:36 am" },
    { icon: "user-plus",   cat: "green",  t: "Assigned to User",  meta: "SHAHEEEDU · Lead assigned to Nasiha", time: "10:36 am" },
    { icon: "leads",       cat: "orange", t: "Status Changed",    meta: "Mr. SK SHEMEED · Lead status changed from New to Not interested", time: "10:36 am" },
    { icon: "check",       cat: "green",  t: "Task Completed",    meta: "Mr. ASWINI MANOJ · Task completed: Follow Up - Mr. ASWINI MANOJ · Outgoing by Nopona", time: "10:36 am" },
    { icon: "user-plus",   cat: "green",  t: "Assigned to User",  meta: "Mr. ASWINI MANOJ · Lead assigned to Nasiha", time: "10:36 am" },
    { icon: "tasks",       cat: "purple", t: "Task Created",      meta: "SHAHEEEDU · Task created", time: "10:11 am" },
    { icon: "check",       cat: "green",  t: "Task Completed",    meta: "Mr. ASWINI MANOJ · Task completed: Follow Up - Mr. ASWINI MANOJ", time: "10:11 am" },
  ] }
];

const BREAKDOWN_ACT = [
  { name: "Status Changed",       v: 23904, color: "#3b82f6", pct: "1.0%" },
  { name: "Added to Campaigns",   v: 17545, color: "#a855f7", pct: "19.0%" },
  { name: "Task Created",         v: 12331, color: "#f97316", pct: "5.0%" },
  { name: "Unassigned from User", v: 12054, color: "#22d3ee", pct: "13.0%" },
  { name: "Task Completed",       v: 11349, color: "#ec4899", pct: "12.0%" },
  { name: "Assigned to User",     v: 11275, color: "#65a30d", pct: "12.0%" },
  { name: "Call",                 v: 2303,  color: "#06b6d4", pct: "2.0%" },
  { name: "Lead Created",         v: 40,    color: "#16a34a", pct: "0.0%" },
  { name: "Lead Deleted",         v: 11,    color: "#dc2626", pct: "0.0%" },
  { name: "Purposes Updated",     v: 10,    color: "#a855f7", pct: "0.0%" },
  { name: "Note Added",           v: 8,     color: "#84cc16", pct: "0.0%" },
  { name: "Spotlight Toggled",    v: 6,     color: "#f97316", pct: "0.0%" },
  { name: "Lead Updated",         v: 3,     color: "#3b82f6", pct: "0.0%" },
  { name: "Phone Numbers Updated", v: 1,    color: "#06b6d4", pct: "0.0%" },
  { name: "Converted to Deal",    v: 1,     color: "#16a34a", pct: "0.0%" },
];

const LEADERBOARD = [
  { name: "Shad",           v: 2842 },
  { name: "Muhammed Nihad", v: 2270 },
  { name: "Fahmida",        v: 2206 },
  { name: "Nasiha",         v: 1970 },
  { name: "Fathima Khusna", v: 1462 },
  { name: "Smita johoneyy", v: 1199 },
  { name: "Fathima rana kp",v: 1188 },
  { name: "Rana Fathima MP", v: 1124 },
  { name: "Privacy",        v: 1062 },
  { name: "Meharin Zainab M", v: 1070 },
];

function Kpi({ icon, label, value, sub, color = "#3b82f6" }) {
  const accentMap = {
    "#ef4444": "accent-red", "#3b82f6": "accent-blue", "#a855f7": "accent-purple",
    "#22c55e": "accent-green", "#eab308": "accent-yellow", "#22d3ee": "accent-cyan",
    "#f97316": "accent-yellow" };
  const accent = accentMap[color] || "accent-blue";
  return (
    <div className={`card kpi ${accent}`}>
      <div className="kpi-top">
        <div className="kpi-icon" style={{
          background: `color-mix(in srgb, ${color} 18%, transparent)`,
          color: color,
          boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${color} 30%, transparent)` }}>
          <Icon name={icon} className="" size={20} />
        </div>
        <span className="kpi-label">{label}</span>
      </div>
      <div className="kpi-val">{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}

function Heatmap() {
  const cells = Array.from({ length: 30 }, () => Math.random());
  return (
    <div>
      <div className="heatmap">
        {cells.map((v, i) => <div key={i} className="heat-cell" style={{ "--lv": v }} />)}
      </div>
      <div className="heat-legend">
        <span>Low</span>
        <span className="scale">
          <span style={{ background: "color-mix(in srgb, var(--brand) 4%, var(--surface-2))" }}></span>
          <span style={{ background: "color-mix(in srgb, var(--brand) 18%, var(--surface-2))" }}></span>
          <span style={{ background: "color-mix(in srgb, var(--brand) 35%, var(--surface-2))" }}></span>
          <span style={{ background: "color-mix(in srgb, var(--brand) 55%, var(--surface-2))" }}></span>
          <span style={{ background: "color-mix(in srgb, var(--brand) 80%, var(--surface-2))" }}></span>
        </span>
        <span>High</span>
      </div>
    </div>
  );
}

function Donut() {
  const total = BREAKDOWN_ACT.reduce((s, x) => s + x.v, 0);
  const size = 160, stroke = 24, r = (size - stroke) / 2, cx = size / 2, cy = size / 2;
  const C = 2 * Math.PI * r;
  let acc = 0;
  return (
    <svg viewBox={`0 0 ${size} ${size}`} width="160" height="160">
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="var(--track)" strokeWidth={stroke} />
      {BREAKDOWN_ACT.map((it, i) => {
        const frac = it.v / total;
        const len = frac * C;
        const dasharray = `${len} ${C - len}`;
        const dashoffset = -acc * C;
        acc += frac;
        return <circle key={i} cx={cx} cy={cy} r={r} fill="none" stroke={it.color}
          strokeWidth={stroke} strokeDasharray={dasharray} strokeDashoffset={dashoffset}
          transform={`rotate(-90 ${cx} ${cy})`} />;
      })}
      <text x={cx} y={cy - 4} textAnchor="middle" fill="var(--text-1)"
        style={{ fontSize: 22, fontWeight: 700, fontFamily: "var(--font-sans)" }}>
        {(total/1000).toFixed(0)}k
      </text>
      <text x={cx} y={cy + 14} textAnchor="middle" fill="var(--text-3)"
        style={{ fontSize: 9, fontWeight: 500, fontFamily: "var(--font-sans)" }}>
        TOTAL
      </text>
    </svg>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [filters, setFilters] = useState({ date: "01/05/2026 – 18/05/2026", user: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  const maxLeader = Math.max(...LEADERBOARD.map(l => l.v));

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="rep-activities" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Activities Report"
          subtitle="Stream of lead-related activities across your team. See who is most active, what types of activities are being performed, and when peak hours occur."
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
        />
        <div className="content">
          <div className="rep-filters">
            <FilterPill label="Date" value={filters.date} open={openPop==="date"} onToggle={(o)=>setOpenPop(o?"date":null)} onClear={()=>setFilter("date",null)}>
              <AssignedContent value={filters.date} onChange={(v)=>{setFilter("date",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Assigned User" value={filters.user} open={openPop==="user"} onToggle={(o)=>setOpenPop(o?"user":null)} onClear={()=>setFilter("user",null)}>
              <AssignedContent value={filters.user} onChange={(v)=>{setFilter("user",v);setOpenPop(null);}} />
            </FilterPill>
          </div>

          <div className="kpi-grid" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
            <Kpi icon="activity" color="#ef4444" label="Total Activities" value="91,979" sub="↑ 685% vs previous period" />
            <Kpi icon="users-2"  color="#3b82f6" label="Leads Added"      value="40"     sub="↑ 3000% vs previous period" />
            <Kpi icon="phone"    color="#a855f7" label="Calls Logged"     value="0"      sub="0% vs previous period" />
            <Kpi icon="reports"  color="#22c55e" label="Status Updates"   value="22,956" sub="↑ 210% vs previous period" />
          </div>

          <div className="rep-section">
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom: 10 }}>
              <div>
                <h3 style={{ marginBottom: 2 }}>Activity Heatmap</h3>
                <div className="sub">Hourly volume · May 2026</div>
              </div>
            </div>
            <Heatmap />
          </div>

          <div className="act-grid">
            <div className="rep-section">
              <h3>Activity Feed</h3>
              <div className="sub">May 2026</div>
              <div className="act-feed">
                {FEED.map((day, di) => (
                  <React.Fragment key={di}>
                    {day.items.map((a, i) => (
                      <div key={i} className="act-row">
                        <div className={`act-icon ${a.cat}`}><Icon name={a.icon} className="" /></div>
                        <div className="act-body">
                          <div className="act-title">{a.t}</div>
                          <div className="act-meta">{a.meta}</div>
                        </div>
                        <span className="act-time">{a.time}</span>
                      </div>
                    ))}
                  </React.Fragment>
                ))}
              </div>
              <div style={{ display: "flex", justifyContent: "center", padding: "14px 0 2px" }}>
                <button className="pager-btn" style={{ padding: "0 18px" }}>Load more</button>
              </div>
            </div>

            <div className="act-side">
              <div className="rep-section">
                <h3>Activity Breakdown</h3>
                <div className="sub">By type · May 2026</div>
                <div style={{ display: "flex", justifyContent: "center", padding: "8px 0" }}>
                  <Donut />
                </div>
                <div className="legend-rep" style={{ marginTop: 10 }}>
                  {BREAKDOWN_ACT.map((b, i) => (
                    <div key={i} className="row">
                      <span className="sw" style={{ background: b.color }}></span>
                      <span className="nm">{b.name}</span>
                      <span className="vl">{b.v.toLocaleString()}</span>
                      <span style={{ color: "var(--text-3)", minWidth: 40, textAlign: "right" }}>{b.pct}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rep-section">
                <h3>Agent Leaderboard</h3>
                <div className="sub">Activity · May 2026</div>
                <div className="lead-board">
                  {LEADERBOARD.map((l, i) => (
                    <div key={i} className="lead-row">
                      <span className="lead-rank">{i + 1}</span>
                      <span className="lead-name">{l.name}</span>
                      <div className="lead-bar"><div style={{ width: `${(l.v / maxLeader) * 100}%` }}></div></div>
                      <span className="lead-val">{l.v.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
