/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, ScheduledContent, AssignedContent */
const { useState, useEffect } = React;

const SOURCES = [
  { name: "Direct", v: 5,  color: "#6366f1" },
  { name: "Excel Import KTX", v: 1, color: "#6366f1" },
  { name: "GLDialer", v: 8, color: "#6366f1" },
  { name: "IVR", v: 13, color: "#6366f1" },
  { name: "KTX", v: 4, color: "#6366f1" },
];
const BREAKDOWN = [
  { src: "IVR", a: 13, i: 0, d: 0, ac: 0, total: 13 },
  { src: "GLDialer", a: 8, i: 0, d: 0, ac: 0, total: 8 },
  { src: "Direct", a: 5, i: 0, d: 0, ac: 0, total: 5 },
  { src: "KTX", a: 4, i: 0, d: 0, ac: 0, total: 4 },
  { src: "Excel Import KTX", a: 1, i: 0, d: 0, ac: 0, total: 1 },
];

function Kpi({ icon, label, value, sub, color = "#3b82f6" }) {
  const accentMap = {
    "#ef4444": "accent-red", "#3b82f6": "accent-blue", "#a855f7": "accent-purple",
    "#22c55e": "accent-green", "#eab308": "accent-yellow", "#22d3ee": "accent-cyan",
    "#f97316": "accent-yellow" };
  const accent = accentMap[color] || "accent-blue";
  return (
    <div className={`card kpi ${accent}`}>
      <div className="kpi-top">
        <div className="kpi-icon" style={{
          background: `color-mix(in srgb, ${color} 18%, transparent)`,
          color: color,
          boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${color} 30%, transparent)` }}>
          <Icon name={icon} className="" size={20} />
        </div>
        <span className="kpi-label">{label}</span>
      </div>
      <div className="kpi-val">{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}

function SourceBars() {
  const max = Math.max(...SOURCES.map(s => s.v));
  return (
    <div className="hbar-list">
      {SOURCES.map((s, i) => (
        <div key={i} className="hbar-row" style={{ gridTemplateColumns: "140px 1fr 40px" }}>
          <div className="hbar-label">{s.name}</div>
          <div className="hbar-track" style={{ height: 18 }}>
            <div className="hbar-fill" style={{ width: `${(s.v / max) * 100}%`, background: s.color }} />
          </div>
          <div className="hbar-val">{s.v}</div>
        </div>
      ))}
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [filters, setFilters] = useState({ date: "18/04/2026 – 18/05/2026", field: null, source: null, user: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="rep-lead-source" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Lead Source Report"
          subtitle="See which sources are driving the most leads. Filter by date range to understand source performance over any period."
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={<button className="btn-export"><Icon name="download" className="" />Export CSV</button>}
        />
        <div className="content">
          <div className="rep-filters">
            <FilterPill label="Date" value={filters.date} open={openPop==="date"} onToggle={(o)=>setOpenPop(o?"date":null)} onClear={()=>setFilter("date",null)}>
              <ScheduledContent value={filters.date} onChange={(v)=>{setFilter("date",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Date Field" value={filters.field} open={openPop==="field"} onToggle={(o)=>setOpenPop(o?"field":null)} onClear={()=>setFilter("field",null)}>
              <AssignedContent value={filters.field} onChange={(v)=>{setFilter("field",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Source" value={filters.source} open={openPop==="source"} onToggle={(o)=>setOpenPop(o?"source":null)} onClear={()=>setFilter("source",null)}>
              <AssignedContent value={filters.source} onChange={(v)=>{setFilter("source",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Assigned User" value={filters.user} open={openPop==="user"} onToggle={(o)=>setOpenPop(o?"user":null)} onClear={()=>setFilter("user",null)}>
              <AssignedContent value={filters.user} onChange={(v)=>{setFilter("user",v);setOpenPop(null);}} />
            </FilterPill>
          </div>

          <div className="kpi-grid" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
            <Kpi icon="users-2"  color="#3b82f6" label="Total Leads" value="31"  sub="Leads matching the selected date range and filters" />
            <Kpi icon="reports"  color="#22c55e" label="Active Sources" value="5" sub="Sources with at least one lead in this period" />
            <Kpi icon="trend-up" color="#a855f7" label="Top Source" value={<span style={{display:"inline-flex",flexDirection:"column"}}><span style={{ fontSize: 18, color: "#3b82f6", fontWeight: 700 }}>IVR</span><span style={{ fontSize: 11, color: "var(--text-3)" }}>13 leads</span></span>} sub="Source with the highest lead count" />
            <Kpi icon="star"     color="#f97316" label="Best Converting Source" value="—" sub="Source with the most leads reaching the Action stage" />
          </div>

          <div className="rep-section">
            <h3>Source Distribution</h3>
            <div className="sub">Lead count per source for the selected period</div>
            <SourceBars />
          </div>

          <div className="rep-section">
            <h3>Breakdown by AIDA Stage</h3>
            <div className="sub">Lead count per source, grouped by AIDA stage</div>
            <table className="leads-table" style={{ marginTop: 4 }}>
              <thead>
                <tr>
                  <th>Source</th>
                  <th style={{ textAlign:"right" }}><span style={{ display:"inline-flex", gap:6, alignItems:"center" }}><span className="dot-status" style={{ background:"#3b82f6" }}></span>Attention</span></th>
                  <th style={{ textAlign:"right" }}><span style={{ display:"inline-flex", gap:6, alignItems:"center" }}><span className="dot-status" style={{ background:"#a855f7" }}></span>Interest</span></th>
                  <th style={{ textAlign:"right" }}><span style={{ display:"inline-flex", gap:6, alignItems:"center" }}><span className="dot-status" style={{ background:"#f97316" }}></span>Desire</span></th>
                  <th style={{ textAlign:"right" }}><span style={{ display:"inline-flex", gap:6, alignItems:"center" }}><span className="dot-status" style={{ background:"#22c55e" }}></span>Action</span></th>
                  <th style={{ textAlign:"right" }}>Total</th>
                </tr>
              </thead>
              <tbody>
                {BREAKDOWN.map((b, i) => (
                  <tr key={i}>
                    <td style={{ fontWeight: 500 }}>{b.src}</td>
                    <td style={{ textAlign:"right" }} className="tt-cell">{b.a}</td>
                    <td style={{ textAlign:"right" }} className="tt-cell">{b.i}</td>
                    <td style={{ textAlign:"right" }} className="tt-cell">{b.d}</td>
                    <td style={{ textAlign:"right" }} className="tt-cell">{b.ac}</td>
                    <td style={{ textAlign:"right", fontWeight: 700 }} className="tt-cell">{b.total}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
