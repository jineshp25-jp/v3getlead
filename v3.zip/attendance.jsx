/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, ScheduledContent, AssignedContent, MoreContent */
const { useState, useEffect } = React;

const KPIS = [
  { num: "0",   lbl: "Agents",      icon: "team",       color: "#3b82f6" },
  { num: "0",   lbl: "Sessions",    icon: "layers",     color: "#a855f7" },
  { num: "0.0", lbl: "Total hours", icon: "clock",      color: "#eab308" },
  { num: "0",   lbl: "Active now",  icon: "activity",   color: "#22c55e" },
];

const MORE_GROUPS = [
  { group: "People", items: ["Team", "Role"] },
  { group: "Location", items: ["Branch", "GPS Region"] },
  { group: "Session",  items: ["Status", "Duration"] },
];

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [filters, setFilters] = useState({ date: "18/05/2026 – 18/05/2026", agent: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "theme": "dark",
    "accent": "#ef3b3b",
    "fontScale": 100
  }/*EDITMODE-END*/);

  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="attendance" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Attendance"
          subtitle="Every field check-in and check-out across your team. Click a row for photos, GPS, and full notes."
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
        />
        <div className="content">
          <div className="att-filters">
            <FilterPill
              label="Date"
              value={filters.date}
              open={openPop === "date"}
              onToggle={(o) => setOpenPop(o ? "date" : null)}
              onClear={() => setFilter("date", null)}
            >
              <ScheduledContent value={filters.date} onChange={(v) => { setFilter("date", v); setOpenPop(null); }} />
            </FilterPill>
            <FilterPill
              label="Agent"
              value={filters.agent}
              open={openPop === "agent"}
              onToggle={(o) => setOpenPop(o ? "agent" : null)}
              onClear={() => setFilter("agent", null)}
            >
              <AssignedContent value={filters.agent} onChange={(v) => { setFilter("agent", v); setOpenPop(null); }} />
            </FilterPill>
            <FilterPill
              label="More"
              value={null}
              open={openPop === "more"}
              onToggle={(o) => setOpenPop(o ? "more" : null)}
            >
              <MoreContent groups={MORE_GROUPS} onPick={() => setOpenPop(null)} />
            </FilterPill>
          </div>

          <div className="calls-kpi-grid tasks-kpi-grid">
            {KPIS.map((k, i) => (
              <div key={i} className="calls-kpi">
                <div className="calls-kpi-icon" style={{
                  background: `color-mix(in srgb, ${k.color} 18%, transparent)`,
                  color: k.color,
                  boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${k.color} 30%, transparent)` }}>
                  <Icon name={k.icon} className="" size={18} />
                </div>
                <div className="num" style={{ color: k.color }}>{k.num}</div>
                <div className="lbl">{k.lbl}</div>
              </div>
            ))}
          </div>

          <div className="att-empty">
            <h3 className="att-empty-title">Sessions</h3>
            <div className="att-empty-body">
              <div className="att-empty-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>
              </div>
              <div className="att-empty-text">No attendance records yet for these filters.</div>
            </div>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent}
          options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale}
          min={85} max={115} step={5} unit="%"
          onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
