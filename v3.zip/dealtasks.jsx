/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, ChevDown, FilterPill, ScheduledContent, StatusContent, AssignedContent, MoreContent */
const { useState, useEffect } = React;

const KPIS = [
  { num: "1", lbl: "Total",     accent: "blue",   color: "#3b82f6", icon: "deals"        },
  { num: "0", lbl: "Completed", accent: "green",  color: "#22c55e", icon: "check-circle" },
  { num: "1", lbl: "Pending",   accent: "yellow", color: "#eab308", icon: "clock"        },
  { num: "0", lbl: "Overdue",   accent: "red",    color: "#ef4444", icon: "alert"        },
];

const TASKS = [
  { deal: "Deal dashboard Testing", title: "Test Deail", details: "rgfv", category: "Email",
    assignedBy: "KTX GLOBAL", assignedTo: "Arya",
    created: "18/05/2026, 12:35 pm", scheduled: "18/05/2026, 1:34 pm" },
];

const MORE_GROUPS = [
  { group: "People", items: ["Assigned By"] },
  { group: "Deal",   items: ["Deal Status", "Deal Type", "Branch"] },
  { group: "Task",   items: ["Category", "Priority"] },
];

function Avatar({ name }) {
  const safe = name && name !== "-" ? name : "?";
  const initials = safe.split(" ").map(s => s[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
  return <span className="avatar-sm">{initials || "?"}</span>;
}

function RowMenu() {
  const [open, setOpen] = useState(false);
  const ref = React.useRef(null);
  useEffect(() => {
    if (!open) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);
  const items = [
    { id: "view",   label: "View Task",   icon: "eye" },
    { id: "edit",   label: "Edit Task",   icon: "edit" },
    { id: "delete", label: "Delete Task", icon: "trash", danger: true },
  ];
  return (
    <div className="row-menu-wrap" ref={ref}>
      <button className={`row-action ${open ? "active" : ""}`} onClick={(e) => { e.stopPropagation(); setOpen(o => !o); }} aria-label="More">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="5" r="1.3" fill="currentColor"/>
          <circle cx="12" cy="12" r="1.3" fill="currentColor"/>
          <circle cx="12" cy="19" r="1.3" fill="currentColor"/>
        </svg>
      </button>
      {open && (
        <div className="hdr-menu row-menu" role="menu" onClick={(e) => e.stopPropagation()}>
          {items.map((it) => (
            <button key={it.id} role="menuitem" className={`hdr-menu-item ${it.danger ? "danger" : ""}`} onClick={() => setOpen(false)}>
              <Icon name={it.icon} className="" size={16} />
              <span>{it.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function DealTasksToolbar({ pageSize, setPageSize, filters, setFilter, clearAll, openPop, setOpenPop }) {
  const hasAny = filters.scheduled || filters.status || filters.assigned;
  return (
    <>
      <div className="calls-toolbar calls-toolbar-merged">
        <div className="calls-search">
          <Icon name="search" className="" />
          <input placeholder="Search by task name, deal…" />
        </div>
        <select className="per-page-select" value={pageSize} onChange={(e) => setPageSize(Number(e.target.value))}>
          <option>15</option><option>25</option><option>50</option><option>100</option>
        </select>
        <FilterPill
          label="Scheduled"
          value={filters.scheduled}
          open={openPop === "sched"}
          onToggle={(o) => setOpenPop(o ? "sched" : null)}
          onClear={() => setFilter("scheduled", null)}
        >
          <ScheduledContent value={filters.scheduled} onChange={(v) => { setFilter("scheduled", v); setOpenPop(null); }} />
        </FilterPill>
        <FilterPill
          label="Status"
          value={filters.status}
          open={openPop === "status"}
          onToggle={(o) => setOpenPop(o ? "status" : null)}
          onClear={() => setFilter("status", null)}
        >
          <StatusContent value={filters.status} onChange={(v) => { setFilter("status", v); setOpenPop(null); }} />
        </FilterPill>
        <FilterPill
          label="Assigned To"
          value={filters.assigned}
          open={openPop === "assigned"}
          onToggle={(o) => setOpenPop(o ? "assigned" : null)}
          onClear={() => setFilter("assigned", null)}
        >
          <AssignedContent value={filters.assigned} onChange={(v) => { setFilter("assigned", v); setOpenPop(null); }} />
        </FilterPill>
        <FilterPill
          label="More"
          value={null}
          open={openPop === "more"}
          onToggle={(o) => setOpenPop(o ? "more" : null)}
        >
          <MoreContent groups={MORE_GROUPS} onPick={() => setOpenPop(null)} />
        </FilterPill>
        {hasAny && (
          <button className="clear-all-btn" onClick={clearAll}>
            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 6-12 12M6 6l12 12"/></svg>
            Clear All
          </button>
        )}
      </div>
    </>
  );
}

function DealTasksTable() {
  return (
    <div className="calls-table-wrap">
      <table className="leads-table">
        <thead>
          <tr>
            <th><span className="th-inner">Deal <ChevDown /></span></th>
            <th><span className="th-inner">Title <ChevDown /></span></th>
            <th><span className="th-inner">Details <ChevDown /></span></th>
            <th><span className="th-inner">Category <ChevDown /></span></th>
            <th><span className="th-inner">Assigned By <ChevDown /></span></th>
            <th><span className="th-inner">Assigned To <ChevDown /></span></th>
            <th><span className="th-inner">Status <ChevDown /></span></th>
            <th><span className="th-inner">Created At <ChevDown /></span></th>
            <th><span className="th-inner">Scheduled At <ChevDown /></span></th>
            <th className="col-actions"></th>
          </tr>
        </thead>
        <tbody>
          {TASKS.map((t, i) => (
            <tr key={i}>
              <td><span className="calls-lead">{t.deal}</span></td>
              <td><span className="lead-name">{t.title}</span></td>
              <td><span className="time-cell">{t.details}</span></td>
              <td><span className="tag">{t.category}</span></td>
              <td><span className="assigned-name"><Avatar name={t.assignedBy} />{t.assignedBy}</span></td>
              <td><span className="assigned-name"><Avatar name={t.assignedTo} />{t.assignedTo}</span></td>
              <td><span className="status-open">Open</span></td>
              <td><span className="time-cell">{t.created}</span></td>
              <td><span className="time-cell">{t.scheduled}</span></td>
              <td className="col-actions"><RowMenu /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [pageSize, setPageSize] = useState(15);
  const [filters, setFilters] = useState({ scheduled: "18/05/2026 – 18/05/2026", status: null, assigned: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));
  const clearAll = () => setFilters({ scheduled: null, status: null, assigned: null });

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "theme": "dark",
    "accent": "#ef3b3b",
    "fontScale": 100
  }/*EDITMODE-END*/);

  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  const headerActions = (
    <>
      <button className="btn-import">
        <Icon name="upload" className="" />
        Import
      </button>
      <button className="btn-primary">
        <Icon name="plus" className="" size={14} />
        New Deal Task
      </button>
    </>
  );

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="tasks-deal" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Deal Tasks"
          subtitle="Manage and track tasks associated with deals"
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={headerActions}
        />
        <div className="content">
          <div className="calls-kpi-grid tasks-kpi-grid">
            {KPIS.map((k, i) => (
              <div key={i} className={`calls-kpi accent-${k.accent}`}>
                <div className="calls-kpi-icon" style={{
                  background: `color-mix(in srgb, ${k.color} 18%, transparent)`,
                  color: k.color,
                  boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${k.color} 30%, transparent)` }}>
                  <Icon name={k.icon} className="" size={18} />
                </div>
                <div className="num" style={{ color: k.color }}>{k.num}</div>
                <div className="lbl">{k.lbl}</div>
              </div>
            ))}
          </div>

          <div>
            <DealTasksToolbar
              pageSize={pageSize}
              setPageSize={setPageSize}
              filters={filters}
              setFilter={setFilter}
              clearAll={clearAll}
              openPop={openPop}
              setOpenPop={setOpenPop}
            />
            <DealTasksTable />
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent}
          options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale}
          min={85} max={115} step={5} unit="%"
          onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
