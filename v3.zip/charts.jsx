/* global React */
const { useMemo: chartsUseMemo } = React;

// ───── Sparkline ─────
function Sparkline({ data, color = "currentColor", w = 60, h = 24 }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const step = w / (data.length - 1);
  const pts = data.map((v, i) => `${i * step},${h - ((v - min) / range) * (h - 4) - 2}`).join(" ");
  const last = data.length - 1;
  const lx = last * step;
  const ly = h - ((data[last] - min) / range) * (h - 4) - 2;
  return (
    <svg className="kpi-spark" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={lx} cy={ly} r="2" fill={color} />
    </svg>
  );
}

// ───── Bar chart (Leads Added) ─────
function LeadsAddedChart({ data }) {
  const w = 720, h = 240, padL = 36, padR = 8, padT = 14, padB = 28;
  const innerW = w - padL - padR;
  const innerH = h - padT - padB;
  const max = Math.max(...data.map(d => d.v));
  const niceMax = Math.ceil(max / 10) * 10;
  const barW = (innerW / data.length) * 0.55;
  const gap = (innerW / data.length) * 0.45;
  const ticks = [0, niceMax * 0.25, niceMax * 0.5, niceMax * 0.75, niceMax];
  const xLabels = [0, 7, 14, 21, 28].filter(i => data[i]);
  return (
    <div className="barchart">
      <svg viewBox={`0 0 ${w} ${h}`}>
        <g className="grid">
          {ticks.map((t, i) => {
            const y = padT + innerH - (t / niceMax) * innerH;
            return <line key={i} x1={padL} y1={y} x2={w - padR} y2={y} />;
          })}
        </g>
        <g className="axis">
          {ticks.map((t, i) => {
            const y = padT + innerH - (t / niceMax) * innerH;
            return <text key={i} x={padL - 8} y={y + 3} textAnchor="end">{Math.round(t)}</text>;
          })}
        </g>
        <g>
          {data.map((d, i) => {
            const x = padL + (i / data.length) * innerW + gap / 2;
            const bh = (d.v / niceMax) * innerH;
            const y = padT + innerH - bh;
            const isToday = i === data.length - 1;
            const isPeak = d.v === max;
            const fill = isPeak ? "var(--brand)" : isToday ? "var(--c-blue)" : "var(--text-3)";
            const opacity = isPeak ? 1 : isToday ? 1 : 0.5;
            return (
              <rect
                key={i}
                className="bar-rect"
                x={x} y={y}
                width={barW} height={Math.max(bh, 1)}
                rx="2.5"
                fill={fill}
                opacity={opacity}
                style={{ animationDelay: `${i * 12}ms` }}
              >
                <title>{d.label}: {d.v} leads</title>
              </rect>
            );
          })}
        </g>
        <g className="axis">
          {xLabels.map(i => {
            const x = padL + (i / data.length) * innerW + gap / 2 + barW / 2;
            return <text key={i} x={x} y={h - 8} textAnchor="middle">{data[i].label}</text>;
          })}
        </g>
      </svg>
    </div>
  );
}

// ───── Donut (Leads by Status) ─────
function DonutChart({ items, total }) {
  const size = 180, stroke = 18, r = (size - stroke) / 2, cx = size / 2, cy = size / 2;
  const C = 2 * Math.PI * r;
  let acc = 0;
  return (
    <svg viewBox={`0 0 ${size} ${size}`} width="180" height="180">
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="var(--track)" strokeWidth={stroke} />
      {items.filter(it => it.v > 0).map((it, i) => {
        const frac = it.v / total;
        const len = frac * C;
        const dasharray = `${len} ${C - len}`;
        const dashoffset = -acc * C;
        acc += frac;
        return (
          <circle
            key={i}
            cx={cx} cy={cy} r={r}
            fill="none"
            stroke={it.color}
            strokeWidth={stroke}
            strokeDasharray={dasharray}
            strokeDashoffset={dashoffset}
            transform={`rotate(-90 ${cx} ${cy})`}
            strokeLinecap="butt"
          />
        );
      })}
      <text x={cx} y={cy - 2} textAnchor="middle" fill="var(--text-1)"
            style={{ fontSize: 32, fontWeight: 600, fontFamily: "var(--font-sans)" }}>
        {total}
      </text>
      <text x={cx} y={cy + 16} textAnchor="middle" fill="var(--text-3)"
            style={{ fontSize: 9, fontWeight: 500, fontFamily: "var(--font-sans)" }}>
        TOTAL
      </text>
    </svg>
  );
}

// ───── Lead Sources bar chart (categorical) ─────
function CategoryBarChart({ data, unit = "" }) {
  const w = 540, h = 260, padL = 12, padR = 12, padT = 14, padB = 38;
  const innerW = w - padL - padR;
  const innerH = h - padT - padB;
  const max = Math.max(...data.map(d => d.v));
  const niceMax = Math.max(max, 4);
  const slot = innerW / data.length;
  const barW = Math.min(slot * 0.55, 60);
  return (
    <div className="barchart">
      <svg viewBox={`0 0 ${w} ${h}`}>
        <g className="grid">
          {[0.25, 0.5, 0.75, 1].map((t, i) => {
            const y = padT + innerH - t * innerH;
            return <line key={i} x1={padL} y1={y} x2={w - padR} y2={y} />;
          })}
        </g>
        <g>
          {data.map((d, i) => {
            const x = padL + slot * i + (slot - barW) / 2;
            const bh = (d.v / niceMax) * innerH;
            const y = padT + innerH - bh;
            return (
              <g key={i}>
                <rect
                  className="bar-rect"
                  x={x} y={y} width={barW} height={Math.max(bh, 2)}
                  rx="6"
                  fill={d.color}
                  style={{ animationDelay: `${i * 60}ms` }}
                >
                  <title>{d.label}: {d.v}</title>
                </rect>
                <text x={x + barW / 2} y={y - 8} textAnchor="middle"
                      fill="var(--text-1)"
                      style={{ fontSize: 13, fontWeight: 600, fontFamily: "var(--font-sans)" }}>{d.v}{unit}</text>
              </g>
            );
          })}
        </g>
        <g className="axis">
          {data.map((d, i) => {
            const x = padL + slot * i + slot / 2;
            return <text key={i} x={x} y={h - 14} textAnchor="middle">{d.label}</text>;
          })}
        </g>
      </svg>
    </div>
  );
}

window.Sparkline = Sparkline;
window.LeadsAddedChart = LeadsAddedChart;
window.DonutChart = DonutChart;
window.CategoryBarChart = CategoryBarChart;
