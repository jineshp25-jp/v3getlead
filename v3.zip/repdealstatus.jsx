/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, ScheduledContent, AssignedContent */
const { useState, useEffect } = React;

const STATUSES = [
  { name: "New",         dot: "#3b82f6", chip: "In Progress", chipKind: "progress", deals: 1, value: "INR 500.00", age: "5.6d", share: 100 },
  { name: "In Progress", dot: "#a855f7", chip: "In Progress", chipKind: "progress", deals: 0, value: "—",          age: "—",   share: 0 },
  { name: "Negotiation", dot: "#f97316", chip: "In Progress", chipKind: "progress", deals: 0, value: "—",          age: "—",   share: 0 },
  { name: "Won",         dot: "#22c55e", chip: "Win",          chipKind: "win",      deals: 0, value: "—",          age: "—",   share: null },
  { name: "Lost",        dot: "#ef4444", chip: "Loss",         chipKind: "loss",     deals: 0, value: "—",          age: "—",   share: null },
];

function Kpi({ icon, label, value, sub, color = "#3b82f6" }) {
  const accent = { "#ef4444":"accent-red","#3b82f6":"accent-blue","#a855f7":"accent-purple","#22c55e":"accent-green","#eab308":"accent-yellow","#22d3ee":"accent-cyan","#f97316":"accent-yellow" }[color] || "accent-blue";
  return (
    <div className={`card kpi ${accent}`}>
      <div className="kpi-top">
        <div className="kpi-icon" style={{ background: `color-mix(in srgb, ${color} 18%, transparent)`, color, boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${color} 30%, transparent)` }}>
          <Icon name={icon} className="" size={20} />
        </div>
        <span className="kpi-label">{label}</span>
      </div>
      <div className="kpi-val">{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [filters, setFilters] = useState({ date: "19/04/2026 – 19/05/2026", branch: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="rep-deal-status" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Deal Status Report"
          subtitle="A live snapshot of how your deals are distributed across statuses, with pipeline value and performance metrics."
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={<button className="btn-export"><Icon name="download" className="" />Export CSV</button>}
        />
        <div className="content">
          <div className="rep-filters">
            <FilterPill label="Date" value={filters.date} open={openPop==="date"} onToggle={(o)=>setOpenPop(o?"date":null)} onClear={()=>setFilter("date",null)}>
              <ScheduledContent value={filters.date} onChange={(v)=>{setFilter("date",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Branch" value={filters.branch} open={openPop==="branch"} onToggle={(o)=>setOpenPop(o?"branch":null)} onClear={()=>setFilter("branch",null)}>
              <AssignedContent value={filters.branch} onChange={(v)=>{setFilter("branch",v);setOpenPop(null);}} />
            </FilterPill>
            <span style={{ marginLeft: 8, color: "var(--text-3)", fontSize: '13.5px' }}>Currency:</span>
            <span className="tag-soft">INR</span>
          </div>

          <div className="kpi-grid" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
            <Kpi icon="target"   color="#3b82f6" label="Open Deals"    value="1"          sub="Deals currently in progress" />
            <Kpi icon="wallet"   color="#22c55e" label="Pipeline Value" value="INR 500.00" sub="Total value of open deals" />
            <Kpi icon="trend-up" color="#a855f7" label="Win Rate"      value="—"          sub="0W / 0L" />
            <Kpi icon="calendar" color="#eab308" label="Avg Deal Age"  value="5.6d"       sub="Average age across all deals" />
          </div>

          <div className="rep-section">
            <h3>Deal Status Breakdown</h3>
            <div className="sub">Deal count and pipeline value per status for the selected period</div>
            <table className="leads-table">
              <thead>
                <tr><th>Status</th><th style={{textAlign:"right"}}>Deals</th><th style={{textAlign:"right"}}>Value</th><th style={{textAlign:"right"}}>Avg Age</th><th>Pipeline Share</th></tr>
              </thead>
              <tbody>
                {STATUSES.map((s, i) => (
                  <tr key={i}>
                    <td>
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
                        <span className="dot-color" style={{ background: s.dot, margin: 0 }}></span>
                        <span style={{ fontWeight: 500 }}>{s.name}</span>
                        <span className={`pill-active ${s.chipKind === "loss" ? "" : s.chipKind === "win" ? "green" : ""}`} style={s.chipKind === "loss" ? { background: "var(--brand)" } : null}>{s.chip}</span>
                      </span>
                    </td>
                    <td className="tt-cell" style={{ textAlign: "right" }}>{s.deals}</td>
                    <td className="tt-cell" style={{ textAlign: "right", fontWeight: 600 }}>{s.value}</td>
                    <td className="tt-cell" style={{ textAlign: "right", color: "var(--text-2)" }}>{s.age}</td>
                    <td style={{ width: 240 }}>
                      {s.share === null ? <span style={{ color: "var(--text-3)" }}>—</span> :
                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                          <div className="hbar-track" style={{ flex: 1, height: 6 }}><div className="hbar-fill red" style={{ width: `${s.share}%` }}></div></div>
                          <span className="tt-cell" style={{ minWidth: 36, textAlign: "right", color: s.share === 0 ? "var(--text-3)" : "var(--text-1)" }}>{s.share}%</span>
                        </div>
                      }
                    </td>
                  </tr>
                ))}
                <tr style={{ background: "var(--surface-2)" }}>
                  <td style={{ fontWeight: 700 }}>Total</td>
                  <td className="tt-cell" style={{ textAlign: "right", fontWeight: 700 }}>1</td>
                  <td className="tt-cell" style={{ textAlign: "right", fontWeight: 700 }}>INR 500.00</td>
                  <td></td>
                  <td></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
