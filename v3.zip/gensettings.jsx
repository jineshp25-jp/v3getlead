/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider */
const { useState, useEffect } = React;

const TABS = [
  { id: "account",  label: "Account",                 icon: "customers" },
  { id: "branches", label: "Branches",                icon: "layers" },
  { id: "entity",   label: "Entity Terminology",      icon: "edit" },
  { id: "datetime", label: "Date & Time Format",      icon: "calendar" },
  { id: "notify",   label: "Notification Preferences", icon: "bell" },
];

function AccountPane() {
  return (
    <div>
      <div className="ls-pane-head"><div><h2>Account Information</h2><div className="ls-pane-sub">View and manage your account details</div></div></div>
      <div className="gs-card">
        <div className="gs-field-row">
          <div className="gs-field">
            <label>Account Name</label>
            <input defaultValue="KTX GLOBAL" />
          </div>
          <div className="gs-field">
            <label>Timezone</label>
            <input defaultValue="Asia/Kolkata" readOnly />
          </div>
        </div>
        <div className="gs-field-row">
          <div className="gs-field">
            <label>Currency</label>
            <input defaultValue="INR" readOnly />
          </div>
          <div className="gs-field">
            <label>Locale</label>
            <input defaultValue="en" readOnly />
          </div>
        </div>
        <div className="gs-actions">
          <button className="btn-save">Save Changes</button>
        </div>
      </div>
    </div>
  );
}

function BranchesPane() {
  const branches = [
    { name: "Default", currency: "INR", created: "19/04/2026" },
    { name: "Test Deail", currency: "USD", created: "19/05/2026" },
  ];
  return (
    <div>
      <div className="ls-pane-head"><div><h2>Branches</h2></div><div className="ls-actions"><button className="btn-primary"><Icon name="plus" className="" size={14} />Add Branch</button></div></div>
      <table className="gs-branches-table">
        <thead><tr><th>Name</th><th>Currency</th><th>Created</th><th style={{ width: 40 }}></th></tr></thead>
        <tbody>
          {branches.map((b, i) => (
            <tr key={i}>
              <td style={{ fontWeight: 600 }}>{b.name}</td>
              <td><span className="tag-soft">{b.currency}</span></td>
              <td style={{ color: "var(--text-2)", fontVariantNumeric: "tabular-nums" }}>{b.created}</td>
              <td>
                <button className="ls-icon-btn">
                  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="5" r="1.3" fill="currentColor"/><circle cx="12" cy="12" r="1.3" fill="currentColor"/><circle cx="12" cy="19" r="1.3" fill="currentColor"/></svg>
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function EntityPane() {
  return (
    <div>
      <div className="ls-pane-head"><div><h2>Entity Terminology</h2><div className="ls-pane-sub">Customize how entities are named throughout your CRM to match your industry-specific terminology.</div></div></div>

      <div className="gs-card">
        <div className="entity-section">
          <h3>Lead Management</h3>
          <div className="sub">Customize names for leads (e.g., "Patient", "Student", "Prospect")</div>
          <div className="gs-field-row">
            <div className="gs-field"><label>Singular</label><input defaultValue="Lead" /></div>
            <div className="gs-field"><label>Plural</label><input defaultValue="Leads" /></div>
          </div>
        </div>

        <div className="entity-section">
          <h3>Deal Management</h3>
          <div className="sub">Customize names for deals (e.g., "Appointment", "Booking", "Sale")</div>
          <div className="gs-field-row">
            <div className="gs-field"><label>Singular</label><input defaultValue="Deal" /></div>
            <div className="gs-field"><label>Plural</label><input defaultValue="Deals" /></div>
          </div>
        </div>

        <div className="entity-section" style={{ marginBottom: 0 }}>
          <h3>Task Management</h3>
          <div className="sub">Customize names for tasks (e.g., "Activity", "Action Item", "To-Do")</div>
          <div className="gs-field-row" style={{ marginBottom: 0 }}>
            <div className="gs-field"><label>Singular</label><input defaultValue="Task" /></div>
            <div className="gs-field"><label>Plural</label><input defaultValue="Tasks" /></div>
          </div>
        </div>

        <div className="gs-actions" style={{ borderTop: "1px solid var(--border)", paddingTop: 16, marginTop: 14 }}>
          <button className="btn-reset">Reset to Defaults</button>
          <button className="btn-save dirty">Save Changes</button>
        </div>
      </div>
    </div>
  );
}

function RadioCard({ on, title, meta, onClick }) {
  return (
    <div className={`gs-radio-card ${on ? "on" : ""}`} onClick={onClick}>
      <div className="gs-radio-dot"></div>
      <div className="gs-radio-body">
        <div className="gs-radio-title">{title}</div>
        {meta && <div className="gs-radio-meta">{meta}</div>}
      </div>
    </div>
  );
}

function DateTimePane() {
  const [dateFmt, setDateFmt] = useState("dmy");
  const [timeFmt, setTimeFmt] = useState("12h");
  const [rel, setRel] = useState("7d");
  return (
    <div>
      <div className="ls-pane-head"><div><h2>Date &amp; Time Format</h2><div className="ls-pane-sub">Pick how dates and times are displayed across the application. The preference applies to every member of this business.</div></div></div>

      <div className="gs-card">
        <div className="gs-card-head">
          <h3>Date format</h3>
          <div className="sub">Used wherever a date is displayed.</div>
        </div>
        <div className="gs-radio-grid">
          <RadioCard on={dateFmt === "short"} title="Short month name"      meta="12 Apr 2026" onClick={() => setDateFmt("short")} />
          <RadioCard on={dateFmt === "dmy"}   title="Day / Month / Year"    meta="12/04/2026"  onClick={() => setDateFmt("dmy")} />
          <RadioCard on={dateFmt === "mdy"}   title="Month / Day / Year (US)" meta="04/12/2026" onClick={() => setDateFmt("mdy")} />
          <RadioCard on={dateFmt === "iso"}   title="ISO (Year-Month-Day)"  meta="2026-04-12"  onClick={() => setDateFmt("iso")} />
        </div>

        <div className="gs-card-head" style={{ marginTop: 8 }}>
          <h3>Time format</h3>
          <div className="sub">Used wherever a time is displayed.</div>
        </div>
        <div className="gs-radio-grid">
          <RadioCard on={timeFmt === "12h"} title="12-hour clock" meta="3:45 pm" onClick={() => setTimeFmt("12h")} />
          <RadioCard on={timeFmt === "24h"} title="24-hour clock" meta="15:45"   onClick={() => setTimeFmt("24h")} />
        </div>

        <div className="gs-card-head" style={{ marginTop: 8 }}>
          <h3>Relative time</h3>
          <div className="sub">Show recent dates as "2 hours ago" up to the chosen threshold, then fall back to the absolute date format above. Hovering over any date always reveals the full timestamp.</div>
        </div>
        <div className="gs-radio-grid">
          <RadioCard on={rel === "always"} title="Always relative" meta='Show "2 hours ago", "3 weeks ago" for every date.' onClick={() => setRel("always")} />
          <RadioCard on={rel === "1d"}     title="Up to 1 day"     meta="Relative for under 1 day, then absolute."          onClick={() => setRel("1d")} />
          <RadioCard on={rel === "7d"}     title="Up to 7 days"    meta="Relative for under 7 days, then absolute."         onClick={() => setRel("7d")} />
          <RadioCard on={rel === "30d"}    title="Up to 30 days"   meta="Relative for under 30 days, then absolute."        onClick={() => setRel("30d")} />
          <RadioCard on={rel === "never"}  title="Always absolute" meta="Never show relative time — always show the full date." onClick={() => setRel("never")} />
        </div>

        <div className="gs-preview">
          <div style={{ gridColumn: "1 / -1" }}><h4>Live preview</h4></div>
          <div className="gs-preview-col"><div className="lbl">Date</div><div className="val">19/05/2026</div></div>
          <div className="gs-preview-col"><div className="lbl">Time</div><div className="val">5:38 pm</div></div>
          <div className="gs-preview-col"><div className="lbl">Date &amp; Time</div><div className="val">19/05/2026, 5:38 pm</div></div>
        </div>

        <div className="gs-actions">
          <button className="btn-save">Save Changes</button>
        </div>
      </div>
    </div>
  );
}

function Toggle({ on, onChange }) {
  return (
    <button type="button" role="switch" aria-checked={on}
      className={`ls-switch ${on ? "on" : ""}`}
      onClick={() => onChange(!on)}>
      <span className="ls-switch-thumb"></span>
    </button>
  );
}

function NotifyPane() {
  const [web, setWeb] = useState(true);
  const [push, setPush] = useState(true);
  const [leadRe, setLeadRe] = useState(true);
  const [taskAssign, setTaskAssign] = useState(true);
  const [taskDue, setTaskDue] = useState(true);
  const [dealStat, setDealStat] = useState(true);
  const [dealAssign, setDealAssign] = useState(true);
  const [sys, setSys] = useState(true);
  const [quiet, setQuiet] = useState(false);
  return (
    <div>
      <div className="ls-pane-head"><div><h2>Notification Preferences</h2><div className="ls-pane-sub">Manage how and when you receive notifications</div></div></div>

      <div className="notif-section">
        <div className="notif-section-head">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
          <div><h3>Notification Channels</h3><div className="sub">Choose how you want to receive notifications</div></div>
        </div>
        <div className="notif-row">
          <span className="notif-ico"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg></span>
          <div className="notif-body"><div className="notif-title">Web Notifications</div><div className="notif-meta">Receive notifications in the browser</div></div>
          <Toggle on={web} onChange={setWeb} />
        </div>
        <div className="notif-row">
          <span className="notif-ico"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/></svg></span>
          <div className="notif-body"><div className="notif-title">Push Notifications</div><div className="notif-meta">Receive push notifications on your mobile device</div></div>
          <Toggle on={push} onChange={setPush} />
        </div>
      </div>

      <div className="notif-section">
        <h3 style={{ margin: 0, fontSize: 14, fontWeight: 700, color: "var(--text-1)" }}>Lead Notifications</h3>
        <div className="sub" style={{ fontSize: 12, color: "var(--text-2)", marginTop: 2, marginBottom: 4 }}>Customize which lead notifications you receive</div>
        <div className="notif-row" style={{ gridTemplateColumns: "1fr auto" }}>
          <div className="notif-title">Lead Recontacted</div>
          <Toggle on={leadRe} onChange={setLeadRe} />
        </div>
      </div>

      <div className="notif-section">
        <h3 style={{ margin: 0, fontSize: 14, fontWeight: 700, color: "var(--text-1)" }}>Task Notifications</h3>
        <div className="sub" style={{ fontSize: 12, color: "var(--text-2)", marginTop: 2, marginBottom: 4 }}>Customize which task notifications you receive</div>
        <div className="notif-row" style={{ gridTemplateColumns: "1fr auto" }}>
          <div className="notif-title">Task Assigned</div><Toggle on={taskAssign} onChange={setTaskAssign} />
        </div>
        <div className="notif-row" style={{ gridTemplateColumns: "1fr auto" }}>
          <div className="notif-title">Task Due Soon</div><Toggle on={taskDue} onChange={setTaskDue} />
        </div>
      </div>

      <div className="notif-section">
        <h3 style={{ margin: 0, fontSize: 14, fontWeight: 700, color: "var(--text-1)" }}>Deal Notifications</h3>
        <div className="sub" style={{ fontSize: 12, color: "var(--text-2)", marginTop: 2, marginBottom: 4 }}>Customize which deal notifications you receive</div>
        <div className="notif-row" style={{ gridTemplateColumns: "1fr auto" }}>
          <div className="notif-title">Deal Status Changed</div><Toggle on={dealStat} onChange={setDealStat} />
        </div>
        <div className="notif-row" style={{ gridTemplateColumns: "1fr auto" }}>
          <div className="notif-title">Deal Assigned</div><Toggle on={dealAssign} onChange={setDealAssign} />
        </div>
      </div>

      <div className="notif-section">
        <h3 style={{ margin: 0, fontSize: 14, fontWeight: 700, color: "var(--text-1)" }}>System Notifications</h3>
        <div className="sub" style={{ fontSize: 12, color: "var(--text-2)", marginTop: 2, marginBottom: 4 }}>Customize which system notifications you receive</div>
        <div className="notif-row" style={{ gridTemplateColumns: "1fr auto" }}>
          <div><div className="notif-title">System Announcement</div><div className="notif-meta">This notification cannot be disabled</div></div>
          <Toggle on={sys} onChange={() => {}} />
        </div>
      </div>

      <div className="notif-section">
        <div className="notif-section-head">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
          <div><h3>Quiet Hours</h3><div className="sub">Set a time range when you don't want to receive notifications</div></div>
        </div>
        <div className="notif-row" style={{ gridTemplateColumns: "1fr auto" }}>
          <div><div className="notif-title">Enable Quiet Hours</div><div className="notif-meta">Pause notifications during specific hours</div></div>
          <Toggle on={quiet} onChange={setQuiet} />
        </div>
      </div>

      <div className="gs-bottom-actions">
        <button className="btn-reset">Reset</button>
        <button className="btn-save">Save Changes</button>
      </div>
    </div>
  );
}

const PANES = { account: AccountPane, branches: BranchesPane, entity: EntityPane, datetime: DateTimePane, notify: NotifyPane };

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [tab, setTab] = useState(() => {
    const p = new URLSearchParams(window.location.search).get("tab") || window.__gsTab;
    return TABS.find(x => x.id === p)?.id || "account";
  });

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale}%`; }, [tweaks.fontScale]);

  const Pane = PANES[tab] || AccountPane;

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="settings" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="General Settings"
          subtitle="Configure general settings for your business"
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
        />
        <div className="content">
          <div className="ls-layout">
            <aside className="ls-side">
              <h3>General Settings</h3>
              <div className="ls-side-list">
                {TABS.map((t) => (
                  <button key={t.id} className={`ls-side-item ${tab === t.id ? "active" : ""}`} onClick={() => setTab(t.id)}>
                    <Icon name={t.icon} className="" />
                    <span>{t.label}</span>
                  </button>
                ))}
              </div>
            </aside>
            <section className="ls-pane">
              <Pane />
            </section>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
