/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakToggle, TweakSlider */
const { useState, useEffect, useMemo } = React;

const DEALS = [
  { id: "DL-2026-00001", name: "Deal dashboard Testing", sub: "Testing deal listing page",
    lead: "JineeshJp", amount: "₹500.00", branch: "Default", type: "General",
    status: "new", assignee: "Arya", close: "14/05/2026, 5:30 am" },
  { id: "DL-2026-00002", name: "Enterprise CRM rollout", sub: "Onboarding kit — 50 seats",
    lead: "Acme Corp", amount: "₹4,80,000", branch: "Mumbai", type: "Subscription",
    status: "progress", assignee: "Priya M.", close: "22/05/2026, 6:00 pm" },
  { id: "DL-2026-00003", name: "Annual support renewal", sub: "Tier-2 support, 12 months",
    lead: "Sara K.", amount: "₹1,20,000", branch: "Bangalore", type: "Renewal",
    status: "negotiation", assignee: "Raj P.", close: "30/05/2026, 11:00 am" },
  { id: "DL-2026-00004", name: "Telecalling addon — Q2", sub: "Outbound dialer + 5 lines",
    lead: "Lina Ali", amount: "₹68,500", branch: "Dubai", type: "Addon",
    status: "won", assignee: "Arya", close: "09/05/2026, 4:00 pm" },
  { id: "DL-2026-00005", name: "Migration: legacy CRM", sub: "Data migration + training",
    lead: "Ajith", amount: "₹2,15,000", branch: "Kochi", type: "Services",
    status: "progress", assignee: "Karan S.", close: "12/06/2026, 10:00 am" },
  { id: "DL-2026-00006", name: "Pilot — 10 user trial", sub: "30 day pilot conversion",
    lead: "Priya M.", amount: "₹0.00", branch: "Default", type: "Pilot",
    status: "new", assignee: "Arya", close: "18/05/2026, 2:30 pm" },
  { id: "DL-2026-00007", name: "Campaign management bundle", sub: "SMS + Email + WhatsApp",
    lead: "Raj Patel", amount: "₹3,40,000", branch: "Default", type: "Bundle",
    status: "lost", assignee: "Karan S.", close: "01/05/2026, 9:00 am" },
];

const STATUS_LABEL = {
  new: "New",
  progress: "In Progress",
  negotiation: "Negotiation",
  won: "Won",
  lost: "Lost" };

function StatusPill({ status }) {
  return <span className={`status-pill status-${status}`}>{STATUS_LABEL[status]}</span>;
}

function ChevDown() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>;
}

function RowMenu() {
  const [open, setOpen] = useState(false);
  const ref = React.useRef(null);
  useEffect(() => {
    if (!open) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  const items = [
    { id: "view",   label: "View Deal",   icon: "eye" },
    { id: "delete", label: "Delete Deal", icon: "trash", danger: true },
  ];

  return (
    <div className="row-menu-wrap" ref={ref}>
      <button
        className={`row-action ${open ? "active" : ""}`}
        onClick={(e) => { e.stopPropagation(); setOpen(o => !o); }}
        aria-label="More"
      >
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="5" r="1.3" fill="currentColor"/>
          <circle cx="12" cy="12" r="1.3" fill="currentColor"/>
          <circle cx="12" cy="19" r="1.3" fill="currentColor"/>
        </svg>
      </button>
      {open && (
        <div className="hdr-menu row-menu" role="menu" onClick={(e) => e.stopPropagation()}>
          {items.map((it) => (
            <button
              key={it.id}
              role="menuitem"
              className={`hdr-menu-item ${it.danger ? "danger" : ""}`}
              onClick={() => setOpen(false)}
            >
              <Icon name={it.icon} className="" size={16} />
              <span>{it.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function CreateDealModal({ open, onClose }) {
  const [currency, setCurrency] = useState("INR");
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" role="dialog" aria-labelledby="modal-title" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <div>
            <h2 id="modal-title" className="modal-title">Create Deal</h2>
            <div className="modal-sub">Add a new deal to your pipeline</div>
          </div>
          <button className="modal-close" aria-label="Close" onClick={onClose}>
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 6-12 12M6 6l12 12"/></svg>
          </button>
        </div>

        <div className="modal-body">
          <div className="field">
            <label className="field-label">Deal Name <span className="req">*</span></label>
            <input className="field-input" placeholder="e.g., Website Redesign Project" />
          </div>

          <div className="field-row">
            <div className="field">
              <label className="field-label">Lead <span className="req">*</span></label>
              <div className="field-search">
                <Icon name="search" className="" />
                <input className="field-input" placeholder="Search by name, phone, or email…" />
              </div>
            </div>
            <div className="field">
              <label className="field-label">Branch <span className="req">*</span></label>
              <select className="field-select" defaultValue="">
                <option value="" disabled>Select branch</option>
                <option>Default</option><option>Mumbai</option><option>Bangalore</option><option>Dubai</option><option>Kochi</option>
              </select>
            </div>
          </div>

          <div className="field-row">
            <div className="field">
              <label className="field-label">Type <span className="req">*</span></label>
              <select className="field-select" defaultValue="">
                <option value="" disabled>Select type</option>
                <option>General</option><option>Subscription</option><option>Renewal</option><option>Pilot</option><option>Bundle</option>
              </select>
            </div>
            <div className="field">
              <label className="field-label">Status <span className="req">*</span></label>
              <select className="field-select" defaultValue="">
                <option value="" disabled>Select status</option>
                <option>New</option><option>In Progress</option><option>Negotiation</option><option>Won</option><option>Lost</option>
              </select>
            </div>
          </div>

          <div className="field">
            <label className="field-label">Assigned Agent <span className="req">*</span></label>
            <select className="field-select" defaultValue="">
              <option value="" disabled>Select agent</option>
              <option>Arya</option><option>Priya M.</option><option>Raj P.</option><option>Karan S.</option>
            </select>
          </div>

          <div className="field">
            <label className="field-label">Amount <span className="req">*</span></label>
            <div className="field-amount">
              <select className="field-currency" value={currency} onChange={(e) => setCurrency(e.target.value)}>
                <option value="INR">₹</option>
                <option value="USD">$</option>
                <option value="EUR">€</option>
                <option value="AED">د.إ</option>
              </select>
              <input className="field-input" placeholder="100.50" />
            </div>
          </div>

          <div className="field">
            <label className="field-label">Expected Close Date</label>
            <div className="field-date">
              <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>
              <input className="field-input" placeholder="Pick a date" />
            </div>
          </div>

          <div className="field">
            <label className="field-label">Notes</label>
            <textarea className="field-textarea" placeholder="Add any additional notes…"></textarea>
          </div>
        </div>

        <div className="modal-foot">
          <button className="btn-cancel" onClick={onClose}>Cancel</button>
          <button className="btn-primary">Create Deal</button>
        </div>
      </div>
    </div>
  );
}

function DealsToolbar() {
  return (
    <div className="leads-toolbar">
      <div className="leads-search deals-toolbar-inner">
        <Icon name="search" className="" />
        <input placeholder="Search by deal name…" />
      </div>

      <button className="toolbar-btn">
        <Icon name="columns" className="" />
        <span>Columns</span>
      </button>

      <button className="toolbar-btn">
        <Icon name="filter" className="" />
        <span>Advanced Filters</span>
        <span className="nudge">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="10" height="10"><path d="m15 18-6-6 6-6"/></svg>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="10" height="10"><path d="m9 18 6-6-6-6"/></svg>
        </span>
      </button>
    </div>
  );
}

function Avatar({ name }) {
  const initials = name.split(" ").map(s => s[0]).slice(0, 2).join("");
  return <span className="avatar-sm">{initials}</span>;
}

function DealsTable() {
  return (
    <div className="leads-table-wrap">
      <table className="leads-table">
        <thead>
          <tr>
            <th><span className="th-inner">Deal # <ChevDown /></span></th>
            <th><span className="th-inner">Name <ChevDown /></span></th>
            <th><span className="th-inner">Lead <ChevDown /></span></th>
            <th><span className="th-inner">Amount <ChevDown /></span></th>
            <th><span className="th-inner">Branch <ChevDown /></span></th>
            <th><span className="th-inner">Type <ChevDown /></span></th>
            <th><span className="th-inner">Status <ChevDown /></span></th>
            <th><span className="th-inner">Assigned To <ChevDown /></span></th>
            <th><span className="th-inner">Expected Close <ChevDown /></span></th>
            <th className="col-actions"></th>
          </tr>
        </thead>
        <tbody>
          {DEALS.map((d) => (
            <tr key={d.id}>
              <td><span className="deal-id">{d.id}</span></td>
              <td>
                <div className="lead-name">{d.name}</div>
                {d.sub && <div className="lead-sub">{d.sub}</div>}
              </td>
              <td><span className="lead-name" style={{ fontWeight: 500 }}>{d.lead}</span></td>
              <td><span className="amount-cell">{d.amount}</span></td>
              <td><span className="tag">{d.branch}</span></td>
              <td><span className="tag">{d.type}</span></td>
              <td><StatusPill status={d.status} /></td>
              <td>
                <span className="assignee">
                  <Avatar name={d.assignee} />
                  <span className="nm">{d.assignee}</span>
                </span>
              </td>
              <td>
                <span className="expected-close">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>
                  {d.close}
                </span>
              </td>
              <td className="col-actions"><RowMenu /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "theme": "dark",
    "accent": "#ef3b3b",
    "fontScale": 100
  }/*EDITMODE-END*/);

  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  const totalCount = DEALS.length;
  const totalAmount = "₹12,03,500";

  const headerActions = (
    <>
      <button className="btn-secondary">
        <Icon name="download" className="" size={14} />
        Export
      </button>
      <button className="btn-primary" onClick={() => setCreateOpen(true)}>
        <Icon name="plus" className="" size={14} />
        Create Deal
      </button>
    </>
  );

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="deals" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar title="Deals" theme={tweaks.theme} setTheme={(v) => setTweak("theme", v)} actions={headerActions} />
        <div className="content">
          <div className="deals-summary">
            <div className="deal-summary-card">
              <div className="kpi-top">
                <div className="kpi-icon" style={{
                  background: "color-mix(in srgb, #3b82f6 18%, transparent)",
                  color: "#3b82f6",
                  boxShadow: "inset 0 0 0 1px color-mix(in srgb, #3b82f6 30%, transparent)" }}>
                  <Icon name="deals" className="" size={20} />
                </div>
                <span className="kpi-label">Total deals count</span>
              </div>
              <div className="kpi-val">{totalCount}</div>
              <div className="kpi-sub up"><span className="kpi-arrow">▲</span>+2 added this week</div>
            </div>
            <div className="deal-summary-card accent-green">
              <div className="kpi-top">
                <div className="kpi-icon" style={{
                  background: "color-mix(in srgb, #22c55e 18%, transparent)",
                  color: "#22c55e",
                  boxShadow: "inset 0 0 0 1px color-mix(in srgb, #22c55e 30%, transparent)" }}>
                  <Icon name="wallet" className="" size={20} />
                </div>
                <span className="kpi-label">Total deals amount</span>
              </div>
              <div className="kpi-val">{totalAmount}</div>
              <div className="kpi-sub up"><span className="kpi-arrow">▲</span>+8.1% vs last month</div>
            </div>
          </div>

          <div>
            <DealsToolbar />
            <DealsTable />
          </div>
        </div>
      </main>

      <CreateDealModal open={createOpen} onClose={() => setCreateOpen(false)} />

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio
          label="Mode"
          value={tweaks.theme}
          options={["dark", "light"]}
          onChange={(v) => setTweak("theme", v)}
        />
        <TweakColor
          label="Accent"
          value={tweaks.accent}
          options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]}
          onChange={(v) => setTweak("accent", v)}
        />
        <TweakSection label="Display" />
        <TweakSlider
          label="Font scale"
          value={tweaks.fontScale}
          min={85} max={115} step={5} unit="%"
          onChange={(v) => setTweak("fontScale", v)}
        />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
