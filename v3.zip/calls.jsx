/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, ChevDown, FilterPill, ScheduledContent, StatusContent, AssignedContent, MoreContent */
const { useState, useEffect } = React;

const KPIS = [
  { num: "24,551", lbl: "Total",     accent: "blue",   color: "#3b82f6", icon: "phone" },
  { num: "21,784", lbl: "Completed", accent: "green",  color: "#22c55e", icon: "check-circle" },
  { num: "2,767",  lbl: "Pending",   accent: "yellow", color: "#eab308", icon: "clock" },
  { num: "2,694",  lbl: "OverDue",   accent: "red",    color: "#ef4444", icon: "alert" },
  { num: "10,096", lbl: "Connected", accent: "cyan",   color: "#22d3ee", icon: "phone-call" },
];

const CALLS = [
  { lead: "SUBASH NAIR",     title: "Follow Up - SUBASH NAIR",     assignedBy: "Muhammed Nihad", assignedTo: "Muhammed Nihad", created: "15/05/2026, 5:51 pm", scheduled: "22/05/2026, 5:51 pm" },
  { lead: "SAFEER P",        title: "Follow Up - SAFEER P",        assignedBy: "Muhammed Nihad", assignedTo: "Muhammed Nihad", created: "15/05/2026, 5:47 pm", scheduled: "22/05/2026, 5:47 pm" },
  { lead: "SHEEJA N",        title: "Follow Up - SHEEJA N",        assignedBy: "Muhammed Nihad", assignedTo: "Muhammed Nihad", created: "15/05/2026, 5:45 pm", scheduled: "22/05/2026, 5:45 pm" },
  { lead: "Shameel Babu K",  title: "Follow Up - Shameel Babu K",  assignedBy: "Muhammed Nihad", assignedTo: "Muhammed Nihad", created: "15/05/2026, 5:43 pm", scheduled: "22/05/2026, 5:43 pm" },
  { lead: "RANVEER PV",      title: "Follow Up - RANVEER PV",      assignedBy: "Muhammed Nihad", assignedTo: "Muhammed Nihad", created: "15/05/2026, 5:38 pm", scheduled: "22/05/2026, 5:38 pm" },
  { lead: "PRADEESH MARATH", title: "Follow Up - PRADEESH MARA…",  assignedBy: "Muhammed Nihad", assignedTo: "Muhammed Nihad", created: "15/05/2026, 5:34 pm", scheduled: "22/05/2026, 5:34 pm" },
  { lead: "Harshad",         title: "Follow Up - Harshad",         assignedBy: "Muhammed Nihad", assignedTo: "Muhammed Nihad", created: "15/05/2026, 5:27 pm", scheduled: "22/05/2026, 5:27 pm" },
  { lead: "Ashif Muhammed",  title: "Follow Up - Ashif Muhammed",  assignedBy: "Muhammed Nihad", assignedTo: "Muhammed Nihad", created: "15/05/2026, 5:26 pm", scheduled: "22/05/2026, 5:25 pm" },
  { lead: "Muhammed Firos",  title: "Follow Up - Muhammed Firos",  assignedBy: "Fathima rana kp", assignedTo: "Fathima rana kp", created: "15/05/2026, 5:23 pm", scheduled: "22/05/2026, 5:21 pm" },
  { lead: "Praseeth MA",     title: "Follow Up - Praseeth MA",     assignedBy: "Muhammed Nihad", assignedTo: "Muhammed Nihad", created: "15/05/2026, 5:19 pm", scheduled: "22/05/2026, 5:19 pm" },
  { lead: "Ajith Suresh",    title: "Follow Up - Ajith Suresh",    assignedBy: "Fathima rana kp", assignedTo: "Fathima rana kp", created: "15/05/2026, 5:15 pm", scheduled: "22/05/2026, 5:15 pm" },
  { lead: "Mohamed sabith p.s", title: "Follow Up - Mohamed sabith p.s", assignedBy: "Muhammed Nihad", assignedTo: "Muhammed Nihad", created: "15/05/2026, 5:13 pm", scheduled: "22/05/2026, 5:12 pm" },
];

function Avatar({ name }) {
  const initials = name.split(" ").map(s => s[0]).slice(0, 2).join("");
  return <span className="avatar-sm">{initials}</span>;
}

function CallsToolbar({ pageSize, setPageSize, campaignOnly, setCampaignOnly, filters, setFilter, openPop, setOpenPop }) {
  return (
    <>
      <div className="calls-toolbar calls-toolbar-merged">
        <div className="calls-search">
          <Icon name="search" className="" />
          <input placeholder="Search by task name, lead…" />
        </div>
        <label className="calls-checkbox">
          <input type="checkbox" className="cbx" checked={campaignOnly} onChange={(e) => setCampaignOnly(e.target.checked)} />
          Campaign Tasks Only
        </label>
        <select className="per-page-select" value={pageSize} onChange={(e) => setPageSize(Number(e.target.value))}>
          <option>15</option>
          <option>25</option>
          <option>50</option>
          <option>100</option>
        </select>
        <FilterPill
          label="Scheduled"
          value={filters.scheduled}
          open={openPop === "sched"}
          onToggle={(o) => setOpenPop(o ? "sched" : null)}
        >
          <ScheduledContent value={filters.scheduled} onChange={(v) => { setFilter("scheduled", v); setOpenPop(null); }} />
        </FilterPill>
        <FilterPill
          label="Status"
          value={filters.status}
          open={openPop === "status"}
          onToggle={(o) => setOpenPop(o ? "status" : null)}
        >
          <StatusContent value={filters.status} onChange={(v) => { setFilter("status", v); setOpenPop(null); }} />
        </FilterPill>
        <FilterPill
          label="Assigned To"
          value={filters.assigned}
          open={openPop === "assigned"}
          onToggle={(o) => setOpenPop(o ? "assigned" : null)}
        >
          <AssignedContent value={filters.assigned} onChange={(v) => { setFilter("assigned", v); setOpenPop(null); }} />
        </FilterPill>
        <FilterPill
          label="More"
          value={null}
          open={openPop === "more"}
          onToggle={(o) => setOpenPop(o ? "more" : null)}
        >
          <MoreContent
            groups={[
              { group: "People", items: ["Assigned By"] },
              { group: "Lead",   items: ["Lead Status", "Lead Source"] },
              { group: "Call",   items: ["Call Status", "Campaign"] },
            ]}
            onPick={() => setOpenPop(null)}
          />
        </FilterPill>
      </div>
    </>
  );
}

function CallsTable() {
  return (
    <div className="calls-table-wrap">
      <table className="leads-table">
        <thead>
          <tr>
            <th className="col-check"><input type="checkbox" className="cbx" /></th>
            <th><span className="th-inner">Lead <ChevDown /></span></th>
            <th><span className="th-inner">Title <ChevDown /></span></th>
            <th><span className="th-inner">Details <ChevDown /></span></th>
            <th><span className="th-inner">Assigned By <ChevDown /></span></th>
            <th><span className="th-inner">Assigned To <ChevDown /></span></th>
            <th><span className="th-inner">Status <ChevDown /></span></th>
            <th><span className="th-inner">Call Status <ChevDown /></span></th>
            <th><span className="th-inner">Created At <ChevDown /></span></th>
            <th><span className="th-inner">Scheduled At <ChevDown /></span></th>
          </tr>
        </thead>
        <tbody>
          {CALLS.map((c, i) => (
            <tr key={i}>
              <td className="col-check"><input type="checkbox" className="cbx" onClick={(e) => e.stopPropagation()} /></td>
              <td><span className="calls-lead">{c.lead}</span></td>
              <td><span className="lead-name" style={{ fontWeight: 500 }}>{c.title}</span></td>
              <td><span className="dash">–</span></td>
              <td>
                <span className="assigned-name">
                  <Avatar name={c.assignedBy} />
                  {c.assignedBy}
                </span>
              </td>
              <td>
                <span className="assigned-name">
                  <Avatar name={c.assignedTo} />
                  {c.assignedTo}
                </span>
              </td>
              <td><span className="status-open">Open</span></td>
              <td><span className="dash">–</span></td>
              <td><span className="time-cell">{c.created}</span></td>
              <td><span className="time-cell">{c.scheduled}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [pageSize, setPageSize] = useState(15);
  const [campaignOnly, setCampaignOnly] = useState(false);
  const [filters, setFilters] = useState({ scheduled: null, status: null, assigned: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "theme": "dark",
    "accent": "#ef3b3b",
    "fontScale": 100
  }/*EDITMODE-END*/);

  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  const headerActions = (
    <>
      <button className="btn-import">
        <Icon name="upload" className="" />
        Import
      </button>
      <button className="btn-export">
        <Icon name="download" className="" />
        Export
      </button>
      <button className="btn-start">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92V20a2 2 0 0 1-2.18 2A19.86 19.86 0 0 1 2 4.18 2 2 0 0 1 4 2h3.09a1 1 0 0 1 1 .75l1 4a1 1 0 0 1-.27 1L7.21 9.21a16 16 0 0 0 7.58 7.58l1.46-1.46a1 1 0 0 1 1-.27l4 1a1 1 0 0 1 .75 1z"/></svg>
        Start
      </button>
    </>
  );

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="tasks-call" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Calls"
          subtitle="Manage and track your call tasks"
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={headerActions}
        />
        <div className="content">
          <div className="calls-kpi-grid">
            {KPIS.map((k, i) => (
              <div key={i} className={`calls-kpi accent-${k.accent}`}>
                <div className="calls-kpi-icon" style={{
                  background: `color-mix(in srgb, ${k.color} 18%, transparent)`,
                  color: k.color,
                  boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${k.color} 30%, transparent)` }}>
                  <Icon name={k.icon} className="" size={18} />
                </div>
                <div className="num" style={{ color: k.color }}>{k.num}</div>
                <div className="lbl">{k.lbl}</div>
              </div>
            ))}
          </div>

          <div>
            <CallsToolbar
              pageSize={pageSize}
              setPageSize={setPageSize}
              campaignOnly={campaignOnly}
              setCampaignOnly={setCampaignOnly}
              filters={filters}
              setFilter={setFilter}
              openPop={openPop}
              setOpenPop={setOpenPop}
            />
            <CallsTable />
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio
          label="Mode"
          value={tweaks.theme}
          options={["dark", "light"]}
          onChange={(v) => setTweak("theme", v)}
        />
        <TweakColor
          label="Accent"
          value={tweaks.accent}
          options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]}
          onChange={(v) => setTweak("accent", v)}
        />
        <TweakSection label="Display" />
        <TweakSlider
          label="Font scale"
          value={tweaks.fontScale}
          min={85} max={115} step={5} unit="%"
          onChange={(v) => setTweak("fontScale", v)}
        />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
