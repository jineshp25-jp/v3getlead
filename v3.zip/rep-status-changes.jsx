/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, ScheduledContent, AssignedContent */
const { useState, useEffect } = React;

// ─── Helpers
function pillClass(status) {
  const map = {
    "New": "pill-blue", "Attempt 1": "pill-blue", "Attempt 2": "pill-blue", "Attempt 3": "pill-blue", "Spam": "pill-blue",
    "will purchase": "pill-blue", "incoming call not supported": "pill-blue", "Just Check": "pill-blue",
    "Will let you know": "pill-green",
    "Attempted To Purchase": "pill-green", "Purchased": "pill-green",
    "Contacted": "pill-purple",
    "Not attended": "pill-red", "Not Interested": "pill-red" };
  return map[status] || "pill-blue";
}

const TRANSITIONS = [
  { from: "Attempt 1", to: "New", v: 8200 },
  { from: "Just Check", to: "New", v: 6500 },
  { from: "Spam", to: "New", v: 5200 },
  { from: "will purchase", to: "New", v: 4400 },
  { from: "Will let you know", to: "Will let you know", v: 3600 },
  { from: "Attempted To Purchase", to: "New", v: 2900 },
  { from: "Purchased", to: "New", v: 2400 },
  { from: "Not attended", to: "Not attended", v: 1900, cls: "red" },
  { from: "Not attended", to: "Contacted", v: 1500, cls: "purple" },
  { from: "incoming call not supported", to: "New", v: 1100 },
];

const HISTORY = [
  { date: "18/05/2026", lead: "Ar. ASWINI MANOJ",        from: "New", to: "Not attended",            dur: "Ongoing", agent: "Nasiha" },
  { date: "18/05/2026", lead: "SALEEL SALEEM K",          from: "New", to: "Not Interested",          dur: "Ongoing", agent: "Nasiha" },
  { date: "18/05/2026", lead: "Midhun Mohandas",          from: "New", to: "Contacted",               dur: "Ongoing", agent: "Nasiha" },
  { date: "18/05/2026", lead: "SHAJIN MOHAMED",           from: "New", to: "Contacted",               dur: "Ongoing", agent: "Nasiha" },
  { date: "18/05/2026", lead: "MUHAMMED MUSTHAFA",        from: "New", to: "Not Interested",          dur: "Ongoing", agent: "Nasiha" },
  { date: "18/05/2026", lead: "Nikhil",                   from: "New", to: "Contacted",               dur: "Ongoing", agent: "Nasiha" },
  { date: "16/05/2026", lead: "FARHAN ALI",                from: "New", to: "Attempt 1",               dur: "Ongoing", agent: "Fahmida" },
  { date: "16/05/2026", lead: "Adarsh Abraham Johnson",   from: "New", to: "Attempt 1",               dur: "Ongoing", agent: "Fahmida" },
  { date: "15/05/2026", lead: "FAROOK KURIKKAL",          from: "New", to: "Will let you know",       dur: "Ongoing", agent: "Shad" },
  { date: "15/05/2026", lead: "RASHEED ALI",              from: "New", to: "incoming call not supported", dur: "Ongoing", agent: "Shad" },
  { date: "15/05/2026", lead: "ABDUL SHABEER",            from: "New", to: "Attempt 1",               dur: "Ongoing", agent: "Shad" },
  { date: "15/05/2026", lead: "MUGESH KUMAR",             from: "New", to: "Not Interested",          dur: "Ongoing", agent: "Shad" },
  { date: "15/05/2026", lead: "FINOB K",                  from: "New", to: "Attempt 1",               dur: "Ongoing", agent: "Shad" },
  { date: "15/05/2026", lead: "Harisuthan Prakash",       from: "New", to: "Not Interested",          dur: "Ongoing", agent: "Shad" },
  { date: "15/05/2026", lead: "SUSMITHA AJITH",           from: "New", to: "Will let you know",       dur: "Ongoing", agent: "Shad" },
];

function Kpi({ icon, label, value, sub, color = "#3b82f6" }) {
  const accentMap = {
    "#ef4444": "accent-red", "#3b82f6": "accent-blue", "#a855f7": "accent-purple",
    "#22c55e": "accent-green", "#eab308": "accent-yellow", "#22d3ee": "accent-cyan",
    "#f97316": "accent-yellow" };
  const accent = accentMap[color] || "accent-blue";
  return (
    <div className={`card kpi ${accent}`}>
      <div className="kpi-top">
        <div className="kpi-icon" style={{
          background: `color-mix(in srgb, ${color} 18%, transparent)`,
          color: color,
          boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${color} 30%, transparent)` }}>
          <Icon name={icon} className="" size={20} />
        </div>
        <span className="kpi-label">{label}</span>
      </div>
      <div className="kpi-val">{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}

function HBarChart() {
  const max = Math.max(...TRANSITIONS.map(t => t.v));
  return (
    <div className="hbar-list">
      {TRANSITIONS.map((t, i) => (
        <div key={i} className="hbar-row">
          <div className="hbar-label">
            <span className={`pill ${pillClass(t.from)} pill-mini`}>{t.from}</span>
            <svg className="arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
            <span className={`pill ${pillClass(t.to)} pill-mini`}>{t.to}</span>
          </div>
          <div className="hbar-track">
            <div className={`hbar-fill ${t.cls || ""}`} style={{ width: `${(t.v / max) * 100}%`, animationDelay: `${i * 40}ms` }} />
          </div>
          <div className="hbar-val">{t.v.toLocaleString()}</div>
        </div>
      ))}
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [filters, setFilters] = useState({ date: "18/04/2026 – 18/05/2026", user: null, source: null, to: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "theme": "dark", "accent": "#ef3b3b", "fontScale": 100
  }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="rep-lead-status-changes" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Lead Status Change Report"
          subtitle="Analyse how leads move between statuses over a selected time period. Use this report to identify bottlenecks, spot recurring patterns, and monitor team activity across your pipeline."
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={<button className="btn-export"><Icon name="download" className="" />Export CSV</button>}
        />
        <div className="content">
          <div className="rep-filters">
            <FilterPill label="Date" value={filters.date} open={openPop==="date"} onToggle={(o)=>setOpenPop(o?"date":null)} onClear={()=>setFilter("date",null)}>
              <ScheduledContent value={filters.date} onChange={(v)=>{setFilter("date",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Assigned User" value={filters.user} open={openPop==="user"} onToggle={(o)=>setOpenPop(o?"user":null)} onClear={()=>setFilter("user",null)}>
              <AssignedContent value={filters.user} onChange={(v)=>{setFilter("user",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Source" value={filters.source} open={openPop==="source"} onToggle={(o)=>setOpenPop(o?"source":null)} onClear={()=>setFilter("source",null)}>
              <AssignedContent value={filters.source} onChange={(v)=>{setFilter("source",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="To Status" value={filters.to} open={openPop==="to"} onToggle={(o)=>setOpenPop(o?"to":null)} onClear={()=>setFilter("to",null)}>
              <AssignedContent value={filters.to} onChange={(v)=>{setFilter("to",v);setOpenPop(null);}} />
            </FilterPill>
          </div>

          <div className="kpi-grid" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
            <Kpi icon="trend-up" color="#ef4444" label="Total Status Changes" value="30,153" sub="Total times any lead changed status in this period" />
            <Kpi icon="users-2"  color="#3b82f6" label="Unique Leads Changed" value="14,331" sub="Distinct leads with at least one status change" />
            <Kpi icon="clock"    color="#a855f7" label="Daily Average"        value="1,005.1" sub="Average status changes per day over the selected period" />
            <Kpi icon="spark"    color="#22c55e" label="Most Common Transition" value={<span style={{display:"inline-flex",gap:6,alignItems:"center"}}><span className="pill pill-blue pill-mini">New</span><svg className="arrow" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg><span className="pill pill-blue pill-mini">New</span></span>} sub="6,444 times · The status transition that occurred most frequently" />
          </div>

          <div className="rep-section">
            <h3>Status Transitions</h3>
            <div className="sub">Breakdown of all status transitions ranked by frequency</div>
            <HBarChart />
          </div>

          <div className="rep-section">
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
              <div>
                <h3>Change History</h3>
                <div className="sub">Each row represents a single lead moving from one status to another. You can see the lead name, the exact transition made, how long the lead spent in the previous status before the change, and who it was assigned to at the time.</div>
              </div>
              <span style={{ fontSize: '13.5px', color: "var(--text-3)", whiteSpace: "nowrap" }}>30,153 changes</span>
            </div>
            <table className="leads-table" style={{ marginTop: 4 }}>
              <thead>
                <tr><th>Date</th><th>Lead</th><th>Transition</th><th>Duration</th><th>Assigned User</th></tr>
              </thead>
              <tbody>
                {HISTORY.map((h, i) => (
                  <tr key={i}>
                    <td className="tt-cell" style={{ color: "var(--text-2)" }}>{h.date}</td>
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <span className="avatar-sm" style={{ background: `hsl(${(h.lead.charCodeAt(0) * 23) % 360}, 70%, 55%)` }}>{h.lead.split(" ").map(s=>s[0]).slice(0,2).join("").toUpperCase()}</span>
                        <span style={{ fontWeight: 600 }}>{h.lead}</span>
                      </div>
                    </td>
                    <td>
                      <span className="transition">
                        <span className={`pill ${pillClass(h.from)} pill-mini`}>{h.from}</span>
                        <svg className="arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
                        <span className={`pill ${pillClass(h.to)} pill-mini`}>{h.to}</span>
                      </span>
                    </td>
                    <td className="tt-cell" style={{ color: "var(--text-2)" }}>
                      <span className="dur-chip"><span className="dur-dot"></span>{h.dur}</span>
                    </td>
                    <td><span className="agent-tag">{h.agent}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="rep-pager">
              <div>Showing 1 to 15 of 30,153 changes</div>
              <div className="rep-pager-right">
                <button className="pager-btn">Previous</button>
                <button className="pager-btn active">1</button>
                <button className="pager-btn">2</button>
                <button className="pager-btn">3</button>
                <button className="pager-btn">4</button>
                <button className="pager-btn">5</button>
                <span className="pager-ellipsis">…</span>
                <button className="pager-btn">2011</button>
                <button className="pager-btn">Next</button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
