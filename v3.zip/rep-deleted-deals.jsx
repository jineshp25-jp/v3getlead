/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, ScheduledContent, AssignedContent */
const { useState, useEffect } = React;

const DEALS = [
  { id: "DL-2026-00018", name: "Deal dashboard Testing", amount: "₹500.00",      lead: "JineeshJp",     branch: "Default",    type: "General",      status: "new",         agent: "Arya",         by: "KTX GLOBAL",  at: "18/05/2026, 12:35 pm" },
  { id: "DL-2026-00012", name: "Enterprise CRM rollout", amount: "₹4,80,000",    lead: "Acme Corp",     branch: "Mumbai",     type: "Subscription", status: "progress",    agent: "Priya M.",     by: "KTX GLOBAL",  at: "16/05/2026, 4:22 pm" },
  { id: "DL-2026-00010", name: "Annual support renewal", amount: "₹1,20,000",    lead: "Sara K.",       branch: "Bangalore",  type: "Renewal",      status: "lost",        agent: "Raj P.",       by: "Fahmida",     at: "14/05/2026, 11:02 am" },
  { id: "DL-2026-00009", name: "Telecalling addon Q1",   amount: "₹68,500",      lead: "Lina Ali",      branch: "Dubai",      type: "Addon",        status: "negotiation", agent: "Arya",         by: "KTX GLOBAL",  at: "12/05/2026, 6:00 pm" },
  { id: "DL-2026-00008", name: "Migration: legacy CRM",  amount: "₹2,15,000",    lead: "Ajith",         branch: "Kochi",      type: "Services",     status: "lost",        agent: "Karan S.",     by: "Fahmida",     at: "10/05/2026, 9:30 am" },
  { id: "DL-2026-00007", name: "Pilot — 10 user trial",  amount: "₹0.00",        lead: "Priya M.",      branch: "Default",    type: "Pilot",        status: "new",         agent: "Arya",         by: "KTX GLOBAL",  at: "09/05/2026, 5:30 am" },
  { id: "DL-2026-00006", name: "Campaign mgmt bundle",   amount: "₹3,40,000",    lead: "Raj Patel",     branch: "Default",    type: "Bundle",       status: "lost",        agent: "Karan S.",     by: "Unknown",     at: "08/05/2026, 5:30 am" },
  { id: "DL-2026-00005", name: "SMS Gateway addon",      amount: "₹22,000",      lead: "Nikhil",        branch: "Default",    type: "Addon",        status: "negotiation", agent: "Karan S.",     by: "KTX GLOBAL",  at: "08/05/2026, 5:30 am" },
  { id: "DL-2026-00004", name: "Outreach onboarding",    amount: "₹15,000",      lead: "Tester",        branch: "Default",    type: "Services",     status: "won",         agent: "Arya",         by: "Fahmida",     at: "07/05/2026, 5:30 am" },
  { id: "DL-2026-00003", name: "Annual subscription",    amount: "₹98,000",      lead: "Harshad",       branch: "Default",    type: "Subscription", status: "lost",        agent: "Priya M.",     by: "Unknown",     at: "06/05/2026, 5:30 am" },
  { id: "DL-2026-00002", name: "Support hours topup",    amount: "₹6,500",       lead: "Sara K.",       branch: "Default",    type: "Addon",        status: "new",         agent: "Raj P.",       by: "KTX GLOBAL",  at: "05/05/2026, 5:30 am" },
  { id: "DL-2026-00001", name: "POC — 5 user trial",     amount: "₹0.00",        lead: "Lina Ali",      branch: "Default",    type: "Pilot",        status: "new",         agent: "Arya",         by: "Unknown",     at: "05/05/2026, 5:30 am" },
];

const STATUS_LABEL = {
  new: "New",
  progress: "In Progress",
  negotiation: "Negotiation",
  won: "Won",
  lost: "Lost" };

function Kpi({ icon, label, value, sub, color = "#3b82f6" }) {
  const accentMap = {
    "#ef4444": "accent-red", "#3b82f6": "accent-blue", "#a855f7": "accent-purple",
    "#22c55e": "accent-green", "#eab308": "accent-yellow", "#22d3ee": "accent-cyan",
    "#f97316": "accent-yellow" };
  const accent = accentMap[color] || "accent-blue";
  return (
    <div className={`card kpi ${accent}`}>
      <div className="kpi-top">
        <div className="kpi-icon" style={{
          background: `color-mix(in srgb, ${color} 18%, transparent)`,
          color: color,
          boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${color} 30%, transparent)` }}>
          <Icon name={icon} className="" size={20} />
        </div>
        <span className="kpi-label">{label}</span>
      </div>
      <div className="kpi-val">{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [q, setQ] = useState("");
  const [filters, setFilters] = useState({ date: "01/05/2026 – 18/05/2026", by: null, status: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="rep-deleted-deals" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title={<span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="var(--brand)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>
            Deleted Deals
          </span>}
          subtitle="All soft-deleted deals across your pipeline. Restore any deal within 30 days, or filter to audit deletions by team member."
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={<button className="btn-export"><Icon name="download" className="" />Export CSV</button>}
        />
        <div className="content">
          <div className="rep-filters">
            <FilterPill label="Date" value={filters.date} open={openPop==="date"} onToggle={(o)=>setOpenPop(o?"date":null)} onClear={()=>setFilter("date",null)}>
              <ScheduledContent value={filters.date} onChange={(v)=>{setFilter("date",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Deleted By" value={filters.by} open={openPop==="by"} onToggle={(o)=>setOpenPop(o?"by":null)} onClear={()=>setFilter("by",null)}>
              <AssignedContent value={filters.by} onChange={(v)=>{setFilter("by",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Status at deletion" value={filters.status} open={openPop==="status"} onToggle={(o)=>setOpenPop(o?"status":null)} onClear={()=>setFilter("status",null)}>
              <AssignedContent value={filters.status} onChange={(v)=>{setFilter("status",v);setOpenPop(null);}} />
            </FilterPill>
          </div>

          <div className="kpi-grid" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
            <Kpi icon="trash"    color="#ef4444" label="Deleted Deals" value="2,403" sub="Soft-deleted, restorable within 30 days" />
            <Kpi icon="wallet"   color="#22c55e" label="Total Value Lost" value="₹4.8M" sub="Sum of amounts on deleted deals" />
            <Kpi icon="clock"    color="#a855f7" label="This Month" value="38" sub="Deleted in the selected period" />
            <Kpi icon="users-2"  color="#3b82f6" label="Most Deletions" value={<span style={{display:"inline-flex",flexDirection:"column"}}><span style={{ fontSize: 18, fontWeight: 700 }}>KTX GLOBAL</span><span style={{ fontSize: 11, color: "var(--text-3)" }}>1,420 deals</span></span>} sub="Team member with the most deletions" />
          </div>

          <div className="rep-section">
            <div className="dl-search-bar">
              <div className="dl-search-input">
                <Icon name="search" className="" />
                <input placeholder="Search by deal name, lead, or deal number…" value={q} onChange={(e) => setQ(e.target.value)} />
                {q && (
                  <button className="dl-search-clear" onClick={() => setQ("")} aria-label="Clear">
                    <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 6-12 12M6 6l12 12"/></svg>
                  </button>
                )}
              </div>
              <span className="dl-count-chip">
                <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>
                2,403 deleted deals
              </span>
            </div>

            <table className="leads-table">
              <thead>
                <tr>
                  <th>Deal #</th>
                  <th>Name</th>
                  <th>Lead</th>
                  <th>Amount</th>
                  <th>Branch</th>
                  <th>Type</th>
                  <th>Status at deletion</th>
                  <th>Assigned to</th>
                  <th>Deleted by</th>
                  <th>Deleted at</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {DEALS.map((d, i) => (
                  <tr key={i}>
                    <td><span className="deal-id">{d.id}</span></td>
                    <td style={{ fontWeight: 600 }}>{d.name}</td>
                    <td style={{ color: "var(--text-1)", fontWeight: 500 }}>{d.lead}</td>
                    <td className="amount-cell">{d.amount}</td>
                    <td><span className="tag-soft">{d.branch}</span></td>
                    <td><span className="tag-soft">{d.type}</span></td>
                    <td><span className={`status-pill status-${d.status}`}>{STATUS_LABEL[d.status]}</span></td>
                    <td>
                      <span className="assignee">
                        <span className="avatar-sm" style={{ background: `hsl(${(d.agent.charCodeAt(0) * 23) % 360}, 65%, 55%)` }}>{d.agent.split(" ").map(s=>s[0]).slice(0,2).join("").toUpperCase()}</span>
                        <span className="nm">{d.agent}</span>
                      </span>
                    </td>
                    <td>
                      {d.by === "KTX GLOBAL" ? <span className="tag-soft">KTX GLOBAL</span> :
                       d.by === "Fahmida" ? <span className="agent-tag">Fahmida</span> :
                       <span style={{ color: "var(--text-3)" }}>{d.by}</span>}
                    </td>
                    <td className="tt-cell" style={{ color: "var(--text-2)" }}>{d.at}</td>
                    <td style={{ textAlign: "right" }}>
                      <button className="btn-restore">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>
                        Restore
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="rep-pager">
              <div>Showing 1 to 12 of 2,403 deleted deals</div>
              <div className="rep-pager-right">
                <button className="pager-btn">Previous</button>
                <button className="pager-btn active">1</button>
                <button className="pager-btn">2</button>
                <button className="pager-btn">3</button>
                <button className="pager-btn">4</button>
                <button className="pager-btn">5</button>
                <span className="pager-ellipsis">…</span>
                <button className="pager-btn">201</button>
                <button className="pager-btn">Next</button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
