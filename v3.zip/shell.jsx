/* global React, Icon */
const { useState: shellUseState } = React;

// ─── Navigation
const NAV_TOP = [
  { id: "dashboard", label: "Dashboard", icon: "dashboard", href: "Dashboard.html" },
  { id: "leads",     label: "Leads",     icon: "leads",     href: "Leads.html",     count: "12.9k" },
  { id: "deals",     label: "Deals",     icon: "deals",     href: "Deals.html",     count: 148 },
  { id: "tasks",     label: "Tasks",     icon: "tasks",     count: 12, children: [
    { id: "tasks-call",    label: "Call Tasks",    icon: "telecalling", href: "Calls.html" },
    { id: "tasks-general", label: "General Tasks", icon: "tasks",        href: "Tasks.html" },
    { id: "tasks-deal",    label: "Deal Tasks",    icon: "deals",        href: "DealTasks.html" },
  ] },
];
const NAV_WORK = [
  { id: "campaigns",   label: "Campaigns",   icon: "campaigns",   href: "Campaigns.html" },
  { id: "telecalling", label: "Telecalling", icon: "telecalling", href: "#" },
  { id: "attendance",  label: "Attendance",  icon: "calendar",    href: "Attendance.html" },
  { id: "reports",     label: "Reports",     icon: "reports",     groups: [
    { group: "Leads", items: [
      { id: "rep-lead-status-changes", label: "Lead Status Changes", href: "LeadStatusChanges.html" },
      { id: "rep-lead-status",         label: "Lead Status",         href: "LeadStatusReport.html" },
      { id: "rep-lead-source",         label: "Lead Source",         href: "LeadSourceReport.html" },
      { id: "rep-activities",          label: "Activities",          href: "ActivitiesReport.html" },
      { id: "rep-field-visits",        label: "Field Visits",        href: "FieldVisits.html" },
      { id: "rep-deleted-leads",       label: "Deleted Leads",       href: "DeletedLeads.html" },
    ]},
    { group: "Tasks", items: [
      { id: "rep-call-tasks",       label: "Call Tasks",       href: "Calls.html" },
      { id: "rep-task-completion",  label: "Task Completion",  href: "Tasks.html" },
    ]},
    { group: "Calls", items: [
      { id: "rep-call-report",      label: "Call Report",      href: "CallReport.html" },
      { id: "rep-call-history",     label: "Call History",     href: "CallHistory.html" },
    ]},
    { group: "Deals", items: [
      { id: "rep-deal-status",          label: "Deal Status",          href: "DealStatus.html" },
      { id: "rep-deal-field-visits",    label: "Field Visits",         href: "FieldVisits.html" },
      { id: "rep-deal-status-changes",  label: "Deal Status Changes",  href: "LeadStatusChanges.html" },
      { id: "rep-deleted-deals",        label: "Deleted Deals",        href: "DeletedDeals.html" },
      { id: "rep-lead-conversion",      label: "Lead Conversion",      href: "LeadConversion.html" },
    ]},
    { group: "Attendance", items: [
      { id: "rep-team-attendance",  label: "Team Attendance",  href: "TeamAttendance.html" },
    ]},
  ] },
];
const NAV_ORG = [
  { id: "team",     label: "Team",     icon: "team",     href: "#" },
  { id: "settings", label: "Settings", icon: "settings", href: "Settings.html" },
];

function NavItem({ n, active }) {
  const hasChildren = n.children && n.children.length > 0;
  const hasGroups = n.groups && n.groups.length > 0;
  const expandable = hasChildren || hasGroups;
  const childActive =
    (hasChildren && n.children.some(c => c.id === active)) ||
    (hasGroups && n.groups.some(g => g.items.some(it => it.id === active)));
  const [open, setOpen] = React.useState(childActive || active === n.id);

  const go = (href) => {
    if (!href || href === "#") return;
    window.location.href = href;
  };

  const handleClick = (e) => {
    e.preventDefault();
    if (expandable) {
      setOpen(o => !o);
    } else {
      go(n.href);
    }
  };

  return (
    <>
      <a href={n.href || "#"} className={`nav-item ${active === n.id ? "active" : ""} ${expandable ? "has-children" : ""}`} onClick={handleClick} title={n.label}>
        <Icon name={n.icon} />
        <span className="nav-text">{n.label}</span>
        {n.count !== undefined && <span className="nav-count">{n.count}</span>}
        {expandable && (
          <span className={`nav-chev ${open ? "open" : ""}`}>
            <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
          </span>
        )}
      </a>
      {hasChildren && open && (
        <div className="nav-children">
          {n.children.map(c => (
            <a key={c.id} href={c.href || "#"} className={`nav-item nav-child ${active === c.id ? "active" : ""}`} onClick={(e) => { e.preventDefault(); go(c.href); }} title={c.label}>
              <Icon name={c.icon} />
              <span className="nav-text">{c.label}</span>
            </a>
          ))}
        </div>
      )}
      {hasGroups && open && (
        <div className="nav-children nav-grouped">
          {n.groups.map(g => (
            <React.Fragment key={g.group}>
              <div className="nav-group-label">{g.group}</div>
              {g.items.map(it => (
                <a key={it.id} href={it.href || "#"} className={`nav-item nav-child ${active === it.id ? "active" : ""}`} onClick={(e) => { e.preventDefault(); go(it.href); }} title={it.label}>
                  <span className="nav-text">{it.label}</span>
                </a>
              ))}
            </React.Fragment>
          ))}
        </div>
      )}
    </>
  );
}

function Sidebar({ active, collapsed, onToggle }) {
  return (
    <aside className={`sidebar ${collapsed ? "collapsed" : ""}`}>
      <div className="brand">
        <img className="brand-logo brand-logo-dark" src="assets/logo-dark.png" alt="GetLead CRM" />
        <img className="brand-logo brand-logo-light" src="assets/logo-light.png" alt="GetLead CRM" />
        <button className="sidebar-toggle" onClick={onToggle} title={collapsed ? "Expand" : "Collapse"} aria-label="Toggle sidebar">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            {collapsed
              ? <path d="m9 6 6 6-6 6"/>
              : <path d="m15 6-6 6 6 6"/>}
          </svg>
        </button>
      </div>

      <div className="sidebar-scroll">
        <div className="nav-section">
          {NAV_TOP.map(n => <NavItem key={n.id} n={n} active={active} />)}
        </div>

        <div className="nav-section">
          <div className="nav-label">Workspace</div>
          {NAV_WORK.map(n => <NavItem key={n.id} n={n} active={active} />)}
        </div>

        <div className="nav-section">
          <div className="nav-label">Organization</div>
          {NAV_ORG.map(n => <NavItem key={n.id} n={n} active={active} />)}
        </div>
      </div>

      <div className="sidebar-bottom">
        <div className="upgrade-card">
          <div className="upgrade-glow"></div>
          <div className="upgrade-title">Upgrade Plan</div>
          <div className="upgrade-body">Unlock advanced features and automate your sales process.</div>
          <button className="upgrade-btn">Upgrade Now</button>
        </div>

        <div className="sidebar-footer">
          <div className="nav-item" title="Support">
            <Icon name="support" />
            <span className="nav-text">Support</span>
          </div>
          <div className="nav-item" title="Sign out">
            <Icon name="signout" />
            <span className="nav-text">Sign out</span>
          </div>
        </div>
      </div>
    </aside>
  );
}

function AppGrid() {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    const onKey = (e) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);
  const items = [
    { id: "leads",       label: "Leads",        icon: "leads",      href: "Leads.html",        color: "#3b82f6" },
    { id: "deals",       label: "Deals",        icon: "wallet",     href: "Deals.html",        color: "#22c55e" },
    { id: "tasks",       label: "Tasks",        icon: "tasks",      href: "Tasks.html",        color: "#a855f7" },
    { id: "calls",       label: "Calls",        icon: "phone",      href: "Calls.html",        color: "#ef4444" },
    { id: "campaigns",   label: "Campaigns",    icon: "campaigns",  href: "Campaigns.html",    color: "#f97316" },
    { id: "automations", label: "Automations",  icon: "zap",        href: "Campaigns.html",    color: "#eab308" },
    { id: "integrations",label: "Integrations", icon: "spark",      href: "Campaigns.html",    color: "#22d3ee" },
    { id: "facebook",    label: "Facebook",     icon: "chat",       href: "Campaigns.html",    color: "#6366f1" },
    { id: "ai",          label: "AI / MCP",     icon: "spark",      href: "#",                 color: "#ec4899" },
    { id: "users",       label: "Users",        icon: "team",       href: "Settings.html",     color: "#84cc16" },
    { id: "reports",     label: "Reports",      icon: "reports",    href: "LeadStatusReport.html", color: "#22c55e" },
  ];
  return (
    <div className="app-grid-wrap" ref={ref}>
      <button className={`icon-btn ${open ? "active" : ""}`} title="Apps" onClick={() => setOpen(o => !o)}>
        <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" stroke="none">
          <circle cx="5" cy="5" r="1.5"/><circle cx="12" cy="5" r="1.5"/><circle cx="19" cy="5" r="1.5"/>
          <circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>
          <circle cx="5" cy="19" r="1.5"/><circle cx="12" cy="19" r="1.5"/><circle cx="19" cy="19" r="1.5"/>
        </svg>
      </button>
      {open && (
        <div className="app-grid-pop">
          {items.map((it) => (
            <a key={it.id} href={it.href || "#"} className="app-tile" onClick={(e) => { if (!it.href || it.href === "#") e.preventDefault(); setOpen(false); }}>
              <span className="app-tile-icon" style={{ color: it.color, background: `color-mix(in srgb, ${it.color} 14%, transparent)`, boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${it.color} 30%, transparent)` }}>
                <Icon name={it.icon} className="" size={18} />
              </span>
              <span className="app-tile-label">{it.label}</span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

function Topbar({ title = "Dashboard", subtitle, theme, setTheme, actions }) {
  return (
    <div className="topbar">
      <div>
        <h1 className="page-title">{title}</h1>
        {subtitle && <div className="page-sub">{subtitle}</div>}
      </div>
      <div className="top-actions">
        {actions}
        <button className="icon-btn" title="Notifications">
          <Icon name="bell" className="" size={16} />
          <span className="badge"></span>
        </button>
        <button className="icon-btn" title="Toggle theme" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>
          <Icon name={theme === "dark" ? "sun" : "moon"} className="" size={16} />
        </button>
        <button className="icon-btn" title="Messages">
          <Icon name="chat" className="" size={16} />
        </button>
        <AppGrid />
        <div className="user-pill">
          <div className="avatar">GA</div>
          <div className="who">
            <span className="name">Getlead</span>
            <span className="role">Admin</span>
          </div>
        </div>
      </div>
    </div>
  );
}

window.Sidebar = Sidebar;
window.Topbar = Topbar;
