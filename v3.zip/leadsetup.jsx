/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider */
const { useState, useEffect } = React;

// ─── Data
const LEAD_SOURCES = [
  { name: "BNI",              desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "CMA",              desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "Direct",           desc: "Direct inquiries and walk-ins",                  active: true,  created: "19/04/2026" },
  { name: "Excel Import",     desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "Excel Import KTX", desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "Facebook",         desc: "Leads from Facebook ads and organic posts",      active: true,  created: "19/04/2026" },
  { name: "FACEBOOK",         desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "GLDialer",         desc: "Automatically created for API integrations",     active: true,  created: "29/04/2026" },
  { name: "Google Ads",       desc: "Leads from Google advertising campaigns",        active: true,  created: "19/04/2026" },
  { name: "Instagram",        desc: "Leads from Instagram marketing",                 active: true,  created: "19/04/2026" },
  { name: "INSTAGRAM",        desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "IVR",              desc: "Automatically created for API integrations",     active: true,  created: "04/05/2026" },
  { name: "KSSIA",            desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "KTX",              desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "KTX9th",           desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "KTX 9th",          desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "KTX Draft",        desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "KTX FB",           desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "ktx new",          desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "LinkedIn",         desc: "Leads from LinkedIn networking",                 active: true,  created: "19/04/2026" },
  { name: "MCC",              desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "Migration",        desc: "Default source for migrated leads",              active: true,  created: "19/04/2026" },
  { name: "Portal",           desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "Reboot",           desc: "-",                                             active: true,  created: "19/04/2026" },
  { name: "Reboot 2024",      desc: "-",                                             active: true,  created: "19/04/2026" },
];

const LEAD_STATUSES = [
  { name: "New",            dot: "#3b82f6", pos: 0, kind: "System", stage: "attention", active: true },
  { name: "Attempt 1",      dot: "#3b82f6", pos: 1, kind: "Custom", stage: "attention", active: true },
  { name: "Contacted",      dot: "#a855f7", pos: 1, kind: "Custom", stage: "interest",  active: true },
  { name: "Interested",     dot: "#65a30d", pos: 1, kind: "Custom", stage: "attention", active: true },
  { name: "Attempt 2",      dot: "#3b82f6", pos: 2, kind: "Custom", stage: "attention", active: true },
  { name: "Not attended",   dot: "#ef4444", pos: 2, kind: "Custom", stage: "attention", active: true },
  { name: "Qualified",      dot: "#16a34a", pos: 2, kind: "Custom", stage: "desire",    active: true },
  { name: "Unqualified",    dot: "#ef4444", pos: 3, kind: "Custom", stage: "attention", active: true },
  { name: "Will let you know", dot: "#22d3ee", pos: 3, kind: "Custom", stage: "attention", active: true },
  { name: "Attempt 3",      dot: "#3b82f6", pos: 4, kind: "Custom", stage: "attention", active: true },
];

const LEAD_PURPOSES = [
  "2024 DELEGATE", "Business Use", "Delegate", "Exhibitor", "General", "Investment",
  "KTX", "KTX DELEGATE", "KTX-LinkedIn", "KTX STALL", "Other", "Personal Use",
].map(n => ({ name: n, created: "19/04/2026", active: true }));

const WA_TEMPLATES = [
  { name: "test 2",   preview: ",mhg",  created: "18/05/2026" },
  { name: "Test Deail", preview: "test 1", created: "18/05/2026" },
];

const TABS = [
  { id: "sources",    label: "Lead Sources",       icon: "tag" },
  { id: "statuses",   label: "Lead Statuses",      icon: "tasks" },
  { id: "purposes",   label: "Lead Purposes",      icon: "target" },
  { id: "whatsapp",   label: "WhatsApp Templates", icon: "chat" },
  { id: "fields",     label: "Custom Fields",      icon: "columns" },
  { id: "assignment", label: "Lead Assignment",    icon: "user-plus" },
];

function getInitialTab() {
  const p = new URLSearchParams(window.location.search);
  const t = p.get("tab") || window.__defaultTab;
  return TABS.find(x => x.id === t)?.id || "sources";
}

function CreateSourceModal({ open, onClose }) {
  const [active, setActive] = useState(true);
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" role="dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 520 }}>
        <div className="modal-head">
          <div>
            <h2 className="modal-title">Create Lead Source</h2>
            <div className="modal-sub">Add a new lead source for tracking where leads come from</div>
          </div>
          <button className="modal-close" aria-label="Close" onClick={onClose}>
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 6-12 12M6 6l12 12"/></svg>
          </button>
        </div>
        <div className="modal-body">
          <div className="field">
            <label className="field-label">Name</label>
            <input className="field-input" placeholder="e.g., Website, Referral, Social Media" />
          </div>
          <div className="field">
            <label className="field-label">Description <span style={{ color: "var(--text-3)", fontWeight: 500 }}>(optional)</span></label>
            <textarea className="field-textarea" placeholder="Add a description for this lead source"></textarea>
          </div>
          <div className="ls-toggle-row">
            <span className="field-label" style={{ marginBottom: 0 }}>Active</span>
            <button
              type="button"
              role="switch"
              aria-checked={active}
              className={`ls-switch ${active ? "on" : ""}`}
              onClick={() => setActive(a => !a)}
            >
              <span className="ls-switch-thumb"></span>
            </button>
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn-cancel" onClick={onClose}>Cancel</button>
          <button className="btn-primary">Create Source</button>
        </div>
      </div>
    </div>
  );
}

function CreateStatusModal({ open, onClose }) {
  const [color, setColor] = useState("#3B82F6");
  const [active, setActive] = useState(true);
  const [cycle, setCycle] = useState(false);
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" role="dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 560 }}>
        <div className="modal-head">
          <div>
            <h2 className="modal-title">Create Lead Status</h2>
            <div className="modal-sub">Add a new status for your leads. You can create multiple statuses without closing this dialog.</div>
          </div>
          <button className="modal-close" aria-label="Close" onClick={onClose}>
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 6-12 12M6 6l12 12"/></svg>
          </button>
        </div>
        <div className="modal-body">
          <div className="field">
            <label className="field-label">Name <span className="req">*</span></label>
            <input className="field-input" placeholder="e.g., Qualified" />
          </div>
          <div className="field">
            <label className="field-label">Color <span className="req">*</span></label>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 80px", gap: 10 }}>
              <input className="field-input" value={color} onChange={(e) => setColor(e.target.value)} />
              <input type="color" value={color} onChange={(e) => setColor(e.target.value.toUpperCase())} style={{ height: 38, width: "100%", border: "1px solid var(--border)", borderRadius: 8, background: "var(--surface)", cursor: "pointer", padding: 2 }} />
            </div>
          </div>
          <div className="field">
            <label className="field-label">Stage <span className="req">*</span></label>
            <select className="field-select" defaultValue="Attention">
              <option>Attention</option><option>Interest</option><option>Desire</option><option>Action</option>
            </select>
          </div>
          <div className="field">
            <label className="field-label">Position</label>
            <input className="field-input" defaultValue="0" />
          </div>
          <div className="ls-toggle-row">
            <span className="field-label" style={{ marginBottom: 0 }}>Active</span>
            <button type="button" role="switch" aria-checked={active}
              className={`ls-switch ${active ? "on" : ""}`} onClick={() => setActive(a => !a)}>
              <span className="ls-switch-thumb"></span>
            </button>
          </div>
          <div className="ls-toggle-row">
            <div>
              <div className="field-label" style={{ marginBottom: 2 }}>Cycle Start</div>
              <div style={{ fontSize: 12, color: "var(--text-2)" }}>When a lead enters this status, start a new conversion cycle</div>
            </div>
            <button type="button" role="switch" aria-checked={cycle}
              className={`ls-switch ${cycle ? "on" : ""}`} onClick={() => setCycle(c => !c)}>
              <span className="ls-switch-thumb"></span>
            </button>
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn-cancel" onClick={onClose}>Close</button>
          <button className="btn-primary">Create Status</button>
        </div>
      </div>
    </div>
  );
}

function CreatePurposeModal({ open, onClose, onCreate }) {
  const [name, setName] = useState("");
  const [active, setActive] = useState(true);
  useEffect(() => {
    if (!open) return;
    setName(""); setActive(true);
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
  if (!open) return null;
  const canSubmit = name.trim();
  const submit = () => {
    if (!canSubmit) return;
    const today = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    onCreate({
      name: name.trim(),
      created: `${pad(today.getDate())}/${pad(today.getMonth() + 1)}/${today.getFullYear()}`,
      active });
    onClose();
  };
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" role="dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 480 }}>
        <div className="modal-head">
          <div>
            <h2 className="modal-title">Create Lead Purpose</h2>
            <div className="modal-sub">Add a new purpose for categorizing leads</div>
          </div>
          <button className="modal-close" aria-label="Close" onClick={onClose}>
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 6-12 12M6 6l12 12"/></svg>
          </button>
        </div>
        <div className="modal-body">
          <div className="field">
            <label className="field-label">Name</label>
            <input className="field-input" placeholder="e.g., Product Demo" value={name} onChange={(e) => setName(e.target.value)} autoFocus />
          </div>
          <div className="ls-toggle-row">
            <div>
              <div className="field-label" style={{ marginBottom: 2 }}>Active</div>
              <div style={{ fontSize: 12.5, color: "var(--text-2)" }}>Make this purpose available for selection</div>
            </div>
            <button type="button" role="switch" aria-checked={active}
              className={`ls-switch ${active ? "on" : ""}`} onClick={() => setActive(a => !a)}>
              <span className="ls-switch-thumb"></span>
            </button>
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn-cancel" onClick={onClose}>Cancel</button>
          <button className="btn-primary" disabled={!canSubmit} onClick={submit}>Create Purpose</button>
        </div>
      </div>
    </div>
  );
}

function CreateTemplateModal({ open, onClose, onCreate }) {
  const [name, setName] = useState("");
  const [body, setBody] = useState("");
  const [active, setActive] = useState(true);
  useEffect(() => {
    if (!open) return;
    setName(""); setBody(""); setActive(true);
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
  if (!open) return null;
  const canSubmit = name.trim() && body.trim();
  const submit = () => {
    if (!canSubmit) return;
    const today = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    onCreate({
      name: name.trim(),
      preview: body.trim().slice(0, 60),
      created: `${pad(today.getDate())}/${pad(today.getMonth() + 1)}/${today.getFullYear()}`,
      active });
    onClose();
  };
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" role="dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 560 }}>
        <div className="modal-head">
          <div>
            <h2 className="modal-title">Create WhatsApp Template</h2>
            <div className="modal-sub">Add a new reusable message template for WhatsApp communication</div>
          </div>
          <button className="modal-close" aria-label="Close" onClick={onClose}>
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 6-12 12M6 6l12 12"/></svg>
          </button>
        </div>
        <div className="modal-body">
          <div className="field">
            <label className="field-label">Template Name</label>
            <input className="field-input" placeholder="e.g., Follow Up, Introduction, Meeting Reminder" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="field">
            <label className="field-label">Message Template</label>
            <textarea className="field-textarea" placeholder="Enter your WhatsApp message template here…" value={body} onChange={(e) => setBody(e.target.value)} style={{ minHeight: 140 }}></textarea>
            <div style={{ fontSize: 12, color: "var(--text-3)", marginTop: 6 }}>
              Tip: Use placeholders like {"{name}"}, {"{phone}"} for dynamic content
            </div>
          </div>
          <div className="ls-toggle-row">
            <span className="field-label" style={{ marginBottom: 0 }}>Active</span>
            <button type="button" role="switch" aria-checked={active}
              className={`ls-switch ${active ? "on" : ""}`} onClick={() => setActive(a => !a)}>
              <span className="ls-switch-thumb"></span>
            </button>
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn-cancel" onClick={onClose}>Cancel</button>
          <button className="btn-primary" disabled={!canSubmit} onClick={submit}>Create Template</button>
        </div>
      </div>
    </div>
  );
}

function CreateFieldModal({ open, onClose, onCreate }) {
  const [key, setKey] = useState("");
  const [label, setLabel] = useState("");
  const [type, setType] = useState("Text");
  const [placeholder, setPlaceholder] = useState("");
  const [help, setHelp] = useState("");
  const [required, setRequired] = useState(false);
  const [active, setActive] = useState(true);
  useEffect(() => {
    if (!open) return;
    setKey(""); setLabel(""); setType("Text"); setPlaceholder(""); setHelp("");
    setRequired(false); setActive(true);
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
  if (!open) return null;
  const canSubmit = key.trim() && label.trim();
  const submit = () => {
    if (!canSubmit) return;
    onCreate({ key: key.trim(), label: label.trim(), type, placeholder, help, required, active });
    onClose();
  };
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" role="dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 560 }}>
        <div className="modal-head">
          <div>
            <h2 className="modal-title">Create Custom Field</h2>
          </div>
          <button className="modal-close" aria-label="Close" onClick={onClose}>
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 6-12 12M6 6l12 12"/></svg>
          </button>
        </div>
        <div className="modal-body">
          <div className="field">
            <label className="field-label">Field Key</label>
            <input className="field-input" placeholder="e.g., phone_number" value={key} onChange={(e) => setKey(e.target.value)} />
            <div style={{ fontSize: 12, color: "var(--text-3)", marginTop: 4 }}>Unique identifier for this field (cannot be changed later)</div>
          </div>
          <div className="field">
            <label className="field-label">Label</label>
            <input className="field-input" placeholder="e.g., Phone Number" value={label} onChange={(e) => setLabel(e.target.value)} />
          </div>
          <div className="field">
            <label className="field-label">Field Type</label>
            <select className="field-select" value={type} onChange={(e) => setType(e.target.value)}>
              <option>Text</option><option>Number</option><option>Email</option><option>Phone</option>
              <option>Date</option><option>Dropdown</option><option>Checkbox</option><option>Textarea</option>
            </select>
          </div>
          <div className="field">
            <label className="field-label">Placeholder</label>
            <input className="field-input" placeholder="Enter placeholder text" value={placeholder} onChange={(e) => setPlaceholder(e.target.value)} />
          </div>
          <div className="field">
            <label className="field-label">Help Text</label>
            <input className="field-input" placeholder="Enter help text" value={help} onChange={(e) => setHelp(e.target.value)} />
          </div>
          <label className="cbx-row">
            <input type="checkbox" className="cbx" checked={required} onChange={(e) => setRequired(e.target.checked)} />
            <span>Required field</span>
          </label>
          <label className="cbx-row">
            <input type="checkbox" className="cbx" checked={active} onChange={(e) => setActive(e.target.checked)} />
            <span>Active</span>
          </label>
        </div>
        <div className="modal-foot">
          <button className="btn-cancel" onClick={onClose}>Cancel</button>
          <button className="btn-primary" disabled={!canSubmit} onClick={submit}>Create Field</button>
        </div>
      </div>
    </div>
  );
}

function CfMenu({ onEdit, onDelete }) {
  const [open, setOpen] = useState(false);
  const ref = React.useRef(null);
  useEffect(() => {
    if (!open) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);
  return (
    <div className="row-menu-wrap" ref={ref} onMouseDown={(e) => e.stopPropagation()}>
      <button
        className={`ls-icon-btn ${open ? "active" : ""}`}
        aria-label="More"
        onClick={(e) => { e.stopPropagation(); setOpen(o => !o); }}
        draggable={false}
      >
        <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="5" r="1.3" fill="currentColor"/>
          <circle cx="12" cy="12" r="1.3" fill="currentColor"/>
          <circle cx="12" cy="19" r="1.3" fill="currentColor"/>
        </svg>
      </button>
      {open && (
        <div className="hdr-menu row-menu" role="menu" onClick={(e) => e.stopPropagation()}>
          <button role="menuitem" className="hdr-menu-item" onClick={() => { setOpen(false); onEdit && onEdit(); }}>
            <Icon name="edit" className="" size={16} />
            <span>Edit</span>
          </button>
          <button role="menuitem" className="hdr-menu-item danger" onClick={() => { setOpen(false); onDelete && onDelete(); }}>
            <Icon name="trash" className="" size={16} />
            <span>Delete</span>
          </button>
        </div>
      )}
    </div>
  );
}

function PaneHead({ title, sub, actions }) {
  return (
    <div className="ls-pane-head">
      <div>
        <h2>{title}</h2>
        {sub && <div className="ls-pane-sub">{sub}</div>}
      </div>
      <div className="ls-actions">{actions}</div>
    </div>
  );
}

function RowActions({ withEdit = true, withDelete = true }) {
  return (
    <>
      {withEdit && (
        <button className="ls-icon-btn" title="Edit">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 1 1 3 3L12 15l-4 1 1-4z"/></svg>
        </button>
      )}
      {withDelete && (
        <button className="ls-icon-btn danger" title="Delete">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6M10 11v6M14 11v6"/></svg>
        </button>
      )}
    </>
  );
}

function MoreDots() {
  return (
    <button className="ls-icon-btn" title="More">
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="5" r="1.3" fill="currentColor"/>
        <circle cx="12" cy="12" r="1.3" fill="currentColor"/>
        <circle cx="12" cy="19" r="1.3" fill="currentColor"/>
      </svg>
    </button>
  );
}

// ─── Panes
function SourcesPane() {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const items = LEAD_SOURCES.filter(s => s.name.toLowerCase().includes(q.toLowerCase()));
  const totalPages = Math.ceil(items.length / 25);
  return (
    <div>
      <CreateSourceModal open={open} onClose={() => setOpen(false)} />
      <PaneHead
        title="Lead Sources"
        sub="Configure the available lead sources for your business"
        actions={
          <button className="btn-primary" onClick={() => setOpen(true)}><Icon name="plus" className="" size={14} />Add Source</button>
        }
      />
      <div className="ls-section-card">
        <h3>Active Sources</h3>
        <div className="sub">Manage the sources that leads can be assigned to.</div>
        <div className="ls-search" style={{ marginBottom: 12 }}>
          <Icon name="search" className="" />
          <input placeholder="Search sources…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <table className="ls-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Description</th>
              <th>Status</th>
              <th>Created</th>
              <th style={{ width: 90 }}></th>
            </tr>
          </thead>
          <tbody>
            {items.map((s, i) => (
              <tr key={i}>
                <td style={{ fontWeight: 600 }}>{s.name}</td>
                <td style={{ color: s.desc === "-" ? "var(--text-3)" : "var(--text-2)" }}>{s.desc}</td>
                <td><span className="pill-active">Active</span></td>
                <td style={{ color: "var(--text-2)", fontVariantNumeric: "tabular-nums" }}>{s.created}</td>
                <td><MoreDots /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="ls-pager">
        <div>Showing 1 to {items.length} of {items.length} lead sources</div>
        <div className="ls-pager-right">
          <button className="pager-btn">Previous</button>
          <span>Page 1 of {Math.max(1, totalPages)}</span>
          <button className="pager-btn">Next</button>
        </div>
      </div>
    </div>
  );
}

function StatusesPane() {
  const [open, setOpen] = useState(false);
  return (
    <div>
      <CreateStatusModal open={open} onClose={() => setOpen(false)} />
      <PaneHead
        title="Lead Statuses"
        sub="Configure the status workflow for your leads"
        actions={
          <>
            <button className="btn-secondary-row">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v18h18"/><path d="m7 16 4-4 4 4 6-6"/></svg>
              Manage Transitions
            </button>
            <button className="btn-primary" onClick={() => setOpen(true)}><Icon name="plus" className="" size={14} />Add Status</button>
          </>
        }
      />
      <div className="ls-section-card">
        <h3>Active Statuses</h3>
        <div className="sub">Configure the statuses that leads can have in your pipeline.</div>
        <table className="ls-table">
          <thead>
            <tr>
              <th>Status</th>
              <th>Position</th>
              <th>Type</th>
              <th>Stage</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {LEAD_STATUSES.map((s, i) => (
              <tr key={i}>
                <td>
                  <span className="dot-color" style={{ background: s.dot }}></span>
                  <span style={{ fontWeight: 500 }}>{s.name}</span>
                </td>
                <td>
                  <span className="position-pill">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M7 17V3M3 7l4-4 4 4M17 7v14M21 17l-4 4-4-4"/></svg>
                    {s.pos}
                  </span>
                </td>
                <td><span className="tag-soft">{s.kind}</span></td>
                <td><span className={`stage-pill stage-${s.stage}`}>{s.stage[0].toUpperCase() + s.stage.slice(1)}</span></td>
                <td><span className="pill-active green">Active</span></td>
                <td><MoreDots /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function PurposesPane() {
  const [open, setOpen] = useState(false);
  const [purposes, setPurposes] = useState(LEAD_PURPOSES);
  return (
    <div>
      <CreatePurposeModal
        open={open}
        onClose={() => setOpen(false)}
        onCreate={(p) => setPurposes((prev) => [p, ...prev])}
      />
      <PaneHead
        title="Lead Purposes"
        sub="Manage purposes for categorizing leads"
        actions={<button className="btn-primary" onClick={() => setOpen(true)}><Icon name="plus" className="" size={14} />Add Purpose</button>}
      />
      <div className="ls-section-card">
        <table className="ls-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Status</th>
              <th>Created At</th>
              <th style={{ width: 80, textAlign: "right" }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {purposes.map((p, i) => (
              <tr key={i}>
                <td style={{ fontWeight: 500 }}>{p.name}</td>
                <td><span className="pill-active">Active</span></td>
                <td style={{ color: "var(--text-2)", fontVariantNumeric: "tabular-nums" }}>{p.created}</td>
                <td style={{ textAlign: "right" }}>
                  <span style={{ display: "inline-flex", gap: 4 }}><RowActions /></span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function WhatsAppPane() {
  const [open, setOpen] = useState(false);
  const [templates, setTemplates] = useState(WA_TEMPLATES);
  return (
    <div>
      <CreateTemplateModal
        open={open}
        onClose={() => setOpen(false)}
        onCreate={(t) => setTemplates((prev) => [t, ...prev])}
      />
      <PaneHead
        title="WhatsApp Templates"
        sub="Create reusable message templates for WhatsApp communication"
        actions={<button className="btn-primary" onClick={() => setOpen(true)}><Icon name="plus" className="" size={14} />Add Template</button>}
      />
      <div className="ls-section-card">
        <h3>Active Templates</h3>
        <div className="sub">Manage WhatsApp message templates for your team</div>
        <table className="ls-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Template Preview</th>
              <th>Status</th>
              <th>Created</th>
              <th style={{ width: 60 }}></th>
            </tr>
          </thead>
          <tbody>
            {templates.map((t, i) => (
              <tr key={i}>
                <td style={{ fontWeight: 600 }}>{t.name}</td>
                <td style={{ color: "var(--text-2)" }}>{t.preview}</td>
                <td><span className="pill-active">Active</span></td>
                <td style={{ color: "var(--text-2)", fontVariantNumeric: "tabular-nums" }}>{t.created}</td>
                <td><MoreDots /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CustomFieldsPane() {
  const [open, setOpen] = useState(false);
  const [fields, setFields] = useState([]);
  const [dragIdx, setDragIdx] = useState(null);
  const [overIdx, setOverIdx] = useState(null);
  const total    = fields.length;
  const activeN  = fields.filter(f => f.active).length;
  const required = fields.filter(f => f.required).length;

  const onDragStart = (i) => (e) => {
    setDragIdx(i);
    e.dataTransfer.effectAllowed = "move";
    try { e.dataTransfer.setData("text/plain", String(i)); } catch (err) { /* noop */ }
  };
  const onDragOver = (i) => (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
    if (overIdx !== i) setOverIdx(i);
  };
  const onDragLeave = () => setOverIdx(null);
  const onDrop = (i) => (e) => {
    e.preventDefault();
    if (dragIdx === null || dragIdx === i) { setDragIdx(null); setOverIdx(null); return; }
    setFields((prev) => {
      const next = [...prev];
      const [moved] = next.splice(dragIdx, 1);
      next.splice(i, 0, moved);
      return next;
    });
    setDragIdx(null); setOverIdx(null);
  };
  const onDragEnd = () => { setDragIdx(null); setOverIdx(null); };

  return (
    <div>
      <CreateFieldModal open={open} onClose={() => setOpen(false)} onCreate={(f) => setFields((prev) => [...prev, f])} />
      <PaneHead
        title="Custom Fields"
        actions={<button className="btn-primary" onClick={() => setOpen(true)}><Icon name="plus" className="" size={14} />Add Field</button>}
      />

      <div className="cf-stats">
        <div className="cf-stat"><div className="cf-stat-lbl">Total Fields</div><div className="cf-stat-val">{total}</div></div>
        <div className="cf-stat"><div className="cf-stat-lbl">Active Fields</div><div className="cf-stat-val">{activeN}</div></div>
        <div className="cf-stat"><div className="cf-stat-lbl">Required Fields</div><div className="cf-stat-val">{required}</div></div>
      </div>

      {fields.length === 0 ? (
        <div className="coming-soon" style={{ marginTop: 18 }}>
          <h3>No custom fields yet</h3>
          <p>Custom fields let you capture information that isn't part of the default lead form — like company size, deal value range, or industry vertical.</p>
          <p>Click <strong style={{ color: "var(--text-1)" }}>Add Field</strong> to create your first one.</p>
        </div>
      ) : (
        <>
          <div className="cf-header">
            <div className="cf-header-title">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="14" y2="12"/><line x1="4" y1="18" x2="18" y2="18"/></svg>
              <span>Active Fields</span>
            </div>
            <div className="cf-reorder">
              <svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor" stroke="none"><circle cx="9" cy="6" r="1.4"/><circle cx="15" cy="6" r="1.4"/><circle cx="9" cy="12" r="1.4"/><circle cx="15" cy="12" r="1.4"/><circle cx="9" cy="18" r="1.4"/><circle cx="15" cy="18" r="1.4"/></svg>
              Drag to reorder
            </div>
          </div>

          <div className="cf-grid">
            {fields.map((f, i) => (
              <div
                key={i}
                className={`cf-card ${dragIdx === i ? "dragging" : ""} ${overIdx === i && dragIdx !== null && dragIdx !== i ? "drop-target" : ""}`}
                draggable
                onDragStart={onDragStart(i)}
                onDragOver={onDragOver(i)}
                onDragLeave={onDragLeave}
                onDrop={onDrop(i)}
                onDragEnd={onDragEnd}
              >
                <div className="cf-card-head">
                  <span className="cf-grip" title="Drag to reorder">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" stroke="none"><circle cx="9" cy="6" r="1.3"/><circle cx="15" cy="6" r="1.3"/><circle cx="9" cy="12" r="1.3"/><circle cx="15" cy="12" r="1.3"/><circle cx="9" cy="18" r="1.3"/><circle cx="15" cy="18" r="1.3"/></svg>
                  </span>
                  <h4 className="cf-card-title">{f.label}</h4>
                  <button className="ls-icon-btn" aria-label="More" onMouseDown={(e) => e.stopPropagation()} draggable={false}>
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="12" cy="5" r="1.3" fill="currentColor"/>
                      <circle cx="12" cy="12" r="1.3" fill="currentColor"/>
                      <circle cx="12" cy="19" r="1.3" fill="currentColor"/>
                    </svg>
                  </button>
                </div>
                <div className="cf-card-key">{f.key}</div>
                <div className="cf-card-tags">
                  <span className="tag-soft">{f.type}</span>
                  {f.required && <span className="pill-active">Required</span>}
                  {!f.active && <span className="tag-soft">Inactive</span>}
                </div>
                {f.placeholder && <div className="cf-card-meta"><span className="lbl">Placeholder:</span> {f.placeholder}</div>}
                {f.help && <div className="cf-card-meta"><span className="lbl">Help text:</span> {f.help}</div>}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function AssignmentPane() {
  return (
    <div>
      <PaneHead title="Lead Assignment" sub="Configure automatic lead assignment rules" />
      <div className="coming-soon">
        <h3>Coming Soon</h3>
        <p>Lead assignment rules will be available in a future update.</p>
        <p>This feature will allow you to set up round-robin assignment, territory-based routing, and custom assignment rules based on lead attributes.</p>
      </div>
    </div>
  );
}

const PANES = {
  sources:    SourcesPane,
  statuses:   StatusesPane,
  purposes:   PurposesPane,
  whatsapp:   WhatsAppPane,
  fields:     CustomFieldsPane,
  assignment: AssignmentPane };

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [tab, setTab] = useState(getInitialTab());

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "theme": "dark",
    "accent": "#ef3b3b",
    "fontScale": 100
  }/*EDITMODE-END*/);

  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  // Sync tab to URL ?tab=
  useEffect(() => {
    const u = new URL(window.location.href);
    u.searchParams.set("tab", tab);
    window.history.replaceState(null, "", u.toString());
  }, [tab]);

  const PaneComponent = PANES[tab] || SourcesPane;

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="settings" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Lead Settings"
          subtitle="Configure lead management options for your business"
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
        />
        <div className="content">
          <div className="ls-layout">
            <aside className="ls-side">
              <h3>Lead Settings</h3>
              <div className="ls-side-list">
                {TABS.map((t) => (
                  <button
                    key={t.id}
                    className={`ls-side-item ${tab === t.id ? "active" : ""}`}
                    onClick={() => setTab(t.id)}
                  >
                    <Icon name={t.icon} className="" />
                    <span>{t.label}</span>
                  </button>
                ))}
              </div>
            </aside>
            <section className="ls-pane">
              <PaneComponent />
            </section>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent}
          options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale}
          min={85} max={115} step={5} unit="%"
          onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
