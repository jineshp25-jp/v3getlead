/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider */
const { useState, useEffect } = React;

const CAMPAIGNS = [
  {
    id: "call",
    icon: "phone",
    title: "Call Campaign",
    sub: "Create calling campaigns for your leads with tracking and analytics",
    badge: "active",
    color: "#ef4444",
    stats: [
      { v: "12", l: "Running"  },
      { v: "1.8k", l: "Connected" },
      { v: "34%", l: "Pickup rate" },
    ],
    features: [
      "Lead Campaign — Assign specific leads",
      "Data Pool — Agents claim leads FIFO",
      "Real-time call tracking",
      "Agent performance metrics",
      "Lead status management",
    ],
    cta: { label: "View Campaigns", href: "CallCampaigns.html" } },
  {
    id: "sms",
    icon: "chat",
    title: "SMS Campaign",
    sub: "Send targeted SMS messages to your leads",
    badge: "soon",
    color: "#3b82f6",
    features: [
      "Bulk SMS sending",
      "Template management",
      "Delivery tracking",
      "Response management",
    ] },
  {
    id: "wa",
    icon: "whatsapp",
    title: "WhatsApp Campaign",
    sub: "Engage leads through WhatsApp Business API",
    badge: "soon",
    color: "#22c55e",
    features: [
      "WhatsApp Business integration",
      "Rich media messages",
      "Template management",
      "Two-way conversations",
    ] },
  {
    id: "email",
    icon: "mail",
    title: "Email Campaign",
    sub: "Create and send email campaigns to nurture leads",
    badge: "soon",
    color: "#a855f7",
    features: [
      "Drag-and-drop email builder",
      "A/B testing",
      "Analytics and tracking",
      "Automated follow-ups",
    ] },
];

function CampCard({ c }) {
  const accentStyle = {
    "--accent": c.color,
    "--accent-soft": `color-mix(in srgb, ${c.color} 14%, transparent)`,
    "--accent-ring": `color-mix(in srgb, ${c.color} 30%, transparent)`,
    "--accent-glow": `color-mix(in srgb, ${c.color} 16%, transparent)` };
  return (
    <div className={`camp-card ${c.badge === "active" ? "is-active" : "is-soon"}`} style={accentStyle}>
      <div className="camp-glow"></div>
      <div className="camp-head">
        <div className="camp-icon">
          <Icon name={c.icon} className="" />
        </div>
        <span className={`camp-badge ${c.badge}`}>
          {c.badge === "active" ? (
            <>
              <span className="badge-dot"></span>
              Active
            </>
          ) : "Coming Soon"}
        </span>
      </div>
      <div>
        <h3 className="camp-title">{c.title}</h3>
        <div className="camp-sub">{c.sub}</div>
      </div>
      {c.stats && (
        <div className="camp-stats">
          {c.stats.map((s) => (
            <div key={s.l} className="camp-stat">
              <div className="camp-stat-v">{s.v}</div>
              <div className="camp-stat-l">{s.l}</div>
            </div>
          ))}
        </div>
      )}
      <ul className="camp-features">
        {c.features.map((f) => (
          <li key={f}>
            <span className="tick">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5L20 7"/></svg>
            </span>
            {f}
          </li>
        ))}
      </ul>
      {c.cta ? (
        <button className="camp-cta" onClick={() => { if (c.cta.href && c.cta.href !== "#") window.location.href = c.cta.href; }}>
          {c.cta.label}
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
        </button>
      ) : (
        <div className="camp-disabled">
          <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
          Notify me when ready
        </div>
      )}
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "theme": "dark",
    "accent": "#ef3b3b",
    "fontScale": 100
  }/*EDITMODE-END*/);

  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="campaigns" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Campaigns"
          subtitle="Create and manage campaigns to engage with your leads across multiple channels"
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
        />
        <div className="content">
          <div className="camp-hero">
            <div>
              <h2>Reach your leads where they are</h2>
              <p>Run multi-channel campaigns across calls, SMS, WhatsApp, and email — all from one place. Track engagement and conversion in real time.</p>
            </div>
            <div className="camp-hero-stats">
              <div className="camp-hero-stat">
                <div className="v">12</div>
                <div className="l">Active</div>
              </div>
              <div className="camp-hero-stat">
                <div className="v">4.2k</div>
                <div className="l">Sent today</div>
              </div>
              <div className="camp-hero-stat">
                <div className="v">28%</div>
                <div className="l">Response</div>
              </div>
            </div>
          </div>
          <div className="camp-grid">
            {CAMPAIGNS.map((c) => <CampCard key={c.id} c={c} />)}
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent}
          options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale}
          min={85} max={115} step={5} unit="%"
          onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
