/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, ChevDown, FilterPill, ScheduledContent, StatusContent */
const { useState, useEffect } = React;

const CAMPAIGNS = [
  { name: "campaign last round", type: "Data Pool",      typeKey: "data-pool", status: "active",    total: 10705, completed: 4018, createdBy: "KTX GLOBAL", created: "12/05/2026, 9:58 am" },
  { name: "campaign nasiha",     type: "Lead Campaign",  typeKey: "lead-camp", status: "completed", total: 68,    completed: 68,   createdBy: "KTX GLOBAL", created: "08/05/2026, 10:24 am" },
  { name: "camp fahmida",        type: "Lead Campaign",  typeKey: "lead-camp", status: "completed", total: 63,    completed: 63,   createdBy: "KTX GLOBAL", created: "08/05/2026, 10:20 am" },
  { name: "campaign hilite",     type: "Lead Campaign",  typeKey: "lead-camp", status: "completed", total: 128,   completed: 128,  createdBy: "KTX GLOBAL", created: "08/05/2026, 9:53 am" },
  { name: "Campaign 28",         type: "Lead Campaign",  typeKey: "lead-camp", status: "active",    total: 60,    completed: 1,    createdBy: "KTX GLOBAL", created: "07/05/2026, 2:58 pm" },
  { name: "pool NF",             type: "Data Pool",      typeKey: "data-pool", status: "completed", total: 40,    completed: 40,   createdBy: "KTX GLOBAL", created: "06/05/2026, 11:10 am" },
  { name: "camp may",            type: "Lead Campaign",  typeKey: "lead-camp", status: "active",    total: 1426,  completed: 874,  createdBy: "KTX GLOBAL", created: "06/05/2026, 11:01 am" },
  { name: "campaign startup",    type: "Lead Campaign",  typeKey: "lead-camp", status: "active",    total: 4243,  completed: 3644, createdBy: "KTX GLOBAL", created: "02/05/2026, 10:42 am" },
  { name: "campaign new",        type: "Lead Campaign",  typeKey: "lead-camp", status: "active",    total: 500,   completed: 367,  createdBy: "KTX GLOBAL", created: "30/04/2026, 3:39 pm" },
  { name: "Ktx NF",              type: "Lead Campaign",  typeKey: "lead-camp", status: "active",    total: 854,   completed: 648,  createdBy: "KTX GLOBAL", created: "30/04/2026, 12:36 pm" },
  { name: "camp ktx 3",          type: "Lead Campaign",  typeKey: "lead-camp", status: "active",    total: 1479,  completed: 698,  createdBy: "KTX GLOBAL", created: "28/04/2026, 1:04 pm" },
  { name: "campaign ktx 2",      type: "Lead Campaign",  typeKey: "lead-camp", status: "active",    total: 1506,  completed: 230,  createdBy: "KTX GLOBAL", created: "25/04/2026, 12:53 pm" },
  { name: "campaign ktx",        type: "Lead Campaign",  typeKey: "lead-camp", status: "active",    total: 1500,  completed: 1143, createdBy: "KTX GLOBAL", created: "21/04/2026, 1:08 pm" },
  { name: "KSSIA KTX",           type: "Lead Campaign",  typeKey: "lead-camp", status: "completed", total: 0,     completed: 0,    createdBy: "KTX GLOBAL", created: "03/02/2025, 10:49 am" },
  { name: "2024 Delegate",       type: "Lead Campaign",  typeKey: "lead-camp", status: "completed", total: 0,     completed: 0,    createdBy: "KTX GLOBAL", created: "03/02/2025, 10:25 am" },
];

function RowMenu() {
  const [open, setOpen] = useState(false);
  const ref = React.useRef(null);
  useEffect(() => {
    if (!open) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);
  const items = [
    { id: "view",   label: "View Campaign",  icon: "eye" },
    { id: "edit",   label: "Edit Campaign",  icon: "edit" },
    { id: "pause",  label: "Pause Campaign", icon: "clock" },
    { id: "delete", label: "Delete",         icon: "trash", danger: true },
  ];
  return (
    <div className="row-menu-wrap" ref={ref}>
      <button className={`row-action ${open ? "active" : ""}`} onClick={(e) => { e.stopPropagation(); setOpen(o => !o); }} aria-label="More">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="5" r="1.3" fill="currentColor"/>
          <circle cx="12" cy="12" r="1.3" fill="currentColor"/>
          <circle cx="12" cy="19" r="1.3" fill="currentColor"/>
        </svg>
      </button>
      {open && (
        <div className="hdr-menu row-menu" role="menu" onClick={(e) => e.stopPropagation()}>
          {items.map((it) => (
            <button key={it.id} role="menuitem" className={`hdr-menu-item ${it.danger ? "danger" : ""}`} onClick={() => setOpen(false)}>
              <Icon name={it.icon} className="" size={16} />
              <span>{it.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function Avatar({ name }) {
  const initials = name.split(" ").map(s => s[0]).slice(0, 2).join("").toUpperCase();
  return <span className="avatar-sm">{initials}</span>;
}

function Toolbar({ filters, setFilter, openPop, setOpenPop }) {
  return (
    <div className="cc-toolbar-wrap">
      <div className="cc-toolbar-row1">
        <div className="leads-search">
          <Icon name="search" className="" />
          <input placeholder="Search by campaign name…" />
        </div>
      </div>
      <div className="cc-toolbar-row2">
        <span className="cc-count">{CAMPAIGNS.length} campaigns</span>
        <FilterPill
          label="Type"
          value={filters.type}
          open={openPop === "type"}
          onToggle={(o) => setOpenPop(o ? "type" : null)}
          onClear={() => setFilter("type", null)}
        >
          <StatusContent value={filters.type} onChange={(v) => { setFilter("type", v); setOpenPop(null); }} />
        </FilterPill>
        <FilterPill
          label="Status"
          value={filters.status}
          open={openPop === "status"}
          onToggle={(o) => setOpenPop(o ? "status" : null)}
          onClear={() => setFilter("status", null)}
        >
          <StatusContent value={filters.status} onChange={(v) => { setFilter("status", v); setOpenPop(null); }} />
        </FilterPill>
        <FilterPill
          label="Date"
          value={filters.date}
          open={openPop === "date"}
          onToggle={(o) => setOpenPop(o ? "date" : null)}
          onClear={() => setFilter("date", null)}
        >
          <ScheduledContent value={filters.date} onChange={(v) => { setFilter("date", v); setOpenPop(null); }} />
        </FilterPill>
      </div>
    </div>
  );
}

function StatsCell({ total, completed }) {
  const pct = total > 0 ? Math.min(100, (completed / total) * 100) : 0;
  return (
    <div className="cc-stats">
      <div className="cc-stat-row"><span className="lbl">Total</span><span className="val">{total.toLocaleString()}</span></div>
      <div className="cc-stat-bar"><div className="cc-stat-fill" style={{ width: `${pct}%` }} /></div>
      <div className="cc-stat-row"><span className="lbl">Completed</span><span className="val">{completed.toLocaleString()}</span></div>
    </div>
  );
}

function Table() {
  return (
    <div className="calls-table-wrap" style={{ borderRadius: "0 0 12px 12px", borderTop: "none" }}>
      <table className="leads-table">
        <thead>
          <tr>
            <th><span className="th-inner">Name <ChevDown /></span></th>
            <th><span className="th-inner">Type <ChevDown /></span></th>
            <th><span className="th-inner">Status <ChevDown /></span></th>
            <th><span className="th-inner">Stats <ChevDown /></span></th>
            <th><span className="th-inner">Created By <ChevDown /></span></th>
            <th><span className="th-inner">Created <ChevDown /></span></th>
            <th className="col-actions">Actions</th>
          </tr>
        </thead>
        <tbody>
          {CAMPAIGNS.map((c, i) => (
            <tr key={i}>
              <td><span className="calls-lead">{c.name}</span></td>
              <td><span className={`cc-type ${c.typeKey}`}>{c.type}</span></td>
              <td><span className={`cc-status ${c.status}`}>{c.status === "active" ? "Active" : "Completed"}</span></td>
              <td><StatsCell total={c.total} completed={c.completed} /></td>
              <td><span className="cc-creator"><Avatar name={c.createdBy} />{c.createdBy}</span></td>
              <td><span className="cc-created">{c.created}</span></td>
              <td className="col-actions"><RowMenu /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [filters, setFilters] = useState({ type: null, status: null, date: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "theme": "dark",
    "accent": "#ef3b3b",
    "fontScale": 100
  }/*EDITMODE-END*/);

  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  const headerActions = (
    <button className="btn-primary">
      <Icon name="plus" className="" size={14} />
      Create Campaign
    </button>
  );

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="campaigns" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Call Campaigns"
          subtitle="Manage your calling campaigns and track agent performance"
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={headerActions}
        />
        <div className="content">
          <div>
            <Toolbar filters={filters} setFilter={setFilter} openPop={openPop} setOpenPop={setOpenPop} />
            <Table />
          </div>
          <div className="cc-pager">
            <button className="pager-btn">Previous</button>
            <button className="pager-btn">Next</button>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent}
          options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale}
          min={85} max={115} step={5} unit="%"
          onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
