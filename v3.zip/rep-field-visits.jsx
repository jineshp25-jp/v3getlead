/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, ScheduledContent, AssignedContent */
const { useState, useEffect } = React;

function Kpi({ icon, label, value, sub, color = "#3b82f6" }) {
  return (
    <div className="rep-kpi">
      <div className="rep-kpi-row">
        <div className="rep-kpi-icon" style={{
          background: `color-mix(in srgb, ${color} 18%, transparent)`,
          color: color,
          boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${color} 30%, transparent)` }}>
          <Icon name={icon} className="" size={18} />
        </div>
        <span className="rep-kpi-lbl">{label}</span>
      </div>
      <div className="rep-kpi-val">{value}</div>
      {sub && <div className="rep-kpi-sub">{sub}</div>}
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [filters, setFilters] = useState({ date: "01/05/2026 – 18/05/2026", staff: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="rep-field-visits" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Field Visits"
          subtitle="Agent check-in activity · May 2026"
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
        />
        <div className="content">
          <div className="rep-filters">
            <FilterPill label="Date" value={filters.date} open={openPop==="date"} onToggle={(o)=>setOpenPop(o?"date":null)} onClear={()=>setFilter("date",null)}>
              <ScheduledContent value={filters.date} onChange={(v)=>{setFilter("date",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Staff Member" value={filters.staff} open={openPop==="staff"} onToggle={(o)=>setOpenPop(o?"staff":null)} onClear={()=>setFilter("staff",null)}>
              <AssignedContent value={filters.staff} onChange={(v)=>{setFilter("staff",v);setOpenPop(null);}} />
            </FilterPill>
          </div>

          <div className="kpi-grid" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
            <div className="card kpi accent-blue">
              <div className="kpi-top">
                <div className="kpi-icon" style={{ background: "color-mix(in srgb, #3b82f6 18%, transparent)", color: "#3b82f6", boxShadow: "inset 0 0 0 1px color-mix(in srgb, #3b82f6 30%, transparent)" }}>
                  <Icon name="users-2" className="" size={20} />
                </div>
                <span className="kpi-label">Staff Checked In</span>
              </div>
              <div className="kpi-val">0</div>
              <div className="kpi-sub">0.0% attendance</div>
            </div>
            <div className="card kpi accent-green">
              <div className="kpi-top">
                <div className="kpi-icon" style={{ background: "color-mix(in srgb, #22c55e 18%, transparent)", color: "#22c55e", boxShadow: "inset 0 0 0 1px color-mix(in srgb, #22c55e 30%, transparent)" }}>
                  <Icon name="target" className="" size={20} />
                </div>
                <span className="kpi-label">Leads Visited</span>
              </div>
              <div className="kpi-val">0</div>
              <div className="kpi-sub">May 2026</div>
            </div>
            <div className="card kpi accent-yellow">
              <div className="kpi-top">
                <div className="kpi-icon" style={{ background: "color-mix(in srgb, #eab308 18%, transparent)", color: "#eab308", boxShadow: "inset 0 0 0 1px color-mix(in srgb, #eab308 30%, transparent)" }}>
                  <Icon name="clock" className="" size={20} />
                </div>
                <span className="kpi-label">Avg. Time on Site</span>
              </div>
              <div className="kpi-val">—</div>
              <div className="kpi-sub">per lead visit</div>
            </div>
            <div className="card kpi accent-cyan">
              <div className="kpi-top">
                <div className="kpi-icon" style={{ background: "color-mix(in srgb, #22d3ee 18%, transparent)", color: "#22d3ee", boxShadow: "inset 0 0 0 1px color-mix(in srgb, #22d3ee 30%, transparent)" }}>
                  <Icon name="signout" className="" size={20} />
                </div>
                <span className="kpi-label">Still Checked In</span>
              </div>
              <div className="kpi-val">0</div>
              <div className="kpi-sub">Currently active</div>
            </div>
          </div>

          <div className="rep-section">
            <h3>Staff Check-in Summary</h3>
            <div className="sub">Per-agent activity overview for the period</div>
            <div className="empty-block">
              <svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 1 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              No check-ins recorded for this period.
            </div>
          </div>

          <div className="rep-section">
            <h3>Check-in Log</h3>
            <div className="sub">Every individual visit recorded during the period</div>
            <div className="empty-block">
              <svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 1 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              No check-in records for this period.
            </div>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
