/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakToggle, TweakSlider */
const { useState, useEffect, useMemo } = React;

// ─── Mock data
const LEADS = [
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+62 38 329 092", status: "new",         source: "IVR",      created: "about 3 hours ago" },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+62 38 066 033", status: "incoming",    source: "IVR",      created: "about 5 hours ago" },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+91 88 9125 6151", status: "attempt",    source: "IVR",      created: "1 day ago" },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+62 38 185 219",  status: "attempt",    source: "IVR",      created: "1 day ago" },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+971 50 971 6086", status: "new",       source: "GLDialer", created: "2 days ago" },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+91 80 3728 1722", status: "new",       source: "GLDialer", created: "2 days ago" },
  { name: "Ajith",   sub: null,                                  phone: "+91 98 4518 0777", status: "new",       source: "Direct",   created: "5 days ago",  named: true },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+91 79 0228 3861", status: "new",       source: "IVR",      created: "6 days ago" },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+91 70 1075 5716", status: "new",       source: "IVR",      created: "6 days ago" },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+91 97 4444 9448", status: "new",       source: "IVR",      created: "6 days ago" },
  { name: "customer",sub: null,                                  phone: "+91 91 8890 9893", status: "new",       source: "KTX",      created: "06/05/2026, 2:40 pm", named: true },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+62 38 544 319",  status: "new",        source: "IVR",      created: "06/05/2026, 11:56 am" },
  { name: "Priya M.",sub: "Website inquiry form",                phone: "+91 88 4561 9930", status: "interested",source: "Website",  created: "07/05/2026, 9:10 am", named: true },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+91 78 3325 6781", status: "contacted",  source: "IVR",      created: "07/05/2026, 4:22 pm" },
  { name: "Raj Patel",sub: "Referral · Trade show",              phone: "+91 96 5588 1100", status: "qualified",  source: "Direct",   created: "08/05/2026, 11:02 am", named: true },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+62 38 884 552",  status: "notattended",source: "IVR",      created: "08/05/2026, 3:48 pm" },
  { name: "Sara K.", sub: "Facebook lead form",                  phone: "+91 99 1188 7766", status: "attempt",    source: "Facebook", created: "09/05/2026, 8:30 am", named: true },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+91 98 1212 3434", status: "new",        source: "IVR",      created: "09/05/2026, 10:15 am" },
  { name: "Lina Ali",sub: "Excel import — May batch",            phone: "+971 56 778 2241", status: "new",        source: "Excel",    created: "10/05/2026, 12:00 pm", named: true },
  { name: "Unnamed", sub: "Auto-created from inbound call (C…", phone: "+62 38 109 654",  status: "incoming",   source: "IVR",      created: "10/05/2026, 1:11 pm" },
];

const STATUS_LABEL = {
  new: "New",
  attempt: "Attempt 1",
  incoming: "Incoming Call Not Supported",
  interested: "Interested",
  qualified: "Qualified",
  notattended: "Not Attended",
  contacted: "Contacted" };

function StatusPill({ status }) {
  return <span className={`status-pill status-${status}`}>{STATUS_LABEL[status]}</span>;
}

function SourceChip({ source }) {
  return (
    <span className={`src-chip src-${source}`}>
      <span className="swatch"></span>
      {source}
    </span>
  );
}

function LeadsToolbar({ perPage, setPerPage }) {
  return (
    <div className="leads-toolbar">
      <div className="leads-search">
        <Icon name="search" className="" />
        <input placeholder="Search by name, email, or phone number…" />
      </div>

      <div className="per-page">
        <span>per page</span>
        <select className="per-page-select" value={perPage} onChange={(e) => setPerPage(Number(e.target.value))}>
          <option>10</option>
          <option>20</option>
          <option>50</option>
          <option>100</option>
        </select>
      </div>

      <button className="toolbar-btn">
        <Icon name="columns" className="" />
        <span>Columns</span>
      </button>

      <button className="toolbar-btn">
        <Icon name="filter" className="" />
        <span>Advanced Filters</span>
        <span className="nudge">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="10" height="10"><path d="m15 18-6-6 6-6"/></svg>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" width="10" height="10"><path d="m9 18 6-6-6-6"/></svg>
        </span>
      </button>
    </div>
  );
}

function ChevDown() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>;
}

function HeaderMenu() {
  const [open, setOpen] = useState(false);
  const ref = React.useRef(null);
  useEffect(() => {
    if (!open) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  const items = [
    { id: "import",   label: "Import Leads",         icon: "upload"   },
    { id: "export",   label: "Export Leads",         icon: "download" },
    { sep: true },
    { id: "campaign", label: "Add to Campaign",      icon: "target"   },
    { id: "status",   label: "Update Status",        icon: "edit",     disabled: true },
    { id: "source",   label: "Update Source",        icon: "database", disabled: true },
    { id: "assign",   label: "Assign Selected Leads",icon: "user-plus",disabled: true },
    { sep: true },
    { id: "bulk",     label: "Bulk Operations",      icon: "zap"      },
    { sep: true },
    { id: "delete",   label: "Delete Selected Leads",icon: "trash",    danger: true },
  ];

  return (
    <div className="hdr-menu-wrap" ref={ref}>
      <button className={`icon-btn ${open ? "active" : ""}`} title="More" onClick={() => setOpen(o => !o)}>
        <Icon name="more" className="" size={16} />
      </button>
      {open && (
        <div className="hdr-menu" role="menu">
          {items.map((it, i) => it.sep ? (
            <div key={i} className="hdr-menu-sep"></div>
          ) : (
            <button
              key={it.id}
              role="menuitem"
              className={`hdr-menu-item ${it.disabled ? "disabled" : ""} ${it.danger ? "danger" : ""}`}
              disabled={it.disabled}
              onClick={() => setOpen(false)}
            >
              <Icon name={it.icon} className="" size={16} />
              <span>{it.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function RowMenu() {
  const [open, setOpen] = useState(false);
  const ref = React.useRef(null);
  useEffect(() => {
    if (!open) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  const items = [
    { id: "spotlight", label: "Add to Spotlight", icon: "zap" },
    { id: "assign",    label: "Assign Lead",      icon: "user-plus" },
    { sep: true },
    { id: "view",      label: "Quick View",       icon: "eye" },
    { id: "edit",      label: "Edit Lead",        icon: "edit" },
    { id: "delete",    label: "Delete Lead",      icon: "trash", danger: true },
  ];

  return (
    <div className="row-menu-wrap" ref={ref}>
      <button
        className={`row-action ${open ? "active" : ""}`}
        onClick={(e) => { e.stopPropagation(); setOpen(o => !o); }}
        aria-label="More"
      >
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="5" r="1.3" fill="currentColor"/>
          <circle cx="12" cy="12" r="1.3" fill="currentColor"/>
          <circle cx="12" cy="19" r="1.3" fill="currentColor"/>
        </svg>
      </button>
      {open && (
        <div className="hdr-menu row-menu" role="menu" onClick={(e) => e.stopPropagation()}>
          {items.map((it, i) => it.sep ? (
            <div key={i} className="hdr-menu-sep"></div>
          ) : (
            <button
              key={it.id}
              role="menuitem"
              className={`hdr-menu-item ${it.danger ? "danger" : ""}`}
              onClick={() => setOpen(false)}
            >
              <Icon name={it.icon} className="" size={16} />
              <span>{it.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function LeadsTable({ leads, selected, toggle, toggleAll, allSelected }) {
  return (
    <div className="leads-table-wrap">
      <table className="leads-table">
        <thead>
          <tr>
            <th className="col-check"><input type="checkbox" className="cbx" checked={allSelected} onChange={toggleAll} /></th>
            <th><span className="th-inner">Name <ChevDown /></span></th>
            <th><span className="th-inner">Contact <ChevDown /></span></th>
            <th><span className="th-inner">Status <ChevDown /></span></th>
            <th><span className="th-inner">Source <ChevDown /></span></th>
            <th><span className="th-inner">Created <ChevDown /></span></th>
            <th className="col-actions"></th>
          </tr>
        </thead>
        <tbody>
          {leads.map((lead, i) => (
            <tr key={i}>
              <td className="col-check">
                <input type="checkbox" className="cbx" checked={selected.has(i)} onChange={() => toggle(i)} onClick={(e) => e.stopPropagation()} />
              </td>
              <td>
                <div className={`lead-name ${lead.named ? "" : "muted"}`}>{lead.name}</div>
                {lead.sub && <div className="lead-sub">{lead.sub}</div>}
              </td>
              <td>
                <span className="lead-phone">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92V20a2 2 0 0 1-2.18 2A19.86 19.86 0 0 1 2 4.18 2 2 0 0 1 4 2h3.09a1 1 0 0 1 1 .75l1 4a1 1 0 0 1-.27 1L7.21 9.21a16 16 0 0 0 7.58 7.58l1.46-1.46a1 1 0 0 1 1-.27l4 1a1 1 0 0 1 .75 1z"/></svg>
                  {lead.phone}
                </span>
              </td>
              <td><StatusPill status={lead.status} /></td>
              <td><SourceChip source={lead.source} /></td>
              <td className="lead-created">{lead.created}</td>
              <td className="col-actions">
                <RowMenu />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Pager({ page, setPage, totalPages }) {
  const pages = [];
  const start = Math.max(1, page - 2);
  const end = Math.min(totalPages, start + 4);
  for (let i = start; i <= end; i++) pages.push(i);
  return (
    <div className="pager">
      <button className="pager-btn" disabled={page === 1} onClick={() => setPage(p => Math.max(1, p - 1))} aria-label="Previous">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
      </button>
      {start > 1 && <>
        <button className="pager-btn" onClick={() => setPage(1)}>1</button>
        <span className="pager-ellipsis">…</span>
      </>}
      {pages.map(i => (
        <button key={i} className={`pager-btn ${i === page ? "active" : ""}`} onClick={() => setPage(i)}>{i}</button>
      ))}
      {end < totalPages && <>
        <span className="pager-ellipsis">…</span>
        <button className="pager-btn" onClick={() => setPage(totalPages)}>{totalPages}</button>
      </>}
      <button className="pager-btn" disabled={page === totalPages} onClick={() => setPage(p => Math.min(totalPages, p + 1))} aria-label="Next">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
      </button>
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [perPage, setPerPage] = useState(20);
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState(new Set());

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "theme": "dark",
    "accent": "#ef3b3b",
    "fontScale": 100
  }/*EDITMODE-END*/);

  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  const total = 12994;
  const totalPages = Math.ceil(total / perPage);

  const toggle = (i) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i); else next.add(i);
      return next;
    });
  };
  const toggleAll = () => {
    setSelected(prev => prev.size === LEADS.length ? new Set() : new Set(LEADS.map((_, i) => i)));
  };

  const headerActions = (
    <>
      <button className="icon-btn" title="Quick action">
        <Icon name="zap" className="" size={16} />
      </button>
      <HeaderMenu />
      <button className="btn-primary">
        <Icon name="plus" className="" size={14} />
        Create Lead
      </button>
    </>
  );

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="leads" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar title="Leads" theme={tweaks.theme} setTheme={(v) => setTweak("theme", v)} actions={headerActions} />
        <div className="content">
          <div>
            <div className="leads-meta">
              <span className="db">
                <Icon name="database" className="" />
                Optimized view
              </span>
              <span className="dot"></span>
              <span>Updated less than a minute ago</span>
              <span className="dot"></span>
              <span>{total.toLocaleString()} of {total.toLocaleString()} leads</span>
            </div>
          </div>

          <div>
            <LeadsToolbar perPage={perPage} setPerPage={setPerPage} />
            <LeadsTable
              leads={LEADS}
              selected={selected}
              toggle={toggle}
              toggleAll={toggleAll}
              allSelected={selected.size === LEADS.length}
            />
          </div>

          <div className="leads-footer">
            <div>Showing {((page - 1) * perPage + 1).toLocaleString()}–{Math.min(page * perPage, total).toLocaleString()} of {total.toLocaleString()}</div>
            <Pager page={page} setPage={setPage} totalPages={totalPages} />
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio
          label="Mode"
          value={tweaks.theme}
          options={["dark", "light"]}
          onChange={(v) => setTweak("theme", v)}
        />
        <TweakColor
          label="Accent"
          value={tweaks.accent}
          options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]}
          onChange={(v) => setTweak("accent", v)}
        />
        <TweakSection label="Display" />
        <TweakSlider
          label="Font scale"
          value={tweaks.fontScale}
          min={85} max={115} step={5} unit="%"
          onChange={(v) => setTweak("fontScale", v)}
        />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
