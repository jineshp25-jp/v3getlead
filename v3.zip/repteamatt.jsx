/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, ScheduledContent, AssignedContent, MoreContent */
const { useState, useEffect } = React;

function Kpi({ icon, label, value, sub, color = "#3b82f6" }) {
  const accent = { "#ef4444":"accent-red","#3b82f6":"accent-blue","#a855f7":"accent-purple","#22c55e":"accent-green","#eab308":"accent-yellow","#22d3ee":"accent-cyan","#f97316":"accent-yellow" }[color] || "accent-blue";
  return (
    <div className={`card kpi ${accent}`}>
      <div className="kpi-top">
        <div className="kpi-icon" style={{ background: `color-mix(in srgb, ${color} 18%, transparent)`, color, boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${color} 30%, transparent)` }}>
          <Icon name={icon} className="" size={20} />
        </div>
        <span className="kpi-label">{label}</span>
      </div>
      <div className="kpi-val">{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [filters, setFilters] = useState({ date: "19/04/2026 – 19/05/2026", agent: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="rep-team-attendance" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Team Attendance"
          subtitle="Days worked, days absent, total hours, and mode breakdown per agent for the selected period."
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={<button className="btn-export"><Icon name="download" className="" />Export CSV</button>}
        />
        <div className="content">
          <div className="rep-filters">
            <FilterPill label="Date" value={filters.date} open={openPop==="date"} onToggle={(o)=>setOpenPop(o?"date":null)} onClear={()=>setFilter("date",null)}>
              <ScheduledContent value={filters.date} onChange={(v)=>{setFilter("date",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Agent" value={filters.agent} open={openPop==="agent"} onToggle={(o)=>setOpenPop(o?"agent":null)} onClear={()=>setFilter("agent",null)}>
              <AssignedContent value={filters.agent} onChange={(v)=>{setFilter("agent",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="More" value={null} open={openPop==="more"} onToggle={(o)=>setOpenPop(o?"more":null)}>
              <MoreContent groups={[{ group: "Filter", items: ["Branch", "Mode"] }]} onPick={()=>setOpenPop(null)} />
            </FilterPill>
          </div>

          <div className="kpi-grid kpi-grid-xs" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
            <Kpi icon="team"     color="#3b82f6" label="Agents"      value="0"   />
            <Kpi icon="layers"   color="#a855f7" label="Sessions"    value="0"   />
            <Kpi icon="clock"    color="#eab308" label="Total hours" value="0.0" />
            <Kpi icon="activity" color="#22c55e" label="Active now"  value="0"   />
          </div>

          <div className="rep-section">
            <h3>Agents</h3>
            <div className="sub">Day-by-day breakdown per agent across the selected range</div>
            <div className="empty-block" style={{ minHeight: 160 }}>
              <svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>
              No attendance recorded in the selected range.
            </div>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
