/* global React, Icon */

function KpiSparkline({ data, color }) {
  if (!data || data.length === 0) return null;
  const w = 240, h = 60, padT = 6, padB = 8;
  const max = Math.max(...data), min = Math.min(...data);
  const range = max - min || 1;
  const stepX = w / (data.length - 1);
  const pts = data.map((v, i) => {
    const x = i * stepX;
    const y = padT + (h - padT - padB) - ((v - min) / range) * (h - padT - padB);
    return [x, y];
  });
  // Smooth path
  const path = pts.reduce((acc, [x, y], i) => {
    if (i === 0) return `M ${x} ${y}`;
    const [px, py] = pts[i - 1];
    const cx = (px + x) / 2;
    return `${acc} C ${cx} ${py}, ${cx} ${y}, ${x} ${y}`;
  }, "");
  const [lx, ly] = pts[pts.length - 1];
  const gradId = `g-${color.replace(/[^a-z0-9]/gi, "")}`;
  return (
    <svg className="kpi-spark" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id={gradId} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="1" />
        </linearGradient>
      </defs>
      <path d={path} fill="none" stroke={`url(#${gradId})`} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={lx} cy={ly} r="3" fill={color} />
      <circle cx={lx} cy={ly} r="6" fill={color} opacity="0.25" />
    </svg>
  );
}

function KPI({ label, value, icon, color, chip, chipDir, sub, subDir, progress, spark, featured }) {
  const chipUp = chipDir === "up";
  return (
    <div className={`card kpi ${featured ? "is-featured" : ""}`} style={{ "--accent": color }}>
      <div className="kpi-top">
        <div className="kpi-icon" style={{ color, borderColor: `color-mix(in srgb, ${color} 55%, transparent)` }}>
          <Icon name={icon} className="" size={18} />
        </div>
        <span className={`kpi-chip ${chipUp ? "up" : "down"}`} style={{ color, borderColor: `color-mix(in srgb, ${color} 35%, transparent)`, background: `color-mix(in srgb, ${color} 10%, transparent)` }}>
          <span className="kpi-chip-arrow">{chipUp ? "↑" : "↓"}</span>
          {chip}
        </span>
      </div>
      <div className="kpi-label">{label}</div>
      <div className="kpi-val">{value}</div>
      {progress != null ? (
        <div className={`kpi-sub-line ${subDir}`} style={{ color }}>
          <span className="kpi-sub-arrow">•</span>
          {sub}
        </div>
      ) : (
        <div className={`kpi-sub-line ${subDir}`} style={{ color }}>
          <span className="kpi-sub-arrow">{subDir === "down" ? "↓" : subDir === "up" ? "↑" : "•"}</span>
          {sub}
        </div>
      )}
      {spark && (
        <div className="kpi-spark-wrap">
          <KpiSparkline data={spark} color={color} />
        </div>
      )}
    </div>
  );
}

window.KPI = KPI;
