/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, ScheduledContent, AssignedContent, MoreContent */
const { useState, useEffect } = React;

const CALLS = [
  { dir: "Inbound",  from: "+917902454646",  to: "+916238501008",  agent: "Nasiha", stat: "completed", dur: "1s",     talk: "1s",     rec: true,  when: "1 day ago" },
  { dir: "Inbound",  from: "+918606260070",  to: "+916238501008",  agent: "Nasiha", stat: "completed", dur: "1s",     talk: "1s",     rec: true,  when: "1 day ago" },
  { dir: "Inbound",  from: "+918070970135",  to: "+916238501008",  agent: "Nasiha", stat: "completed", dur: "1s",     talk: "1s",     rec: true,  when: "1 day ago" },
  { dir: "Outbound", from: "+916238501008",  to: "+917902454646",  agent: "Nasiha", stat: "completed", dur: "1s",     talk: "1s",     rec: true,  when: "1 day ago" },
  { dir: "Outbound", from: "+916238501008",  to: "+919020203009",  agent: "Nasiha", stat: "completed", dur: "1s",     talk: "1s",     rec: true,  when: "1 day ago" },
  { dir: "Outbound", from: "+916238501008",  to: "+918509973614",  agent: "Nasiha", stat: "completed", dur: "1s",     talk: "1s",     rec: true,  when: "1 day ago" },
  { dir: "Outbound", from: "+916238501008",  to: "+919633167249",  agent: "Nasiha", stat: "completed", dur: "1s",     talk: "1s",     rec: true,  when: "1 day ago" },
  { dir: "Inbound",  from: "+917902454646",  to: "+916238501008",  agent: "Nasiha", stat: "missed",    dur: "1s",     talk: "1s",     rec: false, when: "1 day ago" },
  { dir: "Outbound", from: "+917946350369",  to: "+919061636063",  agent: "Shad",   stat: "completed", dur: "56s",    talk: "56s",    rec: true,  when: "4 days ago" },
  { dir: "Outbound", from: "+917946350369",  to: "+919567622661",  agent: "Shad",   stat: "initiated", dur: "—",      talk: "—",      rec: false, when: "4 days ago" },
  { dir: "Outbound", from: "+917946350369",  to: "+917441123462",  agent: "Shad",   stat: "initiated", dur: "—",      talk: "—",      rec: false, when: "4 days ago" },
  { dir: "Outbound", from: "+917946350369",  to: "+919142583159",  agent: "Shad",   stat: "completed", dur: "25s",    talk: "25s",    rec: true,  when: "4 days ago" },
  { dir: "Outbound", from: "+917946350369",  to: "+919633603391",  agent: "Shad",   stat: "completed", dur: "45s",    talk: "45s",    rec: true,  when: "4 days ago" },
  { dir: "Outbound", from: "+917946350369",  to: "+917907346811",  agent: "Shad",   stat: "completed", dur: "43s",    talk: "43s",    rec: true,  when: "4 days ago" },
  { dir: "Outbound", from: "+917946350369",  to: "+919046002786",  agent: "Muhammed Nihad", stat: "initiated", dur: "—", talk: "—",   rec: false, when: "4 days ago" },
  { dir: "Outbound", from: "+917946350369",  to: "+918509917897",  agent: "Shad",   stat: "completed", dur: "1m 43s", talk: "1m 43s", rec: true,  when: "4 days ago" },
  { dir: "Outbound", from: "+917946350369",  to: "+919995377301",  agent: "Shad",   stat: "completed", dur: "51s",    talk: "51s",    rec: true,  when: "4 days ago" },
  { dir: "Outbound", from: "+917946350369",  to: "+919895900422",  agent: "Muhammed Nihad", stat: "completed", dur: "1m 16s", talk: "1m 16s", rec: true, when: "4 days ago" },
  { dir: "Outbound", from: "+917946350369",  to: "+919633100002",  agent: "Muhammed Nihad", stat: "completed", dur: "8s", talk: "8s", rec: true, when: "4 days ago" },
  { dir: "Outbound", from: "+917946350369",  to: "+919946448241",  agent: "Shad",   stat: "initiated", dur: "—",      talk: "—",      rec: false, when: "4 days ago" },
];

function DirCell({ dir }) {
  const cls = dir.toLowerCase();
  return (
    <span className={`ch-dir ${cls}`}>
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M5 9l-2-2 7-7M3 7h13M19 15l2 2-7 7M21 17H8"/>
      </svg>
      {dir}
      <svg className="caret" viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>
    </span>
  );
}

function StatCell({ stat }) {
  return <span className={`ch-stat ${stat}`}>{stat[0].toUpperCase() + stat.slice(1)}</span>;
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [pageSize, setPageSize] = useState(20);
  const [filters, setFilters] = useState({ status: null, direction: null, lead: null, agent: null, date: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="rep-call-history" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Call History"
          subtitle="View and manage all calls made through your IVR providers"
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={
            <button className="btn-export">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92V20a2 2 0 0 1-2.18 2A19.86 19.86 0 0 1 2 4.18 2 2 0 0 1 4 2h3.09a1 1 0 0 1 1 .75l1 4a1 1 0 0 1-.27 1L7.21 9.21a16 16 0 0 0 7.58 7.58l1.46-1.46a1 1 0 0 1 1-.27l4 1a1 1 0 0 1 .75 1z"/></svg>
              Manage Providers
            </button>
          }
        />
        <div className="content">
          <div className="cr-tabs-row">
            <a href="CallReport.html" className="cr-tab">Call Report</a>
            <a href="CallHistory.html" className="cr-tab active">Call History</a>
          </div>

          <div className="ch-section">
            <div className="ch-toolbar">
              <div className="ch-search-row">
                <div className="leads-search">
                  <Icon name="search" className="" />
                  <input placeholder="Search phone numbers or lead names…" />
                </div>
                <button className="toolbar-btn"><Icon name="columns" className="" />Columns</button>
                <select className="per-page-select" value={pageSize} onChange={(e) => setPageSize(Number(e.target.value))}>
                  <option>10</option><option>20</option><option>50</option><option>100</option>
                </select>
              </div>
              <div className="ch-count">5,536 calls</div>
              <div className="ch-filters">
                <FilterPill label="Status" value={filters.status} open={openPop==="status"} onToggle={(o)=>setOpenPop(o?"status":null)} onClear={()=>setFilter("status",null)}>
                  <AssignedContent value={filters.status} onChange={(v)=>{setFilter("status",v);setOpenPop(null);}} />
                </FilterPill>
                <FilterPill label="Direction" value={filters.direction} open={openPop==="direction"} onToggle={(o)=>setOpenPop(o?"direction":null)} onClear={()=>setFilter("direction",null)}>
                  <AssignedContent value={filters.direction} onChange={(v)=>{setFilter("direction",v);setOpenPop(null);}} />
                </FilterPill>
                <FilterPill label="Lead Status" value={filters.lead} open={openPop==="lead"} onToggle={(o)=>setOpenPop(o?"lead":null)} onClear={()=>setFilter("lead",null)}>
                  <AssignedContent value={filters.lead} onChange={(v)=>{setFilter("lead",v);setOpenPop(null);}} />
                </FilterPill>
                <FilterPill label="Agent" value={filters.agent} open={openPop==="agent"} onToggle={(o)=>setOpenPop(o?"agent":null)} onClear={()=>setFilter("agent",null)}>
                  <AssignedContent value={filters.agent} onChange={(v)=>{setFilter("agent",v);setOpenPop(null);}} />
                </FilterPill>
                <FilterPill label="Date" value={filters.date} open={openPop==="date"} onToggle={(o)=>setOpenPop(o?"date":null)} onClear={()=>setFilter("date",null)}>
                  <ScheduledContent value={filters.date} onChange={(v)=>{setFilter("date",v);setOpenPop(null);}} />
                </FilterPill>
                <FilterPill label="More" value={null} open={openPop==="more"} onToggle={(o)=>setOpenPop(o?"more":null)}>
                  <MoreContent groups={[{ group: "Filter", items: ["Provider", "Duration"] }]} onPick={()=>setOpenPop(null)} />
                </FilterPill>
              </div>
            </div>

            <table className="leads-table" style={{ marginTop: 10 }}>
              <thead>
                <tr>
                  <th style={{ width: 24 }}></th>
                  <th>Direction</th>
                  <th>From</th>
                  <th>To</th>
                  <th>Agent</th>
                  <th>Status</th>
                  <th>Duration</th>
                  <th>Talk Time</th>
                  <th>Recording</th>
                  <th>When</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {CALLS.map((c, i) => (
                  <tr key={i}>
                    <td style={{ paddingRight: 0 }}>
                      <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: "var(--text-3)" }}><path d="m6 9 6 6 6-6"/></svg>
                    </td>
                    <td><DirCell dir={c.dir} /></td>
                    <td><span className="ch-num">{c.from}</span></td>
                    <td><span className="ch-num">{c.to}</span></td>
                    <td style={{ fontWeight: 500 }}>{c.agent}</td>
                    <td><StatCell stat={c.stat} /></td>
                    <td className="tt-cell">{c.dur}</td>
                    <td><span className="ch-talk">{c.talk}</span></td>
                    <td>
                      {c.rec ? (
                        <button className="ch-rec" title="Play recording">
                          <svg viewBox="0 0 24 24" width="13" height="13" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
                        </button>
                      ) : (
                        <span className="ch-rec empty">—</span>
                      )}
                    </td>
                    <td><span className="ch-when">{c.when}</span></td>
                    <td style={{ textAlign: "right" }}>
                      <button className="ch-action" aria-label="More">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="5" r="1.3" fill="currentColor"/>
                          <circle cx="12" cy="12" r="1.3" fill="currentColor"/>
                          <circle cx="12" cy="19" r="1.3" fill="currentColor"/>
                        </svg>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="rep-pager">
              <div></div>
              <div className="rep-pager-right">
                <button className="pager-btn">Previous</button>
                <button className="pager-btn">Next</button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
