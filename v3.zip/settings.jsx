/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider */
const { useState, useEffect } = React;

const SECTIONS = [
  {
    title: "Lead Settings",
    sub: "Manage lead sources, statuses, purposes, custom fields, and assignment rules",
    icon: "leads",
    color: "#ef4444",
    items: [
      { label: "Lead Sources",       icon: "tag",       href: "LeadSources.html" },
      { label: "Lead Statuses",      icon: "tasks",     href: "LeadStatuses.html" },
      { label: "Lead Purposes",      icon: "target",    href: "LeadPurposes.html" },
      { label: "WhatsApp Templates", icon: "chat",      href: "WhatsAppTemplates.html" },
      { label: "Custom Fields",      icon: "columns",   href: "CustomFields.html" },
      { label: "Lead Assignment",    icon: "user-plus", href: "LeadAssignment.html" },
    ] },
  {
    title: "Deal Settings",
    sub: "Manage deal types, statuses, custom fields, and numbering",
    icon: "wallet",
    color: "#3b82f6",
    items: [
      { label: "Deal Types",    icon: "tag",     href: "Deals.html" },
      { label: "Deal Statuses", icon: "tasks",   href: "Deals.html" },
      { label: "Custom Fields", icon: "columns", href: "CustomFields.html" },
      { label: "Numbering",     icon: "spark",   href: "Deals.html" },
    ] },
  {
    title: "Task Settings",
    sub: "Manage call statuses, feedback templates, and task configuration",
    icon: "tasks",
    color: "#a855f7",
    items: [
      { label: "Call Statuses",        icon: "phone", href: "Calls.html" },
      { label: "Feedback Templates",   icon: "chat",  href: "Tasks.html", active: true },
    ] },
  {
    title: "General Settings",
    sub: "Manage account, branches, notifications and configuration",
    icon: "settings",
    color: "#22c55e",
    items: [
      { label: "Account",                icon: "customers", href: "Account.html" },
      { label: "Billing",                icon: "wallet",    href: "Account.html" },
      { label: "Branches",               icon: "layers",    href: "Branches.html" },
      { label: "Entity Terminology",     icon: "edit",      href: "EntityTerminology.html" },
      { label: "Date & Time Format",     icon: "calendar",  href: "DateTimeFormat.html" },
      { label: "Notification Preferences", icon: "bell",    href: "NotificationPrefs.html" },
    ] },
  {
    title: "Automations",
    sub: "Create and manage automated workflows and triggers",
    icon: "zap",
    color: "#eab308",
    items: [
      { label: "Workflows", icon: "zap", href: "Campaigns.html" },
    ] },
  {
    title: "Integrations",
    sub: "Connect external services, APIs, and lead providers",
    icon: "campaigns",
    color: "#22d3ee",
    items: [
      { label: "All Integrations", icon: "campaigns", href: "Campaigns.html" },
    ] },
  {
    title: "Attendance",
    sub: "Configure attendance modes and check-out photo requirement",
    icon: "calendar",
    color: "#f97316",
    items: [
      { label: "Modes & Settings", icon: "calendar", href: "Attendance.html" },
    ] },
  {
    title: "Users & Roles",
    sub: "Manage users, roles, teams, and invitations",
    icon: "team",
    color: "#ec4899",
    items: [
      { label: "Users",       icon: "customers", href: "Users.html" },
      { label: "Roles",       icon: "shield",    href: "Roles.html" },
      { label: "Teams",       icon: "team",      href: "Teams.html" },
      { label: "Invitations", icon: "user-plus", href: "Invitations.html" },
    ] },
];

function SetCard({ s }) {
  return (
    <div className="set-card" style={{ "--accent": s.color }}>
      <div className="set-head">
        <div className="set-icon"><Icon name={s.icon} className="" /></div>
        <div>
          <h3 className="set-title">{s.title}</h3>
          <div className="set-sub">{s.sub}</div>
        </div>
      </div>
      <div className="set-list">
        {s.items.map((it) => (
          <a
            key={it.label}
            href={it.href || "#"}
            className={`set-link ${it.active ? "active" : ""}`}
            onClick={(e) => { if (!it.href || it.href === "#") e.preventDefault(); }}
          >
            <Icon name={it.icon} className="set-link-icon" />
            <span>{it.label}</span>
            <span className="set-chev">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
            </span>
          </a>
        ))}
      </div>
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "theme": "dark",
    "accent": "#ef3b3b",
    "fontScale": 100
  }/*EDITMODE-END*/);

  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="settings" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Settings"
          subtitle="Manage your business configuration and preferences"
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
        />
        <div className="content">
          <div className="set-grid">
            {SECTIONS.map((s) => <SetCard key={s.title} s={s} />)}
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent}
          options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale}
          min={85} max={115} step={5} unit="%"
          onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
