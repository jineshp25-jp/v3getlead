/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, ScheduledContent, AssignedContent, MoreContent */
const { useState, useEffect } = React;

const DEALS = [
  { id: "DL-2026-00001", name: "Deal dashboard Testing", lead: "JineeshJp", source: "KTX", leadStatus: "Interested", dealStatus: "New", amount: "₹500", agent: "Arya", date: "13/05/2026", time: "814d" },
];

function Kpi({ icon, label, value, sub, color = "#3b82f6" }) {
  const accent = { "#ef4444":"accent-red","#3b82f6":"accent-blue","#a855f7":"accent-purple","#22c55e":"accent-green","#eab308":"accent-yellow","#22d3ee":"accent-cyan","#f97316":"accent-yellow" }[color] || "accent-blue";
  return (
    <div className={`card kpi ${accent}`}>
      <div className="kpi-top">
        <div className="kpi-icon" style={{ background: `color-mix(in srgb, ${color} 18%, transparent)`, color, boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${color} 30%, transparent)` }}>
          <Icon name={icon} className="" size={20} />
        </div>
        <span className="kpi-label">{label}</span>
      </div>
      <div className="kpi-val">{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [filters, setFilters] = useState({ date: "19/04/2026 – 19/05/2026", stage: null, status: null });
  const [openPop, setOpenPop] = useState(null);
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="rep-lead-conversion" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="Lead Conversion Report"
          subtitle="Track every deal alongside its originating lead. See which leads converted, how long it took, and which sources drive the most deals."
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={<button className="btn-export"><Icon name="download" className="" />Export CSV</button>}
        />
        <div className="content">
          <div className="rep-filters">
            <FilterPill label="Date" value={filters.date} open={openPop==="date"} onToggle={(o)=>setOpenPop(o?"date":null)} onClear={()=>setFilter("date",null)}>
              <ScheduledContent value={filters.date} onChange={(v)=>{setFilter("date",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Deal Stage" value={filters.stage} open={openPop==="stage"} onToggle={(o)=>setOpenPop(o?"stage":null)} onClear={()=>setFilter("stage",null)}>
              <AssignedContent value={filters.stage} onChange={(v)=>{setFilter("stage",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="Deal Status" value={filters.status} open={openPop==="status"} onToggle={(o)=>setOpenPop(o?"status":null)} onClear={()=>setFilter("status",null)}>
              <AssignedContent value={filters.status} onChange={(v)=>{setFilter("status",v);setOpenPop(null);}} />
            </FilterPill>
            <FilterPill label="More" value={null} open={openPop==="more"} onToggle={(o)=>setOpenPop(o?"more":null)}>
              <MoreContent groups={[{ group: "Filter", items: ["Assigned To", "Source"] }]} onPick={()=>setOpenPop(null)} />
            </FilterPill>
          </div>

          <div className="kpi-grid kpi-grid-compact" style={{ gridTemplateColumns: "repeat(5, 1fr)" }}>
            <Kpi icon="users-2"  color="#3b82f6" label="Total Leads"        value="32"     sub="Created in this period" />
            <Kpi icon="trend-up" color="#a855f7" label="Total Deals"        value="1"      sub="3.1% conversion rate" />
            <Kpi icon="target"   color="#eab308" label="Open Deals"         value="1"      sub="100% of total — in progress" />
            <Kpi icon="star"     color="#22c55e" label="Won Deals"          value="0"      sub="Win rate: 0%" />
            <Kpi icon="clock"    color="#22d3ee" label="Avg Conversion Time" value="814.3d" sub="Average from lead to deal" />
          </div>

          <div className="rep-section">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 }}>
              <div>
                <h3>Converted Deals</h3>
                <div className="sub">Each row is a deal with its originating lead, status, source, and how long it took to convert.</div>
              </div>
              <span style={{ fontSize: 12.5, color: "var(--text-3)" }}>1 deal</span>
            </div>
            <table className="leads-table">
              <thead>
                <tr>
                  <th>Deal</th><th>Lead</th><th>Lead Status</th><th>Deal Status</th>
                  <th style={{ textAlign:"right" }}>Amount</th>
                  <th>Assigned To</th><th>Converted On</th><th>Time to Convert</th>
                </tr>
              </thead>
              <tbody>
                {DEALS.map((d, i) => (
                  <tr key={i}>
                    <td>
                      <div style={{ fontWeight: 600 }}>{d.id}</div>
                      <div style={{ fontSize: 12, color: "var(--text-3)", marginTop: 2 }}>{d.name}</div>
                    </td>
                    <td>
                      <div style={{ fontWeight: 600 }}>{d.lead}</div>
                      <div style={{ fontSize: 12, color: "var(--text-3)", fontStyle: "italic", marginTop: 2 }}>{d.source}</div>
                    </td>
                    <td><span className="pill pill-pink pill-mini">{d.leadStatus}</span></td>
                    <td><span className="pill pill-blue pill-mini">{d.dealStatus}</span></td>
                    <td className="amount-cell" style={{ textAlign: "right" }}>{d.amount}</td>
                    <td><span className="agent-tag">{d.agent}</span></td>
                    <td className="tt-cell" style={{ color: "var(--text-2)" }}>{d.date}</td>
                    <td className="tt-cell" style={{ fontWeight: 600 }}>{d.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
