/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider, FilterPill, ScheduledContent */
const { useState, useEffect } = React;

const DELETED = [
  { name: "Unnamed",     phone: "+91 74700 30700", status: "New", agent: "Fahmida",       source: "GLDialer",  by: "KTX GLOBAL", at: "15/05/2026, 12:33 pm" },
  { name: "hgtyh",       phone: "+91 87542 18541", status: "New", agent: "tester",         source: "Instagram", by: "KTX GLOBAL", at: "15/05/2026, 12:33 pm" },
  { name: "Testibggg",   phone: "+91 96245 12542", status: "New", agent: "Fahmida",        source: "CMA",       by: "Fahmida",    at: "15/05/2026, 12:07 pm" },
  { name: "Hari test",   phone: "+91 86890 73322", status: "New", agent: "Fahmida",        source: "INSTAGRAM", by: "KTX GLOBAL", at: "14/05/2026, 2:35 pm" },
  { name: "testing",     phone: "+91 86680 56985", status: "New", agent: "Fahmida",        source: "Direct",    by: "KTX GLOBAL", at: "07/05/2026, 1:57 pm" },
  { name: "testing",     phone: "+91 69548 75698", status: "New", agent: "Arya",           source: "Direct",    by: "KTX GLOBAL", at: "07/05/2026, 12:27 pm" },
  { name: "Unnamed Lead",phone: "+91 99947 66465", status: "New", agent: "Meharin Zainab M", source: "Reboot",   by: "Unknown",     at: "07/05/2026, 5:30 am" },
  { name: "Unnamed Lead",phone: "+91 87118 88222", status: "New", agent: "Meharin Zainab M", source: "Reboot",   by: "Unknown",     at: "07/05/2026, 5:30 am" },
  { name: "Unnamed Lead",phone: "+91 99955 66098", status: "New", agent: "Meharin Zainab M", source: "Reboot",   by: "Unknown",     at: "07/05/2026, 5:30 am" },
  { name: "Unnamed Lead",phone: "+91 73608 55763", status: "New", agent: "Meharin Zainab M", source: "Reboot",   by: "Unknown",     at: "07/05/2026, 5:30 am" },
  { name: "Unnamed Lead",phone: "+91 86006 24368", status: "New", agent: "Meharin Zainab M", source: "Reboot",   by: "Unknown",     at: "07/05/2026, 5:30 am" },
  { name: "Unnamed Lead",phone: "+91 94558 16812", status: "New", agent: "Meharin Zainab M", source: "Reboot",   by: "Unknown",     at: "07/05/2026, 5:30 am" },
  { name: "Unnamed Lead",phone: "+91 62826 24884", status: "New", agent: "Meharin Zainab M", source: "Reboot",   by: "Unknown",     at: "07/05/2026, 5:30 am" },
  { name: "Unnamed Lead",phone: "+91 85472 19061", status: "New", agent: "Meharin Zainab M", source: "Reboot",   by: "Unknown",     at: "07/05/2026, 5:30 am" },
  { name: "Unnamed Lead",phone: "+91 85920 07499", status: "New", agent: "Meharin Zainab M", source: "Reboot",   by: "Unknown",     at: "07/05/2026, 5:30 am" },
];

function Kpi({ icon, label, value, sub, color = "#3b82f6" }) {
  const accentMap = {
    "#ef4444": "accent-red", "#3b82f6": "accent-blue", "#a855f7": "accent-purple",
    "#22c55e": "accent-green", "#eab308": "accent-yellow", "#22d3ee": "accent-cyan",
    "#f97316": "accent-yellow" };
  const accent = accentMap[color] || "accent-blue";
  return (
    <div className={`card kpi ${accent}`}>
      <div className="kpi-top">
        <div className="kpi-icon" style={{
          background: `color-mix(in srgb, ${color} 18%, transparent)`,
          color: color,
          boxShadow: `inset 0 0 0 1px color-mix(in srgb, ${color} 30%, transparent)` }}>
          <Icon name={icon} className="" size={20} />
        </div>
        <span className="kpi-label">{label}</span>
      </div>
      <div className="kpi-val">{value}</div>
      {sub && <div className="kpi-sub">{sub}</div>}
    </div>
  );
}

function RestoreConfirmModal({ open, onClose, onConfirm, lead }) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" role="dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 460 }}>
        <div className="modal-head">
          <div style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
            <div style={{
              width: 40, height: 40, borderRadius: 10, flexShrink: 0,
              background: "color-mix(in srgb, #22c55e 18%, transparent)",
              color: "#22c55e",
              boxShadow: "inset 0 0 0 1px color-mix(in srgb, #22c55e 30%, transparent)",
              display: "grid", placeItems: "center" }}>
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>
            </div>
            <div>
              <h2 className="modal-title">Restore lead?</h2>
              <div className="modal-sub">{lead ? <><strong style={{ color: "var(--text-1)" }}>{lead.name}</strong> ({lead.phone}) will be moved back to your active leads.</> : "This lead will be moved back to your active leads."}</div>
            </div>
          </div>
          <button className="modal-close" aria-label="Close" onClick={onClose}>
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 6-12 12M6 6l12 12"/></svg>
          </button>
        </div>
        <div className="modal-foot">
          <button className="btn-cancel" onClick={onClose}>Cancel</button>
          <button
            className="btn-primary"
            style={{ background: "#16a34a", boxShadow: "0 1px 0 rgba(255,255,255,0.18) inset, 0 6px 14px -6px rgba(22,163,74,0.5)" }}
            onClick={() => { onConfirm(); onClose(); }}
          >
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: 6 }}><path d="M5 12l5 5L20 7"/></svg>
            Confirm Restore
          </button>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [q, setQ] = useState("");
  const [filters, setFilters] = useState({ date: "Date" });
  const [openPop, setOpenPop] = useState(null);
  const [restoreLead, setRestoreLead] = useState(null);
  const [restored, setRestored] = useState(new Set());
  const setFilter = (k, v) => setFilters(f => ({ ...f, [k]: v }));

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="rep-deleted-leads" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title={<span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
            <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="var(--brand)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>
            Deleted Leads
          </span>}
          subtitle="All soft-deleted leads across your account. Restore any lead within 30 days, or filter to audit deletions by team member."
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
          actions={<button className="btn-export"><Icon name="download" className="" />Export CSV</button>}
        />
        <div className="content">
          <div className="rep-filters">
            <FilterPill label="Date" value={filters.date} open={openPop==="date"} onToggle={(o)=>setOpenPop(o?"date":null)} onClear={()=>setFilter("date",null)}>
              <ScheduledContent value={filters.date} onChange={(v)=>{setFilter("date",v);setOpenPop(null);}} />
            </FilterPill>
          </div>

          <div className="kpi-grid" style={{ gridTemplateColumns: "repeat(4, 1fr)" }}>
            <Kpi icon="trash"    color="#ef4444" label="Deleted Leads" value="18,154" sub="Soft-deleted, restorable within 30 days" />
            <Kpi icon="clock"    color="#a855f7" label="This Month" value="412" sub="Deleted in the selected period" />
            <Kpi icon="users-2"  color="#3b82f6" label="Most Deletions" value={<span style={{display:"inline-flex",flexDirection:"column"}}><span style={{ fontSize: '20px', fontWeight: 700 }}>KTX GLOBAL</span><span style={{ fontSize: '12.5px', color: "var(--text-3)" }}>9,820 leads</span></span>} sub="Team member with the most deletions" />
            <Kpi icon="reports"  color="#22c55e" label="Top Source" value={<span style={{display:"inline-flex",flexDirection:"column"}}><span style={{ fontSize: '20px', fontWeight: 700 }}>Reboot</span><span style={{ fontSize: '12.5px', color: "var(--text-3)" }}>6,431 leads</span></span>} sub="Most common source among deleted leads" />
          </div>

          <div className="rep-section">
            <div className="dl-search-bar">
              <div className="dl-search-input">
                <Icon name="search" className="" />
                <input placeholder="Search by name, phone, email, or assigned agent…" value={q} onChange={(e) => setQ(e.target.value)} />
                {q && (
                  <button className="dl-search-clear" onClick={() => setQ("")} aria-label="Clear">
                    <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 6-12 12M6 6l12 12"/></svg>
                  </button>
                )}
              </div>
              <span className="dl-count-chip">
                <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>
                18,154 deleted leads
              </span>
            </div>

            <table className="leads-table">
              <thead>
                <tr>
                  <th>Lead</th>
                  <th>Status at deletion</th>
                  <th>Assigned to</th>
                  <th>Source</th>
                  <th>Deleted by</th>
                  <th>Deleted at</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {DELETED.map((d, i) => (
                  <tr key={i} style={ restored.has(i) ? { opacity: 0.45 } : null }>
                    <td>
                      <div className="dl-lead-cell">
                        <span className="dl-avatar" style={{ background: `linear-gradient(135deg, hsl(${(d.name.charCodeAt(0) * 23) % 360}, 65%, 55%), hsl(${(d.name.charCodeAt(0) * 23 + 40) % 360}, 65%, 45%))` }}>
                          {d.name.split(" ").map(s=>s[0]).slice(0,2).join("").toUpperCase()}
                        </span>
                        <div className="dl-lead-info">
                          <div className="dl-lead-name">{d.name}</div>
                          <div className="dl-lead-meta">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92V20a2 2 0 0 1-2.18 2A19.86 19.86 0 0 1 2 4.18 2 2 0 0 1 4 2h3.09a1 1 0 0 1 1 .75l1 4a1 1 0 0 1-.27 1L7.21 9.21a16 16 0 0 0 7.58 7.58l1.46-1.46a1 1 0 0 1 1-.27l4 1a1 1 0 0 1 .75 1z"/></svg>
                            {d.phone}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className="dl-status">
                        <span className="dl-status-dot"></span>
                        {d.status}
                      </span>
                    </td>
                    <td style={{ color: "var(--text-1)", fontWeight: 500 }}>{d.agent}</td>
                    <td><span className="tag-soft">{d.source}</span></td>
                    <td>
                      {d.by === "KTX GLOBAL" ? <span className="tag-soft">KTX GLOBAL</span> :
                       d.by === "Fahmida" ? <span className="agent-tag">Fahmida</span> :
                       <span style={{ color: "var(--text-3)" }}>{d.by}</span>}
                    </td>
                    <td className="tt-cell" style={{ color: "var(--text-2)" }}>{d.at}</td>
                    <td style={{ textAlign: "right" }}>
                      <button className="btn-restore" disabled={restored.has(i)} onClick={() => setRestoreLead({ idx: i, ...d })}>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>
                        {restored.has(i) ? "Restored" : "Restore"}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="rep-pager">
              <div>Showing 1 to 15 of 18,154 deleted leads</div>
              <div className="rep-pager-right">
                <button className="pager-btn">Previous</button>
                <button className="pager-btn active">1</button>
                <button className="pager-btn">2</button>
                <button className="pager-btn">3</button>
                <button className="pager-btn">4</button>
                <button className="pager-btn">5</button>
                <span className="pager-ellipsis">…</span>
                <button className="pager-btn">1211</button>
                <button className="pager-btn">Next</button>
              </div>
            </div>
          </div>
        </div>
      </main>

      <RestoreConfirmModal
        open={!!restoreLead}
        lead={restoreLead}
        onClose={() => setRestoreLead(null)}
        onConfirm={() => setRestored((prev) => { const n = new Set(prev); n.add(restoreLead.idx); return n; })}
      />

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
