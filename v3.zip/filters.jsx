/* global React, Icon */
const { useState: filtUseState, useEffect: filtUseEffect, useRef: filtUseRef } = React;

function ChevDown() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>;
}

function useOutsideClose(ref, onClose, when) {
  React.useEffect(() => {
    if (!when) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    document.addEventListener("mousedown", onDoc);
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [when]);
}

function FilterPill({ label, value, open, onToggle, onClear, children }) {
  const ref = React.useRef(null);
  useOutsideClose(ref, () => open && onToggle(false), open);
  return (
    <div className="filter-pill-wrap" ref={ref}>
      <button className={`filter-pill ${open ? "active" : ""} ${value ? "has-value" : ""}`} onClick={() => onToggle(!open)}>
        <span>{label}{value ? <span className="pill-val"> | {value}</span> : null}</span>
        {value && onClear ? (
          <span
            className="pill-x"
            role="button"
            tabIndex={-1}
            onClick={(e) => { e.stopPropagation(); onClear(); }}
            aria-label="Clear filter"
          >
            <svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="m18 6-12 12M6 6l12 12"/></svg>
          </span>
        ) : <ChevDown />}
      </button>
      {open && <div className="filter-pop">{children}</div>}
    </div>
  );
}

// Scheduled popover
const SCHED_PRESETS = ["Today", "Yesterday", "This Week", "Last Week", "This Month", "Last Month", "Last 30 Days", "Last 90 Days", "All Time"];
function ScheduledContent({ value, onChange }) {
  const [from, setFrom] = React.useState("");
  const [to, setTo] = React.useState("");
  return (
    <div className="fpop">
      <div className="fpop-label">Quick presets</div>
      <div className="fpop-chips">
        {SCHED_PRESETS.map(p => (
          <button key={p} className={`chip-btn ${value === p ? "active" : ""}`} onClick={() => onChange(p)}>{p}</button>
        ))}
      </div>
      <div className="fpop-daterange">
        <label className="fpop-field">
          <span>From</span>
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </label>
        <label className="fpop-field">
          <span>To</span>
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </label>
      </div>
    </div>
  );
}

const STATUS_OPTIONS = ["Open", "Overdue", "Completed", "Cancelled"];
function StatusContent({ value, onChange }) {
  const [q, setQ] = React.useState("");
  const items = STATUS_OPTIONS.filter(s => s.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="fpop">
      <div className="fpop-search">
        <Icon name="search" className="" />
        <input placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} autoFocus />
      </div>
      <div className="fpop-list">
        {items.map(s => (
          <button key={s} className={`fpop-item ${value === s ? "active" : ""}`} onClick={() => onChange(s)}>
            <span>{s}</span>
            {value === s && <Icon name="check" className="" size={14} />}
          </button>
        ))}
        {items.length === 0 && <div className="fpop-empty">No matches</div>}
      </div>
    </div>
  );
}

const TEAM = [
  "Abhinaraj", "Alfiya fathima kv", "Ardhra ganesh pg", "Arjun M",
  "Arya", "Ayisha Noura.B,", "Ayishathul Hudha", "Aysha fidha k",
  "Fathima rana kp", "Karan S.", "Muhammed Nihad", "Priya M.", "Raj P.",
];
function AssignedContent({ value, onChange }) {
  const [q, setQ] = React.useState("");
  const items = TEAM.filter(n => n.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="fpop">
      <div className="fpop-search">
        <Icon name="search" className="" />
        <input placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} autoFocus />
      </div>
      <div className="fpop-list fpop-list-scroll">
        {items.map(n => (
          <button key={n} className={`fpop-item ${value === n ? "active" : ""}`} onClick={() => onChange(n)}>
            <span>{n}</span>
            {value === n && <Icon name="check" className="" size={14} />}
          </button>
        ))}
        {items.length === 0 && <div className="fpop-empty">No matches</div>}
      </div>
    </div>
  );
}

function MoreContent({ groups, onPick }) {
  const [q, setQ] = React.useState("");
  const filtered = groups
    .map(g => ({ ...g, items: g.items.filter(i => i.toLowerCase().includes(q.toLowerCase())) }))
    .filter(g => g.items.length);
  return (
    <div className="fpop">
      <div className="fpop-search">
        <Icon name="search" className="" />
        <input placeholder="Find a filter…" value={q} onChange={(e) => setQ(e.target.value)} autoFocus />
      </div>
      <div className="fpop-list">
        {filtered.map(g => (
          <React.Fragment key={g.group}>
            <div className="fpop-group">{g.group}</div>
            {g.items.map(it => (
              <button key={it} className="fpop-item" onClick={() => onPick(it)}>
                <span>{it}</span>
              </button>
            ))}
          </React.Fragment>
        ))}
        {filtered.length === 0 && <div className="fpop-empty">No matches</div>}
      </div>
    </div>
  );
}

Object.assign(window, {
  ChevDown, FilterPill,
  ScheduledContent, StatusContent, AssignedContent, MoreContent });
