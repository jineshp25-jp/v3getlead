/* global React, ReactDOM, Icon, Sidebar, Topbar, TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakColor, TweakSlider */
const { useState, useEffect } = React;

const TABS = [
  { id: "users",       label: "Users",       icon: "customers" },
  { id: "teams",       label: "Teams",       icon: "team" },
  { id: "invitations", label: "Invitations", icon: "chat" },
  { id: "roles",       label: "Roles",       icon: "shield" },
];

const USERS = [
  { name: "safa gold", verified: true, email: "safa@gmail.com", phone: "+917888654565", role: "test lead assign", status: "inactive", joined: "15/05/2026" },
  { name: "tester",    verified: true, email: "test12@gmail.com", phone: "+918457852541", role: "test lead assign", status: "inactive", joined: "15/05/2026" },
  { name: "Ayishathul Hudha", verified: true, email: "hudhahazrath@gmail.com", phone: "+916282098607", role: "Member", status: "active", joined: "12/05/2026" },
  { name: "Fathima Rinsha",   verified: true, email: "fathimarinsha6223@gmail.com", phone: "+919037726223", role: "Member", status: "active", joined: "12/05/2026" },
  { name: "Princy",           verified: true, email: "princyphr007@gmail.com", phone: "+918304938331", role: "Member", status: "active", joined: "12/05/2026" },
  { name: "Sajana",           verified: true, email: "sajanat729@gmail.com", phone: "+919605512315", role: "Member", status: "active", joined: "12/05/2026" },
  { name: "Abhinaraj",        verified: true, email: "abhinaraj14@gmail.com", phone: "+918606921415", role: "Member", status: "active", joined: "12/05/2026" },
  { name: "Hana Hashma",      verified: true, email: "hashmaskp@gmail.com", phone: "+918301906415", role: "Member", status: "active", joined: "05/05/2026" },
  { name: "fathima ziya ck",  verified: true, email: "fathimaziyack21@gmail.com", phone: "+919168141068", role: "Member", status: "active", joined: "04/05/2026" },
  { name: "Fathima Hemda",    verified: true, email: "fathimahemda258@gmail.com", phone: "+919544327725", role: "Member", status: "active", joined: "04/05/2026" },
  { name: "Rifa sharin",      verified: true, email: "sharinrifa@gmail.com", phone: "+918075392027", role: "Member", status: "active", joined: "04/05/2026" },
  { name: "Hanna fathima v",  verified: true, email: "hannafathima8070@gmail.com", phone: "+917902797329", role: "Member", status: "active", joined: "04/05/2026" },
  { name: "Najiya A.T",       verified: true, email: "najiyaazeez77@gmail.com", phone: "+919745897504", role: "Member", status: "active", joined: "04/05/2026" },
  { name: "Meharin Zainab M", verified: true, email: "meharinmoluzz@gmail.com", phone: "+917902560856", role: "Member", status: "active", joined: "04/05/2026" },
  { name: "Kadeeja zahwa k",  verified: true, email: "Kadeejazahwa@gmail.com", phone: "+919048505152", role: "Member", status: "active", joined: "04/05/2026" },
  { name: "fathima niha pk",  verified: true, email: "Fathimanihaas123@gmail.com", phone: "+917356999255", role: "Member", status: "active", joined: "04/05/2026" },
  { name: "Jinsha jaheer p",  verified: true, email: "jinshajaheer23@gmail.com", phone: "+917907491907", role: "Member", status: "active", joined: "04/05/2026" },
  { name: "Rana Fathima MP",  verified: true, email: "ranafathima10075@gmail.com", phone: "+917909243893", role: "Member", status: "active", joined: "04/05/2026" },
  { name: "Nashida.p",        verified: true, email: "nashida0998@gmail.com", phone: "+919645250030", role: "Member", status: "active", joined: "04/05/2026" },
  { name: "Munjiya.k",        verified: true, email: "munjiyashanu8@gmail.com", phone: "+919747406416", role: "Member", status: "active", joined: "04/05/2026" },
];

const TEAMS = [
  { name: "Test Deail", desc: "6frt6j", manager: "KTX GLOBAL", members: 1, status: "active", created: "19/05/2026" },
];

const INVITATIONS = [
  { email: "jineshp25@gmail.com", role: "Member", status: "pending", by: "KTX GLOBAL", sent: 0, expires: "Expires in 7 days" },
];

const ROLES = [
  { name: "Admin",  sys: true,  desc: "Can manage users, settings, and most features", perms: 57, created: "25/03/2026" },
  { name: "Member", sys: true,  desc: "Can manage leads and contacts",                  perms: 15, created: "25/03/2026" },
  { name: "Owner",  sys: true,  desc: "Full access to all features and settings",       perms: 53, created: "25/03/2026" },
  { name: "test lead assign", sys: false, desc: "—",                                    perms: 41, created: "15/05/2026" },
  { name: "Viewer", sys: true,  desc: "Read-only access",                               perms: 5,  created: "25/03/2026" },
];

function PaneHead({ title, sub, actions }) {
  return (
    <div className="ls-pane-head">
      <div>
        <h2>{title}</h2>
        {sub && <div className="ls-pane-sub">{sub}</div>}
      </div>
      <div className="ls-actions">{actions}</div>
    </div>
  );
}

function ChevDown() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m6 9 6 6 6-6"/></svg>;
}

function MoreDots() {
  return (
    <button className="ls-icon-btn" title="More">
      <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="5" r="1.3" fill="currentColor"/>
        <circle cx="12" cy="12" r="1.3" fill="currentColor"/>
        <circle cx="12" cy="19" r="1.3" fill="currentColor"/>
      </svg>
    </button>
  );
}

function UsersPane() {
  const [q, setQ] = useState("");
  return (
    <div>
      <PaneHead
        title="Users"
        sub="Manage account users and their roles"
        actions={
          <>
            <button className="um-mini-filter">Role <ChevDown /></button>
            <button className="um-mini-filter">Status <ChevDown /></button>
            <button className="btn-primary"><Icon name="plus" className="" size={14} />Add User</button>
          </>
        }
      />
      <div className="um-search">
        <Icon name="search" className="" />
        <input placeholder="Search by name, email, or phone number…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="um-meta">81 results</div>
      <div className="um-table-wrap"><table className="ls-table">
        <thead>
          <tr>
            <th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Status</th><th>Joined</th>
          </tr>
        </thead>
        <tbody>
          {USERS.map((u, i) => (
            <tr key={i}>
              <td>
                <div className="um-row-name">{u.name}</div>
                {u.verified && <div className="um-verified">Email verified</div>}
              </td>
              <td><span className="um-link-cell"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/></svg>{u.email}</span></td>
              <td><span className="um-link-cell" style={{ fontVariantNumeric: "tabular-nums" }}><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92V20a2 2 0 0 1-2.18 2A19.86 19.86 0 0 1 2 4.18 2 2 0 0 1 4 2h3.09a1 1 0 0 1 1 .75l1 4a1 1 0 0 1-.27 1L7.21 9.21a16 16 0 0 0 7.58 7.58l1.46-1.46a1 1 0 0 1 1-.27l4 1a1 1 0 0 1 .75 1z"/></svg>{u.phone}</span></td>
              <td><a className="um-role-link" href="#" onClick={(e) => e.preventDefault()}>{u.role}</a></td>
              <td><span className={`um-active ${u.status === "inactive" ? "inactive" : ""}`}>{u.status === "active" ? "Active" : "Inactive"}</span></td>
              <td><span className="um-link-cell"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>{u.joined}</span></td>
            </tr>
          ))}
        </tbody>
      </table></div>
      <div className="um-pager">
        <div className="um-pager-count">Showing 1 to 20 of 81 users</div>
        <div className="um-pager-btns">
          <button className="pager-btn">Previous</button>
          <button className="pager-btn active">1</button>
          <button className="pager-btn">2</button>
          <button className="pager-btn">3</button>
          <button className="pager-btn">4</button>
          <button className="pager-btn">5</button>
          <button className="pager-btn">Next</button>
        </div>
      </div>
    </div>
  );
}

function TeamsPane() {
  const [q, setQ] = useState("");
  return (
    <div>
      <PaneHead
        title="Teams"
        sub="Organize your users into teams with managers"
        actions={<button className="btn-primary"><Icon name="plus" className="" size={14} />Create Team</button>}
      />
      <div className="um-search">
        <Icon name="search" className="" />
        <input placeholder="Search by team name or description…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="um-meta">{TEAMS.length} team</div>
      <div className="um-table-wrap"><table className="ls-table">
        <thead>
          <tr><th>Team Name</th><th>Description</th><th>Manager</th><th>Members</th><th>Status</th><th>Created</th><th style={{ width: 40 }}></th></tr>
        </thead>
        <tbody>
          {TEAMS.map((t, i) => (
            <tr key={i}>
              <td>
                <span className="um-team-name">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20a6 6 0 0 1 12 0M15 20a5 5 0 0 1 6-4.5"/></svg>
                  {t.name}
                </span>
              </td>
              <td style={{ color: "var(--text-2)" }}>{t.desc}</td>
              <td>
                <span className="um-manager">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20a6 6 0 0 1 12 0M15 20a5 5 0 0 1 6-4.5"/></svg>
                  {t.manager}
                </span>
              </td>
              <td>
                <span className="um-members">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20a6 6 0 0 1 12 0M15 20a5 5 0 0 1 6-4.5"/></svg>
                  {t.members} members
                </span>
              </td>
              <td><span className="um-active">Active</span></td>
              <td style={{ color: "var(--text-2)", fontVariantNumeric: "tabular-nums" }}>{t.created}</td>
              <td><MoreDots /></td>
            </tr>
          ))}
        </tbody>
      </table></div>
    </div>
  );
}

function InvitationsPane() {
  const [q, setQ] = useState("");
  return (
    <div>
      <PaneHead
        title="Invitations"
        sub="Manage pending and completed user invitations"
        actions={
          <>
            <button className="um-mini-filter">Role <ChevDown /></button>
            <button className="um-mini-filter">Status <ChevDown /></button>
            <button className="btn-primary"><Icon name="plus" className="" size={14} />Invite User</button>
          </>
        }
      />
      <div className="um-search">
        <Icon name="search" className="" />
        <input placeholder="Search by email…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="um-meta">{INVITATIONS.length} result</div>
      <div className="um-table-wrap"><table className="ls-table">
        <thead><tr><th>Email</th><th>Role</th><th>Status</th><th>Invited By</th><th>Sent</th><th>Expires</th><th>Actions</th></tr></thead>
        <tbody>
          {INVITATIONS.map((iv, i) => (
            <tr key={i}>
              <td><span className="um-link-cell"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/></svg>{iv.email}</span></td>
              <td><span className="tag-soft">{iv.role}</span></td>
              <td><span className="um-active pending">Pending</span></td>
              <td><span className="um-invited-by"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="8" r="3.2"/><path d="M5 21c0-3.9 3.1-7 7-7s7 3.1 7 7"/></svg>{iv.by}</span></td>
              <td><span className="um-sent"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 6h16M4 12h16M4 18h16"/></svg>{iv.sent}</span></td>
              <td><span className="um-expires"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>{iv.expires}</span></td>
              <td><MoreDots /></td>
            </tr>
          ))}
        </tbody>
      </table></div>
    </div>
  );
}

function RolesPane() {
  const [q, setQ] = useState("");
  return (
    <div>
      <PaneHead
        title="Roles & Permissions"
        sub="Manage roles and their associated permissions for your team"
        actions={<button className="btn-primary"><Icon name="plus" className="" size={14} />Create Role</button>}
      />
      <div className="um-search">
        <Icon name="search" className="" />
        <input placeholder="Search by name or description…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="um-meta">{ROLES.length} roles</div>
      <div className="um-table-wrap"><table className="ls-table">
        <thead><tr><th>Role Name</th><th>Description</th><th>Permissions</th><th>Created</th><th style={{ width: 40 }}></th></tr></thead>
        <tbody>
          {ROLES.map((r, i) => (
            <tr key={i}>
              <td>
                <span className="um-role-name">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/></svg>
                  {r.name}
                  {r.sys && <span className="um-sys-tag">System</span>}
                </span>
              </td>
              <td style={{ color: r.desc === "—" ? "var(--text-3)" : "var(--text-2)" }}>{r.desc}</td>
              <td><span className="um-perms"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><circle cx="7" cy="14" r="3"/><path d="m10 11 8-8 4 4-8 8M14 7l4 4M9 17l-2 2"/></svg>{r.perms} permissions</span></td>
              <td style={{ color: "var(--text-2)", fontVariantNumeric: "tabular-nums" }}>{r.created}</td>
              <td><MoreDots /></td>
            </tr>
          ))}
        </tbody>
      </table></div>
    </div>
  );
}

const PANES = { users: UsersPane, teams: TeamsPane, invitations: InvitationsPane, roles: RolesPane };

function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [tab, setTab] = useState(() => {
    const p = new URLSearchParams(window.location.search).get("tab") || window.__umTab;
    return TABS.find(x => x.id === p)?.id || "users";
  });

  const [tweaks, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{ "theme": "dark", "accent": "#ef3b3b", "fontScale": 100 }/*EDITMODE-END*/);
  useEffect(() => { document.documentElement.setAttribute("data-theme", tweaks.theme); }, [tweaks.theme]);
  useEffect(() => {
    document.documentElement.style.setProperty("--brand", tweaks.accent);
    document.documentElement.style.setProperty("--brand-strong", tweaks.accent);
  }, [tweaks.accent]);
  useEffect(() => { document.documentElement.style.fontSize = `${tweaks.fontScale * 0.625}%`; }, [tweaks.fontScale]);

  const Pane = PANES[tab] || UsersPane;

  return (
    <div className={`app ${collapsed ? "sidebar-collapsed" : ""}`}>
      <Sidebar active="settings" collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      <main className="main">
        <Topbar
          title="User Management"
          subtitle="Manage users and invitations for your account"
          theme={tweaks.theme}
          setTheme={(v) => setTweak("theme", v)}
        />
        <div className="content">
          <div className="ls-layout">
            <aside className="ls-side">
              <h3>User Management</h3>
              <div className="ls-side-list">
                {TABS.map((t) => (
                  <button key={t.id} className={`ls-side-item ${tab === t.id ? "active" : ""}`} onClick={() => setTab(t.id)}>
                    <Icon name={t.icon} className="" />
                    <span>{t.label}</span>
                  </button>
                ))}
              </div>
            </aside>
            <section className="ls-pane">
              <Pane />
            </section>
          </div>
        </div>
      </main>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme" />
        <TweakRadio label="Mode" value={tweaks.theme} options={["dark", "light"]} onChange={(v) => setTweak("theme", v)} />
        <TweakColor label="Accent" value={tweaks.accent} options={["#ef3b3b", "#2563eb", "#7c3aed", "#16a34a"]} onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Display" />
        <TweakSlider label="Font scale" value={tweaks.fontScale} min={85} max={115} step={5} unit="%" onChange={(v) => setTweak("fontScale", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
